/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.c
 * Author: rubensantos
 *
 * Created on 28 de Maio de 2020, 22:23
 */

#include <stdio.h>
#include <stdlib.h>
#include "locais.h"

int main(int argc, char** argv) {    
    plocal salas = NULL;
    local *l = NULL;
    pessoa *p = NULL;
    char fichEspaco[15], fichPessoas[15], nome[50];
    int op, numIteracoes = 0, numRnd;
    
    //criaFicheiroEspaco();
    //mostraSalas("E5.bin");

    
    printf("Nome do ficheiro espaço: ");
    scanf("%s", fichEspaco);
    printf("Nome do ficheiro pessoas: ");
    scanf("%s", fichPessoas);
    
    
    l = lerFicheiroLocais(fichEspaco);
    p = lerFicheiroPessoas(fichPessoas);
    salas = inicializaEspaco(fichEspaco, fichPessoas, l, p, &numRnd);
    mostraEspaco(salas);
    
    do {
        op = menu();

        switch (op) {
            case 1: 
                numIteracoes++;
                guardaEstruturaFicheiro(salas, numIteracoes);
                modeloPropagacao(salas, numRnd);
                mostraEspaco(salas);
                
                
                break;
            case 2: 
                recuarPropagacao(salas);
                mostraEspaco(salas);
                break;
            case 3: 
                apresentaEstatistica(salas);
                break;
            case 4: 
                adicionaDoente(salas);
                mostraEspaco(salas);
                break;
            case 5:
                printf("Nome da pessoa: ");
                scanf("%s", nome);
                salas = transferePessoa(salas, nome);
                mostraEspaco(salas);
                break;
        }
    } while (op != 6);

    guardaFicheiro(salas);
    libertaTudo(salas);

    return (EXIT_SUCCESS);
}

