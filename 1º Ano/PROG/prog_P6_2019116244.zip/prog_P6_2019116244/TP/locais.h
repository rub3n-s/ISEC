/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   locais.h
 * Author: rubensantos
 *
 * Created on 29 de Maio de 2020, 12:24
 */

#ifndef LOCAIS_H
#define LOCAIS_H

typedef struct sala local, *plocal;
typedef struct dados pessoa, *ppessoa;

struct sala {
    int id; // id numérico do local
    int capacidade; // capacidade máxima
    ppessoa lista; // ponteiro para o inicio da lista pessoa
    plocal prox; // ponteiro para o proximo local
};

struct dados {
    char nome[100]; // id numérico da pessoa
    int idade; // nome da pessoa
    char estado; // estado da pessoa (S, D, I)
    int dias; // caso estado = 'D' (Doente), guarda o numero de dias que está infetado
    ppessoa prox; //ponteiro para a proxima pessoa
};

// Inicializa o gerador de numeros aleatorios.
// Esta funcao deve ser chamada apenas uma vez no inicio da execucao do programa
void initRandom();

//Devolve um valor inteiro aleatorio distribuido uniformemente entre [a, b]
int intUniformRnd(int a, int b);

//Devolve o valor 1 com probabilidade prob. Caso contrario, devolve 0
int probEvento(float prob);

int menu();
void criaFicheiroEspaco();
void mostraSalas(char *nome);
void lerNumeroLocais(char *nome, int *nrlocais);
void lerNumeroPessoas(char *nome, int *nrpessoas);
local* lerFicheiroLocais(char *fichEspaco);
pessoa* lerFicheiroPessoas();
plocal inicializaEspaco(char *fichEspaco, char* fichPessoas, local *l, pessoa *p, int *numRnd);
void mostraEspaco(plocal p);
void libertaPessoas(ppessoa p);
void libertaTudo(plocal p);
void modeloPropagacao(plocal p, int numRnd);
void apresentaEstatistica(plocal p);
void adicionaDoente(plocal p);
void guardaFicheiro(plocal p);
ppessoa pesquisaPessoa(plocal p, char *nome);
plocal transferePessoa(plocal p, char *nome);
plocal eliminaPessoa(plocal p, int id, char *nome);
plocal recuarPropagacao(plocal p);
void guardaEstruturaFicheiro(plocal p, int numI);

#endif /* LOCAIS_H */
