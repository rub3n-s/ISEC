package pt.isec.pa.teointrojfx.ui.gui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import pt.isec.pa.teointrojfx.model.ModelData;

public class RootPane extends VBox {
    ModelData data;

    Label lbMsg;
    Button btnOk;

    public RootPane(ModelData data) {
        this.data = data;

        createViews();
        registerHandlers();
        update();
    }

    private void createViews() {
        setPadding(new Insets(20));

        HBox hbMsg = new HBox();
        Label lb1 = new Label("Message: ");
        lb1.setStyle("-fx-font-weight: bold;-fx-font-size: 20;");
        lb1.setAlignment(Pos.CENTER_RIGHT);
        lb1.setMinWidth(150);
        lbMsg = new Label();
        lbMsg.setPrefWidth(600);
        lbMsg.setTextFill(Color.WHITE);
        lbMsg.setBackground(new Background(new BackgroundFill(Color.RED,null,null)));
        lbMsg.setStyle("-fx-font-family: 'Comic Sans MS';-fx-font-size: 20;");
        lbMsg.setAlignment(Pos.CENTER);
        hbMsg.getChildren().addAll(lb1,lbMsg);

        AnchorPane anchorPane = new AnchorPane();
        anchorPane.setPadding(new Insets(10));
        anchorPane.setStyle("-fx-background-color: #ffffff;");
        btnOk = new Button("Ok");
        anchorPane.getChildren().add(btnOk);
        AnchorPane.setRightAnchor(btnOk,0.0);
        AnchorPane.setTopAnchor(btnOk,0.0);
        AnchorPane.setBottomAnchor(btnOk,0.0);

        this.getChildren().addAll(hbMsg,anchorPane);
    }

    private void registerHandlers() {
        btnOk.setOnAction( actionEvent -> {
            data.setMessage("Value = "+(int)(Math.random() * 100));
            update();
        });
    }

    private void update() {
        lbMsg.setText(data.getMessage());
    }
}



/*
public class RootPane extends VBox {
    ModelData data;

    // variables, inc. views

    public RootPane(ModelData data) {
        this.data = data;

        createViews();
        registerHandlers();
        update();
    }

    private void createViews() {

        // create and configure views
    }

    private void registerHandlers() {
        // handlers/listeners
    }

    private void update() {
        //update views
    }
}
*/
