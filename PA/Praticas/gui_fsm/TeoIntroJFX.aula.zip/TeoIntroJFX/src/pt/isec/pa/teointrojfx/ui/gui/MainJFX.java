package pt.isec.pa.teointrojfx.ui.gui;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import pt.isec.pa.teointrojfx.model.ModelData;
import pt.isec.pa.teointrojfx.ui.gui.RootPane;

public class MainJFX extends Application {
    ModelData data;

    public MainJFX() {
        data = new ModelData();
    }

    @Override
    public void init() throws Exception {
        super.init();
        data.setMessage("init");
    }

    @Override
    public void start(Stage stage) throws Exception {
        RootPane root = new RootPane(data);
        Scene scene = new Scene(root,500,120);
        stage.setScene(scene);
        stage.setTitle("TeoIntroJFX");
        //stage.setMaximized(false);
        //stage.setResizable(false);
        stage.show();
    }

    @Override
    public void stop() throws Exception {
        super.stop();
    }
}
