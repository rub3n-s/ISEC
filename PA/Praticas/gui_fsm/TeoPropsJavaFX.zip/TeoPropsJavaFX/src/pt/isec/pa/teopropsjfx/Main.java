package pt.isec.pa.teopropsjfx;

import javafx.application.Application;
import pt.isec.pa.teopropsjfx.ui.gui.MainJFX;

public class Main {
    public static void main(String[] args) {
        Application.launch(MainJFX.class,args);
    }
}