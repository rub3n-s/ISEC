import pt.isec.pa.apoio_poe.model.fsm.ManagementContext;
import pt.isec.pa.apoio_poe.ui.ManagementUI;

public class Main {
    public static void main(String[] args) throws Exception {
        ManagementContext fsm = new ManagementContext();
        ManagementUI ui = new ManagementUI(fsm);
        ui.start();
    }
}
