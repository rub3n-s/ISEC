package pt.isec.pa.apoio_poe.model.fsm;

import pt.isec.pa.apoio_poe.model.command.*;
import pt.isec.pa.apoio_poe.model.data.ManagementData;

import java.util.ArrayList;

public class ManagementContext {
    IManagementState state;
    ManagementData data;
    CommandManager cm;

    public ManagementContext() {
        data = new ManagementData();
        state = ManagementState.CONFIGURACAO.createState(this,data);
        cm = new CommandManager();
    }

    void changeState(IManagementState newState) {
        state = newState;
    }

    /* devolve o estado atual da app */
    public ManagementState getState() {
        if (state == null)
            return null;
        return state.getState();
    }

    /* ir para fase seguinte */
    public boolean avancar() { return state.avancar(); }

    /* fechar fase */
    public boolean fechar() { return state.fechar(); }

    /* ir para fase anterior */
    public boolean voltar() { return state.voltar(); }

    /* ler ficheiros csv de varias classes */
    public boolean lerCSV(String nome_fich, String nome_obj) { return data.lerCSV(nome_fich,nome_obj); }

    /* consultar listas de objetos das classes */
    public boolean consultar(String op) { return data.consultar(op); }

    /* consultar listas com filtros */
    public boolean consultarFiltros(String opcao,ArrayList<Integer> arr) { return data.consultarFiltros(opcao,arr); }

    /* previne a repeticao de objetos */
    public boolean objetoUnico(Object obj) { return data.objetoUnico(obj); }

    /* guarda o estado da app na fase 'CONFIGURACAO' */
    public boolean exportarFase1() { return data.exportarFase1(); }

    /* guarda o estado da app na fase 'CANDIDATURA' */
    public boolean exportarFase2() { return data.exportarFase2(); }

    /* guarda o estado da app na fase 'PROPOSTA' */
    public boolean exportarFase3() { return data.exportarFase3(); }

    /* guarda o estado da app na fase 'ORIENTADORES' e 'CONSULTA' */
    public boolean exportarFase4e5() { return data.exportarFase4e5(); }

    /*============================== ALUNOS ==============================*/
    /* modificacao de parametros dos alunos */
    public boolean modificarAluno(long numero, String op, Object obj) { return data.modificarAluno(numero,op,obj); }

    /* verifica se o numero de aluno existe */
    public boolean verificaNumero(long numero) {return data.verificaNumero(numero); }

    /* eliminar aluno*/
    public boolean eliminaAluno(long numero) { return data.eliminaAluno(numero); }

    /*==============================  DOCENTES ==============================*/
    /* modificacao de parametros dos docentes */
    public boolean modificarDocente(String email, String op, Object obj) { return data.modificarDocente(email,op,obj); }

    /* eliminar docente*/
    public boolean eliminaDocente(String email) { return data.eliminaDocente(email); }

    /* verifiac se o email do docente existe */
    public boolean verificaEmail(String email) { return data.verificaEmail(email); }

    /*============================== PROPOSTAS ==============================*/
    /* modificacao de parametros das propostas */
    public boolean modificarProposta(String codigo, String op, Object obj) { return data.modificarProposta(codigo,op,obj); }

    /* eliminar docente*/
    public boolean eliminaProposta(String codigo) { return data.eliminaProposta(codigo); }

    /*============================== CANDIDATURAS ==============================*/
    /* modificacao de parametros das candidaturas */
    public boolean modificarCandidatura(Long numero, String op, String codigo) { return data.modificarCandidatura(numero,op,codigo); }

    /* eliminar candidatura */
    public boolean eliminaCandidatura(Long numero) { return data.eliminaCandidatura(numero); }

    /*============================== FASE PROPOSTAS ==============================*/
    public boolean atribuicaoAutomatica(String str) { return data.atribuicaoAutomatica(str); }

    /*============================== FASE ORIENTADORES ==============================*/
    /* consulta propostas associadas ao docente */
    public void consultarDocenteProp(String codigo) { data.consultarDocenteProp(codigo); }

    /* altera o docente associado a proposta */
    public void alterarDocenteProp(String email, String codigo) { data.alterarDocenteProp(email,codigo); }

    /*============================== COMANDOS ==============================*/
    /* atribuicaoManual / RemocaoManual (Alunos/Docentes) */
    public boolean atribuicaoManual(String codigo, long numAluno) { return cm.invokeCommand(new atribuicaoManualAluno(data,codigo,numAluno)); }

    public boolean remocaoManual(String codigo, long numAluno) { return cm.invokeCommand(new remocaoManualAluno(data,codigo,numAluno)); }

    public boolean atribuicaoManualDocente(String codigo, String email) { return cm.invokeCommand(new atribuicaoManualDocente(data,codigo,email)); }

    public boolean remocaoManualDocente(String codigo, String email) { return cm.invokeCommand(new remocaoManualDocente(data,codigo,email)); }

    /* undo / redo */
    public boolean hasUndo() { return cm.hasUndo(); }

    public boolean undo() { return cm.undo(); }

    public boolean hasRedo() { return cm.hasRedo(); }

    public boolean redo() { return cm.redo(); }
}
