package pt.isec.pa.apoio_poe.model.fsm;

import pt.isec.pa.apoio_poe.model.command.ICommand;
import pt.isec.pa.apoio_poe.model.data.ManagementData;

import java.util.ArrayList;

abstract class ManagementStateAdapter implements IManagementState, ICommand {
    ManagementData data;
    ManagementContext context;

    protected ManagementStateAdapter(ManagementContext context, ManagementData data) {
        this.context = context;
        this.data = data;
    }

    protected void changeState(IManagementState newState) {
        context.changeState(newState);
    }

    @Override
    public ManagementState getState() {
        return null;
    }

    /* ir para fase seguinte */
    @Override
    public boolean avancar() {
        return false;
    }

    /* fechar fase */
    @Override
    public boolean fechar() {
        return false;
    }

    /* ir para fase anterior */
    @Override
    public boolean voltar() {
        return false;
    }

    /* ler ficheiros csv de varias classes */
    @Override
    public boolean lerCSV(String nome_fich, String nome_obj) { return false; }

    /* consultar listas de objetos das classes */
    @Override
    public boolean consultar(String op) {
        return false;
    }

    /* consultar listas com filtros */
    @Override
    public boolean consultarFiltros(String opcao,ArrayList<Integer> arr) { return false; }

    /* previne a repeticao de objetos */
    @Override
    public boolean objetoUnico(Object obj) {
        return false;
    }

    /* guarda o estado da app na fase 'CONFIGURACAO' */
    @Override
    public boolean exportarFase1() { return false; }

    /* guarda o estado da app na fase 'CANDIDATURA' */
    @Override
    public boolean exportarFase2() { return false; }

    /* guarda o estado da app na fase 'PROPOSTA' */
    @Override
    public boolean exportarFase3() { return false; }

    /* guarda o estado da app na fase 'ORIENTADORES' e 'CONSULTA' */
    @Override
    public boolean exportarFase4e5() { return false; }

    /*============================== ALUNOS ==============================*/
    /* modificacao de parametros dos alunos */
    @Override
    public boolean modificarAluno(long numero, String op, Object obj) { return false; }

    /* eliminar aluno */
    @Override
    public boolean eliminaAluno(long numero) { return false; }

    /* procura de aluno */
    /* verifica se o numero de aluno existe */
    @Override
    public boolean verificaNumero(long numero) {return false; }

    /*==============================  DOCENTES ==============================*/
    /* modificacao de parametros dos docentes */
    @Override
    public boolean modificarDocente(String email, String op, Object obj) { return false; }

    /* eliminar docente*/
    @Override
    public boolean eliminaDocente(String email) { return false; }

    /* verifica se o email do docente existe */
    @Override
    public boolean verificaEmail(String email) { return false; }

    /*============================== PROPOSTAS ==============================*/
    /* modificacao de parametros das propostas */
    @Override
    public boolean modificarProposta(String codigo, String op, Object obj) { return false; }

    /* eliminar proposta */
    @Override
    public boolean eliminaProposta(String codigo) { return false; }

    /*============================== CANDIDATURAS ==============================*/
    /* modificacao de parametros das candidaturas */
    @Override
    public boolean modificarCandidatura(Long numero, String op, String codigo) { return false; }

    /* eliminar candidatura */
    @Override
    public boolean eliminaCandidatura(Long numero) { return false; }

    /*============================== FASE PROPOSTAS ==============================*/
    @Override
    public boolean atribuicaoAutomatica(String str) { return false; }

    /*============================== FASE ORIENTADORES ==============================*/
    /* consulta propostas associadas ao docente */
    @Override
    public void consultarDocenteProp(String codigo) { }

    /* altera o docente associado a proposta */
    @Override
    public void alterarDocenteProp(String email, String codigo) { }

    /*============================== COMANDOS ==============================*/
    /* atribuicaoManual / RemocaoManual (Alunos/Docentes) */
    @Override
    public boolean atribuicaoManualAluno(String codigo, long numAluno) { return false; }

    @Override
    public boolean remocaoManualAluno(String codigo, long numAluno) { return false; }

    @Override
    public boolean atribuicaoManualDocente(String codigo, String email) { return false; }

    @Override
    public boolean remocaoManualDocente(String codigo, String email) { return false; }

    /* undo / redo */
    @Override
    public boolean hasUndo() { return false; }

    @Override
    public boolean undo() { return false; }

    @Override
    public boolean hasRedo() { return false; }

    @Override
    public boolean redo() { return false; }
}
