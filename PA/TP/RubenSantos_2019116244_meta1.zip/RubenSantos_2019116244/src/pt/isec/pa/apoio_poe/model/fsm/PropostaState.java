package pt.isec.pa.apoio_poe.model.fsm;

import pt.isec.pa.apoio_poe.model.data.ManagementData;

import java.util.ArrayList;

public class PropostaState extends ManagementStateAdapter {
    public PropostaState(ManagementContext context, ManagementData data) {
        super(context,data);
    }

    @Override
    public ManagementState getState() {
        return ManagementState.PROPOSTA;
    }

    @Override
    public boolean avancar() {
        // se a ORIENTADORES ja estiver fechada avanca para a fase ORIENTADORES_FECHADA
        if (data.isFechada(ManagementState.ORIENTADORES)) {
            changeState(ManagementState.ORIENTADORES_FECHADA.createState(context, data));
            return true;
        }
        changeState(ManagementState.ORIENTADORES.createState(context,data));
        return true;
    }

    @Override
    public boolean voltar() {
        // se a CANDIDATURA ja estiver fechada avanca para a fase CANDIDATURA_FECHADA
        if (data.isFechada(ManagementState.CANDIDATURA)) {
            changeState(ManagementState.CANDIDATURA_FECHADA.createState(context, data));
            return true;
        }
        changeState(ManagementState.CANDIDATURA.createState(context,data));
        return true;
    }

    @Override
    public boolean fechar() {
        // verifica se todas as candidaturas tem um projeto atribuido
        if (!data.consultaAtribuicoes())
            return false;

        // guarda a informação que esta fechada no ManagementData
        data.fechaState(ManagementState.PROPOSTA);

        // avancar de fase (ORIENTADORES)
        avancar();

        System.out.println("\nFase de Proposta fechada\n");
        return true;
    }

    @Override
    public boolean execute() {
        return false;
    }

    @Override
    public boolean undo() {
        return false;
    }
}
