package pt.isec.pa.apoio_poe.model.fsm;

import pt.isec.pa.apoio_poe.model.data.ManagementData;

public class CandidaturaState extends ManagementStateAdapter {
    public CandidaturaState(ManagementContext context, ManagementData data) {
        super(context,data);
    }

    @Override
    public ManagementState getState() {
        return ManagementState.CANDIDATURA;
    }

    @Override
    public boolean avancar() {
        // se a PROPOSTA ja estiver fechada avanca para a fase PROPOSTA_FECHADA
        if (data.isFechada(ManagementState.PROPOSTA))
            changeState(ManagementState.PROPOSTA_FECHADA.createState(context,data));
        else
            changeState(ManagementState.PROPOSTA.createState(context,data));
        return true;
    }

    @Override
    public boolean voltar() {
        // se a CONFIGURACAO ja estiver fechada avanca para a fase CONFIGURACAO_FECHADA
        if (data.isFechada(ManagementState.CONFIGURACAO))
            changeState(ManagementState.CONFIGURACAO_FECHADA.createState(context,data));
        else
            changeState(ManagementState.CONFIGURACAO.createState(context,data));
        return true;
    }

    @Override
    public boolean fechar() {
        if (!data.isFechada(ManagementState.CONFIGURACAO)) {
            System.out.println("\nEsta fase so pode ser fechada quando a 'CONFIGURACAO' estiver fechada.\n");
            return false;
        }

        // guarda a informação que esta fechada no ManagementData
        data.fechaState(ManagementState.CANDIDATURA);

        // avancar de fase (PROPOSTA)
        avancar();

        System.out.println("\nFase 'CANDIDATURA' fechada\n");
        return true;
    }

    @Override
    public boolean execute() {
        return false;
    }

    @Override
    public boolean undo() {
        return false;
    }
}
