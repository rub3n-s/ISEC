package pt.isec.pa.apoio_poe.model.fsm;

import java.util.ArrayList;

public interface IManagementState {
    /* devolve o estado da maquina */
    ManagementState getState();

    /* fechar/avancar de fase */
    boolean fechar();
    boolean avancar();
    boolean voltar();

    boolean consultar(String op);
    boolean consultarFiltros(String opcao,ArrayList<Integer> arr);
    boolean lerCSV(String nome_fich, String nome_obj);
    boolean objetoUnico(Object obj);

    /*============================== EXPORTACAO DE DADOS > CSV ==============================*/
    boolean exportarFase1();    /* CONFIGURACAO' */
    boolean exportarFase2();    /* 'CANDIDATURA' */
    boolean exportarFase3();    /* 'PROPOSTA' */
    boolean exportarFase4e5();  /* 'ORIENTADORES' e 'CONSULTA' */

    /*============================== GESTAO DE ALUNOS ==============================*/
    boolean modificarAluno(long numero, String op, Object obj); /* modificacao de parametros das propostas */
    boolean eliminaAluno(long numero);      /* eliminar aluno */
    boolean verificaNumero(long numero);    /* verifica se o numero de aluno existe */

    /*==============================  GESTAO DE DOCENTES ==============================*/
    boolean modificarDocente(String email, String op, Object obj);  /* modificacao de parametros dos docentes */
    boolean eliminaDocente(String email);   /* eliminar docente */
    boolean verificaEmail(String email);    /* verifica se o email do docente existe */

    /*============================== GESTAO DE PROPOSTAS ==============================*/
    boolean modificarProposta(String codigo, String op, Object obj);    /* modificacao de parametros das propostas */
    boolean eliminaProposta(String codigo);     /* eliminar proposta */

    /*============================== GESTAO DE CANDIDATURAS ==============================*/
    boolean modificarCandidatura(Long numero, String op, String codigo);    /* modificacao de parametros das candidaturas */
    boolean eliminaCandidatura(Long numero);  /* eliminar candidatura */

    /*============================== FASE PROPOSTAS/ORIENTADORES ==============================*/
    boolean atribuicaoAutomatica(String str);

    /*============================== FASE ORIENTADORES ==============================*/
    void consultarDocenteProp(String codigo);   /* consulta propostas associadas ao docente */
    void alterarDocenteProp(String email, String codigo);   /* altera o docente associado a proposta */

    /*============================== COMANDOS ==============================*/
    /* FASE PROPOSTAS */
    boolean atribuicaoManualAluno(String codigo, long numAluno);
    boolean remocaoManualAluno(String codigo, long numAluno);
    /* FASE ORIENTADORES */
    boolean atribuicaoManualDocente(String codigo, String email);
    boolean remocaoManualDocente(String codigo, String email);

    // undo/redo
    boolean hasUndo();
    boolean undo();
    boolean hasRedo();
    boolean redo();
}
