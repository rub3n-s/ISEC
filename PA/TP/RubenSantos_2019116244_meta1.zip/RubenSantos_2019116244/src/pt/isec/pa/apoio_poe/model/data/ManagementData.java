package pt.isec.pa.apoio_poe.model.data;

import pt.isec.pa.apoio_poe.model.fsm.ManagementState;
import pt.isec.pa.apoio_poe.ui.utils.PAInput;

import java.io.*;
import java.util.*;

//TODO::
//  criar um log para insercao/modificao/consulta
//  ao eliminar docente e aluno tem de ser retirado das propostas

public class ManagementData {
    private ArrayList<Aluno> alunos;
    private ArrayList<Docente> docentes;
    private ArrayList<Proposta> propostas;  // estagio, projeto, autoproposto
    private ArrayList<Candidatura> candidaturas;

    List<Proposta> propostasAtribuidas;

    // Fecho das fases
    private boolean configuracaoFechada;
    private boolean candidaturaFechada;
    private boolean propostaFechada;
    private boolean orientadoresFechada;
    private boolean consultaFechada;

    public ManagementData() {
        initManagement();
    }

    private void initManagement() { // metodo privado para inicializacao das listas
        alunos = new ArrayList<>();
        docentes = new ArrayList<>();
        propostas = new ArrayList<>();
        candidaturas = new ArrayList<>();

        propostasAtribuidas = new ArrayList<>();

        configuracaoFechada = false;
        candidaturaFechada = false;
        propostaFechada = false;
        orientadoresFechada = false;
        consultaFechada = false;
    }

    /* getters (listas)*/
    public ArrayList<Aluno> getAlunos() {  return alunos; }  // devolve a lista de alunos
    public ArrayList<Docente> getDocentes() { return docentes; }    // devolve a lista de docentes
    public ArrayList<Proposta> getPropostas() { return propostas; }    // devolve a lista de estagios
    public ArrayList<Candidatura> getCandidaturas() { return candidaturas; }    // devolve a lista de candidaturas

    /* getter e setter para o estado da fase */
    public boolean isFechada(ManagementState state) {
        switch(state) {
            case CONFIGURACAO -> { return configuracaoFechada; }
            case CANDIDATURA -> { return candidaturaFechada; }
            case PROPOSTA -> { return propostaFechada; }
            case ORIENTADORES -> { return orientadoresFechada; }
        }
        return false;
    }

    public void fechaState(ManagementState state) {
        switch(state) {
            case CONFIGURACAO -> configuracaoFechada = true;
            case CANDIDATURA -> candidaturaFechada = true;
            case PROPOSTA -> propostaFechada = true;
            case ORIENTADORES -> orientadoresFechada = true;
        }
    }

    /*============================== LEITURA/ESCRITA > CSV ==============================*/
    public boolean lerCSV(String nome_fich, String nome_obj) {
        if (nome_fich == null)
            return false;

        /* verifica se o nome introduzido do ficheiro existe */
        File file = new File("./csv/" + nome_fich + ".csv");
        if (!file.exists()) {
            System.out.println("\nO ficheiro não existe!");
            return false;
        }

        switch (nome_obj) {  // nome_obj é definido na UI
            case "Aluno" -> lerAluno(nome_fich);
            case "Docente" -> lerDocente(nome_fich);
            case "Proposta" -> lerProposta(nome_fich);
            case "Candidatura" ->lerCandidatura(nome_fich);
            default -> { return false; }
        }
        return true;
    }

    private void lerAluno(String nome_fich)  {
        String line = "";
        String splitBy = ",";
        try {
            /* abertura do ficheiro dentro do try catch porque pode gerar uma excepcao */
            BufferedReader br = new BufferedReader(new FileReader("./csv/" + nome_fich + ".csv"));

            while ((line = br.readLine()) != null) {
                String[] aluno = line.split(splitBy);    // usa virgula como separador

                /* verificar se a linha lida tem o numero de colunas necessarias para criar um objeto Aluno */
                if (aluno.length == 7) {
                    aluno[6] = aluno[6].toUpperCase();
                    if (aluno[6].equalsIgnoreCase("TRUE") || aluno[6].equalsIgnoreCase("FALSE")) {
                        Aluno tmp = new Aluno(Long.parseLong(aluno[0]), aluno[1], aluno[2],
                                aluno[3], aluno[4], Double.parseDouble(aluno[5]), Boolean.parseBoolean(aluno[6]));
                        verificaAluno(tmp); // true -> insere o aluno
                    }
                }
            }
            System.out.println("\nFicheiro '" + nome_fich + ".csv' carregado com sucesso.");

            /* fechar o BufferedReader */
            br.close();
        } catch(IOException e) {
            e.printStackTrace();
        }
    }

    private void lerDocente(String nome_fich) {
        String line = "";
        String splitBy = ",";
        try {
            /* abertura do ficheiro dentro do try catch porque pode gerar uma excepcao */
            BufferedReader br = new BufferedReader(new FileReader("./csv/" + nome_fich + ".csv"));

            while ((line = br.readLine()) != null) {
                String[] docente = line.split(splitBy);    // usa virgula como separador

                /* verificar se a linha lida tem o numero de colunas necessarias para criar um objeto Docente */
                if (docente.length == 2) {
                    Docente tmp = new Docente(docente[0], docente[1]);
                    verificaDocente(tmp); // true -> insere o aluno
                }
            }
            System.out.println("\nFicheiro '" + nome_fich + ".csv' carregado com sucesso.");

            /* fechar o BufferedReader */
            br.close();
        } catch(IOException e) {
            e.printStackTrace();
        }
    }

    private void lerProposta(String nome_fich) {
        String line = "";
        String splitBy = ",";
        long numTmp;    // numero temporario, usado para saber quando é lido o numero de aluno
        String strTmp;   // numero temporario, usado para saber quando é lido o numero de aluno
        try {
            /* abertura do ficheiro dentro do try catch porque pode gerar uma excepcao */
            BufferedReader br = new BufferedReader(new FileReader("./csv/" + nome_fich + ".csv"));
            while ((line = br.readLine()) != null) {
                numTmp = 0;  strTmp = null; // redefine os valores

                /* divide a linha usando a virgula como separador */
                String[] proposta = line.split(splitBy);
                switch (proposta[0]) {
                    case "T1":  // estagio
                        if (proposta.length < 5) return;    // parametros insuficientes
                        if (proposta.length == 6)
                            numTmp = Long.parseLong(proposta[5]);
                        Proposta est = new Estagio(proposta[0], proposta[1], proposta[2], proposta[3], proposta[4], numTmp);
                        verificaProposta(est); // true -> insere estagio
                        break;
                    case "T2":  // projeto
                        if (proposta.length < 5) return;    // parametros insuficientes
                        if (proposta.length == 6)    // numero aluno
                            numTmp = Long.parseLong(proposta[5]);
                        Proposta proj = new Projeto(proposta[0], proposta[1], proposta[2], proposta[3], proposta[4], numTmp);
                        verificaProposta(proj); // true -> insere projeto
                        break;
                    case "T3":  // autoproposto
                        if (proposta.length < 3) return;    // parametros insuficientes
                        if (proposta.length == 4)
                            numTmp = Long.parseLong(proposta[3]);
                        Proposta auto = new Autoproposto(proposta[0], proposta[1], proposta[2], numTmp);
                        verificaProposta(auto); // true -> insere autoproposto
                        break;
                }
            }
            System.out.println("\nFicheiro '" + nome_fich + ".csv' carregado com sucesso.");

            /* fechar o BufferedReader */
            br.close();
        } catch(IOException e) {
            e.printStackTrace();
        }
    }

    private void lerCandidatura(String nome_fich) {
        String line = "";
        String splitBy = ",";
        ArrayList<String> codigos;

        if (verificaLista(alunos)) return;             // nao existem alunos para poder candidatar
        else  if (verificaLista(propostas)) return;    // nao existem propostas para se poder candidatar

        try {
            /* abertura do ficheiro dentro do try catch porque pode gerar uma excepcao */
            BufferedReader br = new BufferedReader(new FileReader("./csv/" + nome_fich + ".csv"));

            while ((line = br.readLine()) != null) {
                String[] candidatura = line.split(splitBy);    // usa virgula como separador

                /* verificar se a linha lida tem o numero de colunas necessarias para criar um objeto Aluno */
                if (candidatura.length >= 2) {
                    codigos = new ArrayList<>();
                    for (int i = 1; i < candidatura.length; i++)
                        codigos.add(candidatura[i]);
                    /* converter os valores lidos como string */
                    Candidatura tmp = new Candidatura(Long.parseLong(candidatura[0]),codigos);
                    verificaCandidatura(tmp); // true -> insere a candidatura
                }
            }
            System.out.println("\nFicheiro '" + nome_fich + ".csv' carregado com sucesso.");

            /* fechar o BufferedReader */
            br.close();
        } catch(IOException e) {
            e.printStackTrace();
        }
    }

    public boolean exportarFase1() {
        File file = new File("./csv/fase1.csv");
        if (file.exists()) {
            file.delete();
            file = new File("./csv/fase1.csv");
        }

        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(file));

            bw.write("Alunos:\n");
            if (!alunos.isEmpty())
                for (var a : alunos)
                    bw.write(a.toString());
            else
                bw.write("Lista de alunos vazia.\n");

            bw.write("\nDocentes:\n");
            if (!docentes.isEmpty())
                for (var d : docentes)
                    bw.write(d.toString());
            else
                bw.write("Lista de docentes vazia.\n");

            bw.write("\nPropostas:\n");
            if (!propostas.isEmpty())
                for (var p : propostas)
                    bw.write(p.toString());
            else
                bw.write("Lista de propostas vazia.\n");

            System.out.println("Escreveu para o ficheiro 'fase1.csv' com sucesso.");
            /* fechar o BufferedWriter */
            bw.close();
        } catch(IOException e) {
            e.printStackTrace();
        }

        return true;
    }

    public boolean exportarFase2() {
        File file = new File("./csv/fase2.csv");
        if (file.exists()) {
            file.delete();  /* se o ficheiro já existir -> elimina e cria um novo ficheiro */
            file = new File("./csv/fase2.csv");
        }

        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(file));

            bw.write("Candidaturas:\n");
            if (!candidaturas.isEmpty())
                for (var c : candidaturas)
                    bw.write(c.toString());
            else
                bw.write("Lista de candidaturas vazia.\n");

            System.out.println("Escreveu para o ficheiro 'fase2.csv' com sucesso.");
            /* fechar o BufferedWriter */
            bw.close();
        } catch(IOException e) {
            e.printStackTrace();
        }

        return true;
    }

    public boolean exportarFase3() {
        File file = new File("./csv/fase3.csv");
        if (file.exists()) {    /* se o ficheiro já existir -> elimina e cria um novo ficheiro */
            file.delete();
            file = new File("./csv/fase3.csv");
        }

        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(file));

            boolean candidatura = false;
            boolean atribuida = false;

            if (alunos.isEmpty()) {
                bw.write("Lista de alunos vazia.\n");
                return true;
            }

            for (var a : alunos) {
                bw.write("Aluno: " + a.toString());
                for (var c : candidaturas) {
                    if (c.getAlunoAtribuido() == a.getNumero()) {
                        bw.write("Opcoes de Candidatura: " + c.toString());
                        candidatura = true;
                        break;
                    }
                }
                if (!candidatura)
                    bw.write("Opcoes de Candidatura: Sem candidatura.\n");
                candidatura = false;

                for (var p : propostasAtribuidas) {
                    if (p.getAlunoAtribuido() == a.getNumero()) {
                        bw.write("Proposta Atribuida: " + p.toString());
                        atribuida = true;
                        break;
                    }
                }
                if (!atribuida)
                    bw.write("Proposta Atribuida: Sem proposta atribuida.\n");
                atribuida = false;
                bw.write("\n");
            }
            System.out.println("Escreveu para o ficheiro 'fase3.csv' com sucesso.");
            /* fechar o BufferedWriter */
            bw.close();
        } catch(IOException e) {
            e.printStackTrace();
        }

        return true;
    }

    public boolean exportarFase4e5() {
        File file = new File("./csv/fase4e5.csv");
        if (file.exists()) {    /* se o ficheiro já existir -> elimina e cria um novo ficheiro */
            file.delete();
            file = new File("./csv/fase4e5.csv");
        }

        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(file));

            if (verificaLista(alunos)) return false;
            if (verificaLista(docentes)) return false;
            if (verificaLista(propostas)) return false;

            boolean candidatura = false;
            boolean atribuida = false;
            int index = 0;

            for (var a : alunos) {
                bw.write("Aluno: " + a.toString());

                bw.write("Opcoes de candidatura: ");
                for (var c : candidaturas) {
                    if (c.getAlunoAtribuido() == a.getNumero()) {
                        candidatura = true;
                        bw.write("\n");
                        for (int i = 0; i < c.getCodigos().size(); i++)
                            bw.write("\t" + (i+1) +  " - " + c.getCodigos().get(i) + "\n");
                    }
                }
                if (!candidatura)
                    bw.write("Sem candidatura registada.\n");

                bw.write("Proposta atribuida: ");
                for (var p : propostasAtribuidas) {
                    if (p.getAlunoAtribuido() == a.getNumero()) {
                        atribuida = true;
                        // se tiver candidatura mostra qual a opcao
                        if (candidatura) {
                            for (var c : candidaturas) {
                                if (c.getAlunoAtribuido() == a.getNumero()) {
                                    for (int i = 0; i < c.getCodigos().size(); i++)
                                        if (c.getCodigos().get(i).equals(p.getCodigo())) {
                                            bw.write("Opcao(" + (i + 1) + ") > ");
                                            break;
                                        }
                                }
                            }
                        }
                        bw.write(p.toString());

                        if (p.getTipo().equalsIgnoreCase("T2")) {
                            bw.write("Docente: ");
                            if (p.getDocente() != null)
                                bw.write(p.getDocente() + "\n");
                            else
                                bw.write("Sem docente atribuido.\n");
                        }
                    }
                }
                if (!atribuida)
                    bw.write("Sem proposta atribuida.\n");
                candidatura = false;
                atribuida = false;
                bw.write("\n");
            }
            System.out.println("Escreveu para o ficheiro 'fase4e5.csv' com sucesso.");
            /* fechar o BufferedWriter */
            bw.close();
        } catch(IOException e) {
            e.printStackTrace();
        }

        return true;
    }

    /*==================== VERIFICACAO PARAMETROS > ALUNO/DOCENTE/PROPOSTA/CANDIDATURA ======================*/
    /* valida qual o tipo de objeto recebido para insercao */
    public boolean objetoUnico(Object obj) {
        switch (obj.getClass().getSimpleName()) {
            case "Aluno" -> verificaAluno((Aluno) obj);
            case "Docente" -> verificaDocente((Docente) obj);
            case "Estagio" -> verificaProposta((Proposta) obj);
            case "Projeto" -> verificaProposta((Proposta) obj);
            case "Autoproposto" -> verificaProposta((Proposta) obj);
            case "Candidatura" -> verificaCandidatura((Candidatura) obj);
            default -> {
                System.out.println("\nObjeto recebido nao corresponde as classes existentes.\n");
                return false;
            }
        }
        return true;
    }

    private boolean verificaAluno(Aluno aluno) {    // alunos -> numero e email (valores unicos)
        if (aluno.getNumero() < 0 || aluno.getNome() == null || aluno.getEmail() == null)
            return false;
        if (!alunos.isEmpty()) {
            for (var a : alunos) {
                if (a.getEmail().equals(aluno.getEmail()) || a.getNumero() == aluno.getNumero()) {
                    System.out.println("Ja existe um aluno com o numero '" + aluno.getNumero() + "' ou email '" +
                            aluno.getEmail() + "'.");
                    return false;
                }
            }
        }
        // previne a introdução de ramos e cursos incorretos
        if ((!aluno.getSiglaRamo().equalsIgnoreCase("RAS") && !aluno.getSiglaRamo().equalsIgnoreCase("SI")
                && !aluno.getSiglaRamo().equalsIgnoreCase("DA"))
            || (!aluno.getSiglaCurso().equalsIgnoreCase("LEI") && !aluno.getSiglaCurso().equalsIgnoreCase("LEI-PL"))
            || (aluno.getClassificacao() < 0.0 || aluno.getClassificacao() > 1.0))
            return false;

        inserir(aluno); //  se os dados de aluno forem validados é inserido no sistema
        System.out.println("Aluno com o numero '" + aluno.getNumero() + "' inserido com sucesso.");
        return true;
    }

    private boolean verificaDocente(Docente docente) {  // docentes -> email (valor unico)
        if (docente.getNome() == null || docente.getEmail() == null)
            return false;
        if (!docentes.isEmpty()) {
            for (var a : docentes) {
                if (a.getEmail().equals(docente.getEmail())) {
                    System.out.println("Ja existe um docente com o email '" + docente.getEmail() + "'.");
                    return false;
                }
            }
        }
        inserir(docente);   //  se os dados do docente forem validados é inserido no sistema
        System.out.println("Docente com o email '" + docente.getEmail() + "' inserido com sucesso.");
        return true;
    }

    private boolean verificaProposta(Proposta proposta) {
        // verifica se o numero de aluno foi inserido corretamente
        if (proposta.getAlunoAtribuido() > 0) {
            boolean aluno = false;
            for (var a : alunos)
                if (a.getNumero() == proposta.getAlunoAtribuido())
                    aluno = true;
            if (!aluno) {
                System.out.println("Nao existe nenhum aluno com o numero '" + proposta.getAlunoAtribuido() + "'.");
                return false;
            }
        }

        // verifica se o email de docente foi inserido corretamente
        if (proposta.getDocente() != null) {
            boolean docente = false;
            for (var d : docentes)
                if (proposta.getDocente().equals(d.getEmail()))
                    docente = true;
            if (!docente) {
                System.out.println("Nao existe nenhum docente com o email '" + proposta.getDocente() + "'.");
                return false;
            }
        }

        if (!propostas.isEmpty()) {
            for (var p : propostas) {
                if (p.getCodigo().equals(proposta.getCodigo()) || p.getAlunoAtribuido() == proposta.getAlunoAtribuido() && p.getAlunoAtribuido() != 0) {
                    System.out.println("Ja existe uma proposta com o codigo'" + proposta.getCodigo() + "'.");
                    return false;
                }
            }
        }
        /* verifica quando há mais do que uma ramo separado por "|" */
        if (proposta.getTipo().equalsIgnoreCase("T1") || proposta.getTipo().equalsIgnoreCase("T2")) {
            String[] ramos = proposta.getRamoDestino().split("\\|+");
            if (ramos.length <= 0 || ramos.length > 3)
                return false;

            // verifica se os ramos foram inseridos corretamente
            for (var r : ramos)
                if (!r.equalsIgnoreCase("DA") && !r.equalsIgnoreCase("RAS") && !r.equalsIgnoreCase("SI"))
                    return false;
        }
        inserir(proposta);  /*  se os dados da proposta forem validados é inserido no sistema   */
        System.out.println("Proposta com o codigo '" + proposta.getCodigo() + "' inserida com sucesso.");
        return true;
    }

    private boolean verificaCandidatura(Candidatura candidatura) {
        if (!verificaNumero(candidatura.getAlunoAtribuido())) // verifica se a lista de alunos esta vazia e se o numero existe
            return false;
        if (candidatura.getCodigos() == null) {
            System.out.println("Lista de codigos nao pode estar vazia.");
            return false;
        }

        // o aluno ja tem candidatura registada
        for (var c : candidaturas)
            if (candidatura.getAlunoAtribuido() == c.getAlunoAtribuido())
                return false;

        // o aluno ja tem proposta atribuida
        for (var p : propostas) {
            if (p.getAlunoAtribuido() == candidatura.getAlunoAtribuido()) {
                System.out.println("O aluno '" + candidatura.getAlunoAtribuido() + "' ja tem uma proposta atribuida.");
                return false;
            }
        }

        // verifica se a proposta existe e ja tem um aluno atribuido
        boolean existeProposta = false;
        boolean alunoAtribuido = false;
        for (var c : candidatura.getCodigos()) {
            for (var p : propostas) {
                if (c.equals(p.getCodigo()))
                    existeProposta = true;
                if (c.equals(p.getCodigo()) && p.getAlunoAtribuido() != 0) {
                    alunoAtribuido = true;
                    break;
                }
            }
            if (!existeProposta) {
                System.out.println("Nao existe nenhuma proposta com o codigo '" + c + "'.");
                return false;
            }
            else if (alunoAtribuido) {
                System.out.println("A proposta com o codigo '" + c + "' ja foi atribuida.");
                return false;
            }
            existeProposta = false;
            alunoAtribuido = false;
        }

        inserir(candidatura);   /*  se os dados da proposta forem validados é inserido no sistema   */
        System.out.println("Candidatura do aluno '" + candidatura.getAlunoAtribuido() + "' inserida com sucesso.");
        return true;
    }

    /* metodo privado para insercao de alunos, docentes e propostas */
    private void inserir(Object obj) {
        switch(obj.getClass().getSimpleName()) {
            case "Aluno" -> alunos.add((Aluno) obj);
            case "Docente" -> docentes.add((Docente) obj);
            case "Estagio" -> propostas.add((Estagio) obj);
            case "Projeto" -> propostas.add((Projeto) obj);
            case "Autoproposto" -> propostas.add((Autoproposto) obj);
            case "Candidatura" -> candidaturas.add((Candidatura) obj);
        }
    }

    /*============================== CONSULTA > LISTAS ==============================*/
    public boolean consultar(String op) {
        switch (op) {
            case "Aluno" -> consultarAlunos();
            case "Docente" -> consultarDocentes();
            case "Proposta" -> consultarPropostas();
            //===== 'CANDIDATURAS' > LISTAGEM DE ALUNOS
            case "Autoproposta" -> consultarListaPropostas("autoproposta");
            case "comCandidatura" -> consultarListaPropostas("comCandidatura");
            case "semCandidatura" -> consultarListaPropostas("semCandidatura");
            //===== 'PROPOSTAS' > LISTAGEM DE ALUNOS
            case "alunosAuto" -> consultarListaPropostas("alunosAuto");
            case "alunosRegistadas" -> consultarListaPropostas("alunosRegistadas");
            case "alunosAtribuidas" -> consultarListaPropostas("alunosAtribuidas");
            case "alunosNaoAtribuidas" -> consultarListaPropostas("alunosNaoAtribuidas");
            //===== 'ORIENTADORES' > LISTAGEM DE DOCENTES
            case "propDocentesAlunos" -> consultarListaPropostas("propDocentesAlunos");
            case "propSemDocentesAlunos" -> consultarListaPropostas("propSemDocentesAlunos");
            case "orientacoes" -> consultarListaPropostas("orientacoes");
            //===== 'CONSULTA'
            case "semPropComCandidatura" -> consultarListaPropostas("semPropComCandidatura");
            case "propostasNaoAtribuidas" -> consultarListaPropostas("propostasNaoAtribuidas");
            case "propostasAtribuidas" -> consultarListaPropostas("propostasAtribuidas");
        }
        return true;
    }

    private void consultarAlunos() {
        if (alunos.isEmpty()) {
            System.out.println("Lista de alunos vazia.");
            return;
        }
        System.out.println("Lista de alunos:\n");
        for (var a : alunos)
            System.out.print(a.toString());
    }

    private void consultarDocentes() {
        if (docentes.isEmpty()) {
            System.out.println("Lista de docentes vazia.");
            return;
        }
        System.out.println("Lista de docentes:\n");
        for (var d : docentes)
            System.out.print(d.toString());
    }

    private void consultarPropostas() {
        if (propostas.isEmpty()) {
            System.out.println("Lista de propostas vazia.");
            return;
        }
        System.out.println("Lista de propostas:\n");
        for (var p : propostas)
            System.out.print(p.toString());
    }

    private void consultarListaPropostas(String op) {
        boolean flg = false;
        switch(op) {
            //========= 'CANDIDATURAS' > LISTAGEM DE ALUNOS
            case "autoproposta":
                if (verificaLista(alunos)) return;
                if (verificaLista(candidaturas)) return;
                if (verificaLista(propostas)) return;
                ArrayList<Long> numerosAluno = new ArrayList<>();
                for (var p : propostas) {
                    for (var c : candidaturas) {
                        for (var cod : c.getCodigos()) {
                            if (p.getCodigo().equals(cod) && p.getTipo().equalsIgnoreCase("T3")
                                    && !numerosAluno.contains(c.getAlunoAtribuido()))
                                numerosAluno.add(c.getAlunoAtribuido());
                        }
                    }
                    if (p.getTipo().equalsIgnoreCase("T3") && p.getAlunoAtribuido() > 0 &&
                            !numerosAluno.contains(p.getAlunoAtribuido()))
                        numerosAluno.add(p.getAlunoAtribuido());
                }
                for (var a : alunos) {
                    if (numerosAluno.contains(a.getNumero())) {
                        System.out.print(a.toString());
                        flg = true;
                    }
                }
                if (!flg)
                    System.out.println("Nao ha alunos com autoproposta.");
                break;
            case "comCandidatura":
                if (verificaLista(alunos)) return;
                if (verificaLista(candidaturas)) return;
                for (var a : alunos) {
                    for (var c : candidaturas)
                        if (a.getNumero() == c.getAlunoAtribuido()) {
                            System.out.print(a.toString());
                            flg = true;
                        }
                }
                if (!flg)
                    System.out.println("Nao ha alunos com candidatura.");
                break;
            case "semCandidatura":
                if (verificaLista(alunos)) return;
                if (verificaLista(candidaturas)) return;
                boolean temCandidatura = false;
                for (var a : alunos) {
                    for (var c : candidaturas)
                        if (a.getNumero() == c.getAlunoAtribuido())
                            temCandidatura = true;
                    if (!temCandidatura) {
                        System.out.print(a.toString());
                        flg = true;
                    }
                    temCandidatura = false;
                }
                if (!flg)
                    System.out.println("Nao ha alunos sem candidatura.");
                break;

            //========= 'PROPOSTAS' > LISTAGEM DE ALUNOS
            case "alunosAuto":  // alunos com autoproposta associada (ainda nao esta atribuida)
                boolean atribuidas = false;
                if (verificaLista(alunos)) return;
                if (verificaLista(propostas)) return;
                for (var a : alunos) {
                    for (var p : propostas)
                        if (a.getNumero() == p.getAlunoAtribuido() && p.getTipo().equalsIgnoreCase("T3")) {
                            System.out.print(a.toString());
                            atribuidas = true;
                        }
                }
                if (!atribuidas)
                    System.out.println("Nao ha autopropostas associadas.");
                break;
            case "alunosRegistadas":    // alunos com candidaturas registadas
                if (verificaLista(alunos)) return;
                if (verificaLista(candidaturas)) return;
                for (var a : alunos) {
                    for (var c : candidaturas)
                        if (a.getNumero() == c.getAlunoAtribuido()) {
                            System.out.print(a.toString());
                            flg = true;
                        }
                }
                if (!flg)
                    System.out.println("Nao ha alunos com candidatura registada.");
                break;
            case "alunosAtribuidas":    // alunos com propostas atribuidas
                if (verificaLista(alunos)) return;
                if (verificaLista(propostasAtribuidas)) return;
                for (var a : alunos) {
                    for (var p : propostasAtribuidas)
                        if (a.getNumero() == p.getAlunoAtribuido()) {
                            System.out.print(a.toString());
                            flg = true;
                        }
                }
                if (!flg)
                    System.out.println("Nao ha alunos com propostas atribuidas.");
                break;
            case "alunosNaoAtribuidas":  // alunos sem propostas atribuidas
                if (verificaLista(alunos)) return;
                // se estiver vazia, nao ha propostas atribuidas > lista todos os alunos
                if (propostasAtribuidas.isEmpty()) {
                    for (var a : alunos)
                        System.out.print(a.toString());
                } else {
                    boolean atribuida = false;
                    for (var a : alunos) {
                        for (var p : propostasAtribuidas)
                            if (a.getNumero() == p.getAlunoAtribuido())
                                atribuida = true;
                        if (!atribuida)
                            System.out.print(a.toString());
                        atribuida = false;
                    }
                }
                break;

            //========= 'ORIENTADORES' > LISTAGEM DE ATRIBUICAO DE DOCENTES
            case "alunosPropDocente":
                if (propostasAtribuidas.isEmpty()) return;
                for (var p : propostasAtribuidas)
                    if (p.getCodigo().equalsIgnoreCase("T2") && p.getAlunoAtribuido() > 0
                    && p.getDocente() != null)
                        System.out.println(p.toString());
                break;
            case "alunosPropSemDocente":
                if (propostasAtribuidas.isEmpty()) return;
                for (var p : propostasAtribuidas)
                    if (p.getCodigo().equalsIgnoreCase("T2") && p.getAlunoAtribuido() > 0
                            && p.getDocente() == null)
                        System.out.println(p.toString());
                break;
            case "orientacoes":
                if (verificaLista(docentes)) return;
                if (verificaLista(propostasAtribuidas)) return;
                Map<String,Integer> orientacoes = new HashMap<>();
                int numOrientacoes = 0, orientadores = 0, min = 9999, max = 0;
                for (var p : propostasAtribuidas) {
                    if (p.getTipo().equalsIgnoreCase("T2") && p.getDocente() != null) {
                        if (!orientacoes.containsKey(p.getDocente())) {
                            orientacoes.put(p.getDocente(), 1);
                            orientadores++;
                            numOrientacoes++;
                        } else {
                            for (var o : orientacoes.entrySet())
                                if (o.getKey().equals(p.getDocente()))
                                    o.setValue(o.getValue()+1);
                            numOrientacoes++;
                        }
                        flg = true;
                    }
                }
                // nao ha propostas com docentes atribuidos
                if (!flg) {
                    System.out.println("Nao ha propostas com docentes atribuidos.");
                    return;
                }
                //  devolve o MENOR numero de orientacoes de um docente
                for (var o : orientacoes.entrySet())
                    if (o.getValue() < min)
                        min = o.getValue();
                //  devolve o MAIOR numero de orientacoes de um docente
                for (var o : orientacoes.entrySet())
                    if (o.getValue() > max)
                        max = o.getValue();
                //  mostra o numero MIN, MAX, MEDIA e por docente (de orientacoes)
                for (var o : orientacoes.entrySet())
                    System.out.println("Docente: " + o.getKey() + ", com " + o.getValue() + " orientacoes.");

                System.out.println("\nMaximo orientacoes: " + max);
                System.out.println("Minimo orientacoes: " + min);
                System.out.println("Media: " + numOrientacoes/orientadores);
                break;

            //========= 'CONSULTA' > LISTAGEM DE ATRIBUICAO DE DOCENTES
            case "semPropComCandidatura":   // alunos sem proposta mas com candidatura
                if (verificaLista(alunos)) return;
                if (verificaLista(candidaturas)) return;
                if (verificaLista(propostasAtribuidas)) return;

                boolean encontrou = false;
                for (var a : alunos) {
                    for (var p : propostasAtribuidas)
                        if (a.getNumero() == p.getAlunoAtribuido())
                            encontrou = true;
                    // se nao tiver proposta atribuida, resta verificar se tem candidatura registada
                    if (!encontrou) {
                        for (var c : candidaturas)
                            if (c.getAlunoAtribuido() == a.getNumero()) {
                                System.out.println(a.toString());
                                flg = true;
                            }
                    }
                    encontrou = false;
                }
                if (!flg)
                    System.out.println("Sem resultados.");
                break;
            case "propostasNaoAtribuidas":     // lista as proposta que ainda nao foram atribuidas
                if (verificaLista(propostas)) return;
                boolean indisponivel = false;
                for (var p : propostas) {
                    for (var pA : propostasAtribuidas)
                        if (p.getCodigo().equals(pA.getCodigo()))
                            indisponivel = true;
                    if (!indisponivel) {
                        System.out.print(p.toString());
                        flg = true;
                    }
                    indisponivel = false;
                }
                if (!flg)
                    System.out.println("Sem resultados.");
                break;
            case "propostasAtribuidas":     // lista as propostas atribuidas
                if (verificaLista(propostas)) return;
                for (var pA : propostasAtribuidas)
                    System.out.print(pA.toString());
                break;
        }
    }

    public boolean consultarFiltros(String opcao,ArrayList<Integer> arr) {
        if (arr.isEmpty())
            return false;

        ArrayList<Proposta> listagem = new ArrayList<>();

        switch(opcao) {
            case "candidatura":
                //========= 'CANDIDATURAS' > LISTAGEM COM FILTROS
                for (var a : arr) {
                    switch (a) {
                        case 1:   // lista de autopropostas de alunos
                            if (verificaLista(propostas)) return false;
                            for (var p : propostas)
                                if (p.getTipo().equalsIgnoreCase("T3") && p.getAlunoAtribuido() > 0)
                                    if (!listagem.contains(p))
                                        listagem.add(p);
                            break;
                        case 2:   // lista de propostas de docentes
                            if (verificaLista(propostas)) return false;
                            for (var p : propostas)
                                if (p.getDocente() != null && p.getTipo().equalsIgnoreCase("T2"))
                                    if (!listagem.contains(p))
                                        listagem.add(p);
                            break;
                        case 3:   // lista de propostas com candidaturas
                            if (verificaLista(propostas)) return false;
                            if (verificaLista(candidaturas)) return false;
                            ArrayList<String> tmp = new ArrayList<>();
                            for (var c : candidaturas)
                                for (var cod : c.getCodigos())
                                    if (!tmp.contains(cod))
                                        tmp.add(cod);
                            for (var p : propostas)
                                if (tmp.contains(p.getCodigo()) && !listagem.contains(p))
                                    listagem.add(p);
                            break;
                        case 4:   // lista de propostas sem candidaturas
                            if (verificaLista(propostas)) return false;
                            if (verificaLista(candidaturas)) return false;
                            boolean semCandidatura = false;
                            for (var p : propostas) {
                                for (var c : candidaturas)
                                    for (int i = 0; i < c.getCodigos().size(); i++)
                                        if (p.getCodigo().equals(c.getCodigos().get(i)))
                                            semCandidatura = true;
                                if (!semCandidatura && !listagem.contains(p))    // se nao encontrou, mostra no ecra
                                    listagem.add(p);
                                semCandidatura = false;
                            }
                            break;
                    }
                }
                break;
            case "proposta":
                //========= 'PROPOSTAS' > LISTAGEM DE PROPOSTAS (C/ FILTROS) PROJETO/ESTAGIO
                for (var a : arr) {
                    switch(a) {
                        case 1:     // lista propostas com autoproposta associada
                            if (verificaLista(propostas)) return false;
                            for (var p : propostas)
                                if (p.getTipo().equalsIgnoreCase("T3"))
                                    if (!listagem.contains(p))
                                        listagem.add(p);
                            break;
                        case 2:     // lista propostas feitas por docentes
                            if (verificaLista(propostas)) return false;
                            for (var p : propostas)
                                if (p.getTipo().equalsIgnoreCase("T2") && p.getDocente() != null)
                                    if (!listagem.contains(p))
                                        listagem.add(p);
                            break;
                        case 3:     // lista as proposta que ainda nao foram atribuidas
                            if (verificaLista(propostas)) return false;
                            boolean indisponivel = false;
                            for (var p : propostas) {
                                for (var pA : propostasAtribuidas)
                                    if (p.getCodigo().equals(pA.getCodigo()))
                                        indisponivel = true;
                                if (!indisponivel && !listagem.contains(p))
                                    listagem.add(p);
                                indisponivel = false;
                            }
                            break;
                        case 4:     // lista as propostas atribuidas
                            if (verificaLista(propostas)) return false;
                            boolean repetida = false;
                            for (var pA : propostasAtribuidas) {
                                for (var l : listagem)
                                    if (l.getCodigo() == pA.getCodigo())
                                        repetida = true;
                                if (!repetida)
                                    listagem.add(pA);
                                repetida = false;
                            }
                            break;
                    }
                }
                break;
        }
        if (listagem.isEmpty()) {
            System.out.println("Sem resultados.");
            return false;
        }
        // lista as propostas sem repeticao
        for (var l : listagem)
            System.out.print(l.toString());
        return true;
    }

    // usada para fechar o estado de proposta (todos os alunos com candidaturas devem ter propostas atribuidas)
    public boolean consultaAtribuicoes() {
        if (verificaLista(alunos)) return false;
        ArrayList<Long> tmp = new ArrayList<>();
        for (var c : candidaturas)
            tmp.add(c.getAlunoAtribuido());
        for (var p : propostasAtribuidas)
            if (!tmp.contains(p.getAlunoAtribuido()))   // candidatura sem proposta atribuida
                return false;
        return true;
    }

    public boolean atribuicaoAutomatica(String str) {
        switch(str) {
            case "autodocentes" -> atribuicaoAutomaticaAlunoAssoc();
            case "alunosSemAtribuicoes" -> atribuicaoAutomaticaAlunoNAssoc();
            case "projdocentes" -> atribuicaoAutomaticaDocente();
        }
        return true;
    }

    //============================= ATRIBUICAO PROPOSTAS ALUNOS =============================
    private void atribuicaoAutomaticaAlunoAssoc() {
        if (candidaturaFechada) {
            System.out.println("Ja nao e possivel fazer atribuicoes, a fase de candidatura fechou.");
            return;
        }

        if (verificaLista(alunos)) return;
        if (verificaLista(propostas)) return;

        // atribuicao automatica das autopropostas
        for (var p : propostas) {
            if (p.getTipo().equalsIgnoreCase("T3") && p.getAlunoAtribuido() > 0) {
                for (var a : alunos)
                    if (a.getNumero() == p.getAlunoAtribuido()) {
                        Proposta tmp = new Autoproposto(p.getTipo(),p.getCodigo(),p.getTitulo());
                        tmp.setAlunoAtribuido(a.getNumero());
                        propostasAtribuidas.add(tmp);
                        System.out.println("Proposta '" + p.getCodigo() + "' atribuida ao aluno '" + a.getNumero() + "'.");
                    }
            }
        }

        // para atribuir docentes verifica primeiro se a lista esta vazia
        if (verificaLista(docentes)) return;

        // atribuicao automatica dos propostas de docentes com aluno atribuido
        for (var p : propostas) {
            if (p.getTipo().equalsIgnoreCase("T2") && p.getDocente() != null && p.getAlunoAtribuido() > 0) {
                propostasAtribuidas.add(p);
                System.out.println("Proposta '" + p.getCodigo() + "' com o docente '" + p.getDocente() +
                        "' atribuida ao aluno '" + p.getAlunoAtribuido() + "'.");
            }
        }
    }

    private void atribuicaoAutomaticaAlunoNAssoc() {
        if (candidaturaFechada) {
            System.out.println("Ja nao e possivel fazer atribuicoes, a fase de candidatura fechou.");
            return;
        }

        boolean temAluno = false;
        int preferencia = 0;

        // primeiro atribui os alunos que tem candidatura registada
        for (var c : candidaturas) {
            preferencia = 0;
            // verifica se esta candidatura ja foi atribuida
            for (var pA : propostasAtribuidas)
                if (c.getAlunoAtribuido() == pA.getAlunoAtribuido())
                    temAluno = true;

            // se a candidatura ainda nao tiver sido atribuida
            if (!temAluno) {
                Aluno aluno = null;
                for (var a : alunos)
                    if (a.getNumero() == c.getAlunoAtribuido())
                        aluno = a;
                for (int i = 0; i < c.getCodigos().size(); i++) {   // avalia propostas por ordem de preferencia
                    preferencia = i + 1;
                    for (var p : propostas) {
                        // se o codigo da proposta for igual ao codigo da candidatura e nao tiver um aluno atribuido
                        if (p.getCodigo().equals(c.getCodigos().get(i)) && p.getAlunoAtribuido() == 0) {
                            if (restricoesAluno(aluno,preferencia,p)) {   // se 'true': vai ser atribuido
                                switch(p.getTipo()) {
                                    case "T1":
                                        Proposta estagio = new Estagio(p.getTipo(),p.getCodigo(),p.getRamoDestino(),
                                                p.getTitulo(),p.getEntAcolhimento(),aluno.getNumero());
                                        propostasAtribuidas.add(estagio);
                                        break;
                                    case "T2":
                                        Proposta projeto = new Projeto(p.getTipo(),p.getCodigo(),p.getRamoDestino(),
                                                p.getTitulo(),p.getDocente(),aluno.getNumero());
                                        propostasAtribuidas.add(projeto);
                                        break;
                                    case "T3":
                                        Proposta auto = new Autoproposto(p.getTipo(),p.getCodigo(),p.getTitulo());
                                        auto.setAlunoAtribuido(aluno.getNumero());
                                        propostasAtribuidas.add(auto);
                                        break;
                                }
                                System.out.println("Proposta '" + p.getCodigo() + "' foi atribuida ao aluno '" + aluno.getNumero()
                                        + "'.");
                            }
                        }
                    }
                }
            }
            temAluno = false;
        }

        // fazer atribuicao de uma proposta disponivel aos alunos sem candidatura e sem proposta associada
        boolean atribuida = false;
        boolean candidatura = false;
        boolean disponivel = true;
        for (var a : alunos) {
            for (var c : candidaturas)
                if (a.getNumero() == c.getAlunoAtribuido())
                    candidatura = true;
            for (var p : propostasAtribuidas)
                if (a.getNumero() == p.getAlunoAtribuido())
                    atribuida = true;

            if (!candidatura && !atribuida) {
                for (var p : propostas) {
                    // verifica se a proposta ja foi atribuida
                    for (var pA : propostasAtribuidas)
                        if (p.getCodigo().equals(pA.getCodigo()))
                            disponivel = false;
                    // caso esteja disponivel verifica as condicoes do aluno em relacao ao estagio
                    if (disponivel) {
                        if (a.isEstagio() && p.getTipo().equals("T1")) {
                            Proposta estagio = new Estagio(p.getTipo(),p.getCodigo(),p.getRamoDestino(),
                                    p.getTitulo(),p.getEntAcolhimento(),a.getNumero());
                            propostasAtribuidas.add(estagio);
                            System.out.println("Proposta '" + p.getCodigo() + "' foi atribuida ao aluno '" + a.getNumero()
                                    + "'.");
                            break;
                        }
                        else if (!a.isEstagio() && p.getTipo().equals("T2")) {
                            Proposta projeto = new Projeto(p.getTipo(),p.getCodigo(),p.getRamoDestino(),
                                    p.getTitulo(),p.getDocente(),a.getNumero());
                            propostasAtribuidas.add(projeto);
                            System.out.println("Proposta '" + p.getCodigo() + "' foi atribuida ao aluno '" + a.getNumero()
                                    + "'.");
                            break;
                        }
                    }
                    disponivel = true;
                }
            }
            candidatura = false;
            atribuida = false;
        }
    }

    private boolean restricoesAluno(Aluno aluno,int preferencia,Proposta proposta) {
        boolean atribuido = false;
        for (var a : alunos) {
            if (!a.equals(aluno)) {
                for (var p : propostasAtribuidas)
                    if (p.getAlunoAtribuido() == a.getNumero())
                        atribuido = true;
                if (!atribuido) {
                    switch (proposta.getTipo()) {
                        case "T1":  // restricao de estagio
                            // se 'false': outro aluno com estagio tem melhor classicacao e esta candidatado a mesma proposta
                            if (a.isEstagio() && a.getClassificacao() > aluno.getClassificacao())
                                return false;
                            // em caso de empate, o user deve escolher
                            else if (a.isEstagio() && a.getClassificacao() == aluno.getClassificacao()) {
                                for (var c : candidaturas) {
                                    if (c.getAlunoAtribuido() == a.getNumero()) {
                                        for (int i = 0; i < c.getCodigos().size(); i++) {
                                            if (c.getCodigos().get(i).equals(proposta.getCodigo()) && preferencia == i + 1) {
                                                if (escolherAluno(aluno, a))
                                                    return true;
                                                return false;
                                            }
                                        }
                                    }
                                }
                            }
                            break;
                        case "T2":  // restricao de projeto
                            // se 'false': outro aluno com projeto tem melhor classicacao e esta candidatado a mesma proposta
                            if (!a.isEstagio() && a.getClassificacao() > aluno.getClassificacao())
                                return false;
                                // em caso de empate, o user deve escolher
                            else if (!a.isEstagio() && a.getClassificacao() == aluno.getClassificacao()) {
                                for (var c : candidaturas) {
                                    if (c.getAlunoAtribuido() == a.getNumero()) {
                                        for (int i = 0; i < c.getCodigos().size(); i++) {
                                            if (c.getCodigos().get(i).equals(proposta.getCodigo()) && preferencia == i + 1) {
                                                if (escolherAluno(aluno, a))
                                                    return true;
                                                return false;
                                            }
                                        }
                                    }
                                }
                            }
                            break;
                    }
                }
                atribuido = false;
            }
        }
        return true;
    }

    private boolean escolherAluno(Aluno a1,Aluno a2) {
        int op;
        do {
            op = 0;
            System.out.println("Houve um empate entre:\n");
            System.out.println("1 - " + a1.toString());
            System.out.println("2 - " + a2.toString());
            op = PAInput.readInt("Qual escolhe? ");
            switch (op) {
                case 1 -> { return true; }
                case 2 -> { return false; }
            }
        } while (op != 1 && op != 2);
        return false;
    }

    public boolean atribuicaoManualAluno(String codigo, Long numAluno) {
        if (verificaLista(alunos)) return false;
        if (verificaLista(candidaturas)) return false;
        if (verificaLista(propostas)) return false;

        if (!verificaCodigo(codigo)) return false;
        if (!verificaNumero(numAluno)) return false;
        if (!verificaAlunoCandidatura(numAluno)) return false;

        // verifica se a fase de candidaturas esta fechada
        if (candidaturaFechada) {
            System.out.println("\nJa nao e possivel fazer atribuicoes, a fase de candidatura fechou\n");
            return false;
        }

        // se a lista de propostas atribuidas ja tiver esta proposta
        for (var p : propostasAtribuidas) {
            if (p.getCodigo().equals(codigo)) {
                System.out.println("\nProposta com o codigo '" + codigo + "' ja esta atribuida.");
                return false;
            } else if (p.getAlunoAtribuido() == numAluno) {
                System.out.println("\nAluno '" + numAluno + "' ja tem uma proposta atribuida.");
                return false;
            }
        }

        // se ainda nao foi atribuida, verifica se a proposta esta disponivel (nao esta associada)
        for (var p : propostas) {
            if (p.getCodigo().equals(codigo) && p.getAlunoAtribuido() == 0) {
                switch(p.getTipo()) {
                    case "T1":
                        Proposta estagio = new Estagio(p.getTipo(),p.getCodigo(),p.getRamoDestino(),
                                p.getTitulo(),p.getEntAcolhimento(),numAluno);
                        propostasAtribuidas.add(estagio);
                        break;
                    case "T2":
                        Proposta projeto = new Projeto(p.getTipo(),p.getCodigo(),p.getRamoDestino(),
                                p.getTitulo(),p.getDocente(),numAluno);
                        propostasAtribuidas.add(projeto);
                        break;
                    case "T3":
                        Proposta auto = new Autoproposto(p.getTipo(),p.getCodigo(),p.getTitulo());
                        auto.setAlunoAtribuido(numAluno);
                        propostasAtribuidas.add(auto);
                        break;
                }
                System.out.println("A proposta '" + codigo + "' foi atribuida ao aluno '" + numAluno + "'.");
                return true;
            }
        }
        return false;
    }

    public boolean remocaoManualAluno(String codigo, Long numAluno) {
        if (verificaLista(alunos)) return false;
        if (verificaLista(candidaturas)) return false;
        if (verificaLista(propostas)) return false;

        if (!verificaCodigo(codigo)) return false;
        if (!verificaNumero(numAluno)) return false;
        if (!verificaAlunoCandidatura(numAluno)) return false;

        // verifica se a fase de candidaturas esta fechada
        if (candidaturaFechada) {
            System.out.println("\nJa nao e possivel fazer remocoes, a fase de candidatura fechou\n");
            return false;
        }

        for (var p : propostasAtribuidas) {
            if (p.getCodigo().equals(codigo) && p.getAlunoAtribuido() == numAluno) {
                propostasAtribuidas.remove(p);
                System.out.println("\nA proposta '" + codigo + "' foi removida ao aluno '" + numAluno + "'.");
                return true;
            }
        }

        return false;
    }

    //============================= ATRIBUICAO DOCENTES =============================
    private boolean atribuicaoAutomaticaDocente() {
        if (verificaLista(docentes)) return false;
        if (verificaLista(propostas)) return false;

        boolean atribuida = false;
        int atribuicoes = 0;
        for (var p : propostas) { // lista de propostas de projeto sem docente
            if (p.getTipo().equalsIgnoreCase("T2") && p.getDocente() != null) {
                for (var pA : propostasAtribuidas) {  // verifica se a proposta ja esta atribuida a um docente
                    if (pA.getCodigo().equals(p.getCodigo()) && pA.getDocente() != null && pA.getDocente().equals(p.getDocente()))
                        atribuida = true;
                    else if (pA.getCodigo().equals(p.getCodigo()) && pA.getDocente() == null) {
                        atribuida = true;
                        atribuicoes++;
                        pA.setDocente(p.getDocente());
                        System.out.println("Proposta '" + p.getCodigo() + "' atribuida ao docente '" + p.getDocente() + "'.");
                    }
                }
                if (!atribuida) {
                    propostasAtribuidas.add(p);
                    atribuicoes++;
                    System.out.println("Proposta '" + p.getCodigo() + "' atribuida ao docente '" + p.getDocente() + "'.");
                }
                atribuida = false;
            }
        }
        if (atribuicoes == 0) {
            System.out.println("Nao ha atribuicoes a serem feitas.");
            return false;
        }
        return true;
    }

    public boolean atribuicaoManualDocente(String codigo, String email) {
        if (verificaLista(docentes)) return false;
        if (verificaLista(propostas)) return false;

        if (!verificaCodigo(codigo)) return false;
        if (!verificaEmail(email)) return false;

        // verifica se a proposta ja foi atribuida a um docente
        for (var pA : propostasAtribuidas) {
            if (pA.getCodigo().equals(codigo) && pA.getTipo().equalsIgnoreCase("T2") && pA.getDocente() != null) {
                System.out.println("\nProposta '" + codigo + "' ja esta atribuida ao docente '" + pA.getDocente() + "'.");
                return false;
            } else if (pA.getCodigo().equals(codigo) && pA.getTipo().equalsIgnoreCase("T2") && pA.getDocente() == null) {
                pA.setDocente(email);
                System.out.println("Proposta '" + codigo + "' atribuida ao docente '" + email + "'.");
                return true;
            }
        }

        // lista de propostas de projeto sem docente
        for (var p : propostas) {
            if (p.getCodigo().equals(codigo) && !p.getTipo().equalsIgnoreCase("T2")) {
                System.out.println("Proposta '" + codigo + "' nao e do tipo projeto.");
                return true;
            } else if (p.getCodigo().equals(codigo) && p.getTipo().equalsIgnoreCase("T2")) {
                Proposta projeto = new Projeto(p.getTipo(),p.getCodigo(),p.getRamoDestino(),p.getTitulo(),email,p.getAlunoAtribuido());
                propostasAtribuidas.add(p);
                System.out.println("Proposta '" + codigo + "' atribuida ao docente '" + email + "'.");
                return true;
            }

        }

        return false;
    }

    public boolean remocaoManualDocente(String codigo, String email) {
        if (verificaLista(docentes)) return false;
        if (verificaLista(propostas)) return false;
        if (verificaLista(propostasAtribuidas)) return false;

        if (!verificaCodigo(codigo)) return false;
        if (!verificaEmail(email)) return false;

        for (var p : propostasAtribuidas) {
            // se existir um aluno atribuido a proposta, apenas remove o docente
            if (p.getCodigo().equals(codigo) && p.getDocente().equals(email) && p.getAlunoAtribuido() > 0) {
                p.setDocente(null);
                System.out.println("Docente '" + email + "' associado a proposta '" + codigo + "' removido com sucesso.");
                return true;
            }
            // se nao existir nenhum aluno remove a proposta da lista
            else if (p.getCodigo().equals(codigo) && p.getDocente().equals(email) && p.getAlunoAtribuido() == 0) {
                propostasAtribuidas.remove(p);
                System.out.println("Docente '" + email + "' associado a proposta '" + codigo + "' removido com sucesso.");
                return true;
            }
        }

        return false;
    }

    public boolean consultarDocenteProp(String email) {
        if (!verificaEmail(email)) return false;
        if (verificaLista(propostasAtribuidas)) return false;

        for (var p : propostasAtribuidas) {
            if (p.getTipo().equalsIgnoreCase("T2") && p.getDocente() != null && p.getDocente().equals(email)) {
                System.out.println("\nProposta associada ao docente '" + email + "': " + p.toString());
                return true;
            }
        }
        System.out.println("\nDocente '" + email + "' nao tem nenhuma proposta associada.");
        return false;
    }

    public boolean alterarDocenteProp(String email, String codigo) {
        if (!verificaEmail(email)) return false;
        if (!verificaCodigo(codigo)) return false;

        for (var p : propostasAtribuidas) {
            if (p.getCodigo().equals(codigo)) {
                p.setDocente(email);
                System.out.println("\nDocente '" + email + "' associado a proposta '" + codigo + "'.");
                return true;
            }
        }
        return false;
    }

    /*======================== MODIFICACAO > ALUNOS ========================*/
    public boolean modificarAluno(long numero, String op, Object obj) {
        if (!verificaNumero(numero))
            return false;
        for (var a : alunos) {
            if (a.getNumero() == numero) {
                switch(op) {
                    case "nome" -> a.setNome((String) obj);
                    case "curso" -> a.setSiglaCurso((String) obj);
                    case "ramo" -> a.setSiglaRamo((String) obj);
                    case "classif" -> a.setClassificacao((Double) obj);
                    case "estagio" -> a.setEstagio((Boolean) obj);
                }
            }
        }
        return true;
    }

    public boolean eliminaAluno(long numero) {
        if (!verificaNumero(numero))
            return false;
        for (var a : alunos)
            if (a.getNumero() == numero)
                alunos.remove(a);
        for (var p : propostas) // deixa de existir o aluno atribuido
            if (p.getAlunoAtribuido() == numero)
                p.setAlunoAtribuido(0);
        for (var c : candidaturas)  // deixa de existir o aluno atribuido
            if (c.getAlunoAtribuido() == numero)
                candidaturas.remove(c);
        System.out.println("\nO aluno com o numero '" + numero + "' foi eliminado com sucesso.\n");
        return true;
    }

    /*======================== MODIFICACAO > DOCENTES ========================*/
    public boolean modificarDocente(String email, String op, Object obj) {
        if (!verificaEmail(email))
            return false;
        for (var d : docentes) {
            if (d.getEmail().equals(email)) {
                switch(op) {
                    case "nome" -> d.setNome((String) obj);
                }
            }
        }
        return true;
    }

    public boolean eliminaDocente(String email) {
        if (!verificaEmail(email))
            return false;
        for (var d : docentes)
            if (d.getEmail().equals(email))
                docentes.remove(d);
        for (var p : propostas) // deixa de existir o docente responsavel
            if (p.getDocente().equals(email))
                p.setDocente(null);
        System.out.println("\nDocente eliminado com sucesso.\n");
        return true;
    }

    /*======================== MODIFICACAO > PROPOSTAS ========================*/
    public boolean modificarProposta(String codigo, String op, Object obj) {
        if (!verificaCodigo(codigo))
            return false;
        for (var p : propostas) {
            if (p.getCodigo().equals(codigo)) {
                switch(op) {
                    case "titulo" -> p.setTitulo((String) obj);
                    case "ramo" -> p.setRamoDestino((String) obj);
                    case "entAcolh" -> p.setEntAcolhimento((String) obj);
                    case "aluno" -> p.setAlunoAtribuido((Long) obj);
                }
            }
        }
        return true;
    }

    public boolean eliminaProposta(String codigo) {
        if (!verificaCodigo(codigo))
            return false;
        for (var c : propostas)
            if (c.getCodigo().equals(codigo))
                propostas.remove(c);
        for (var c : candidaturas)  // deixa de existir essa proposta
            if (c.getCodigos().contains(codigo))
                candidaturas.remove(c);
        System.out.println("\nProposta e candidaturas associadas eliminadas com sucesso.\n");
        return true;
    }

    /*======================== MODIFICACAO > CANDIDATURAS ========================*/
    public boolean modificarCandidatura(Long numero, String op, String codigo) {
        if (!verificaAlunoCandidatura(numero))
            return false;
        switch (op) {
            case "add" -> {
                boolean alunoAtribuido = false;
                for (var p : propostas)
                    if (p.getCodigo().equals(codigo) && p.getAlunoAtribuido() > 0)
                        alunoAtribuido = true;
                if (!alunoAtribuido) {
                    for (var c : candidaturas) {
                        if (c.getAlunoAtribuido() == numero) {
                            c.setCodigo(codigo);
                            System.out.println("\nCodigo de proposta adicionado ao aluno '" + numero + "' com sucesso.");
                        }
                    }
                }
            }
            case "rm" -> {
                for (var c : candidaturas) {
                    // se so tiver um codigo e for igual ao inserido, remove a candidatura
                    if (c.getAlunoAtribuido() == numero && c.getCodigos().size() == 1 && c.getCodigos().contains(codigo)) {
                        candidaturas.remove(c);
                        System.out.println("\nCandidatura do aluno '" + numero + "' removida com sucesso.");
                        break;
                    } else if (c.getAlunoAtribuido() == numero && c.getCodigos().size() > 1) {
                        for (var cod : c.getCodigos()) {
                            if (cod.equals(codigo)) {
                                c.getCodigos().remove(cod);
                                System.out.println("\nCodigo '" + codigo + "' da candidatura do aluno '" + numero + "' removido com sucesso.");
                                break;
                            }
                        }
                    }
                }
            }
        }
        return true;
    }

    public boolean eliminaCandidatura(Long numero) {
        if (!verificaNumero(numero))
            return false;
        if (!verificaAlunoCandidatura(numero))
            return false;
        for (var c : candidaturas) {
            if (c.getAlunoAtribuido() == numero) {
                candidaturas.remove(c);
                System.out.println("\nCandidatura eliminada com sucesso.");
                return true;
            }
        }
        return true;
    }

    /*======================== Verificacao dos Parametros de Valor Unico ========================*/
    public boolean verificaNumero(long numero) {   // numero alunos
        if (numero < 0) {
            System.out.println("\nO numero de aluno inserido deve ser > 0.");
            return false;
        }
        if (!alunos.isEmpty()) {
            for (var a : alunos)
                if (a.getNumero() == numero)
                    return true;
            System.out.println("Nao existe nenhum aluno com o numero '" + numero + "'.");
            return false;
        }
        System.out.println("\nA lista de alunos esta vazia.");
        return false;
    }

    public boolean verificaEmail(String email) {   // email docentes
        if (email == null)
            return false;
        if (!docentes.isEmpty()) {
            for (var d : docentes)
                if (d.getEmail().equals(email))
                    return true;
            System.out.println("Nao existe nenhum docente com o email '" + email + "'.");
            return false;
        }
        System.out.println("\nA lista de docentes esta vazia.\n");
        return false;
    }

    private boolean verificaCodigo(String codigo) { // codigo propostas
        if (!propostas.isEmpty()) {
            for (var p : propostas)
                if (p.getCodigo().equals(codigo))
                    return true;
            System.out.println("\nO codigo inserido nao existe.\n");
            return false;
        }
        System.out.println("\nA lista de propostas esta vazia.\n");
        return false;
    }

    private boolean verificaAlunoCandidatura(Long numero) {
        if (!candidaturas.isEmpty()) {
            for (var c : candidaturas)
                if (c.getAlunoAtribuido() == numero)
                    return true;
            System.out.println("\nO numero inserido nao existe.\n");
            return false;
        }
        System.out.println("\nA lista de candidaturas esta vazia.\n");
        return false;
    }

    /*======================== Verifica Listas ========================*/
    private boolean verificaLista(Object obj) {
        if (obj.equals(alunos) && alunos.isEmpty())
            System.out.println("Lista de alunos vazia.");
        else if (obj.equals(docentes) && docentes.isEmpty())
            System.out.println("Lista de docentes vazia.");
        else if (obj.equals(propostas) && propostas.isEmpty())
            System.out.println("Lista de propostas vazia.");
        else if (obj.equals(candidaturas) && candidaturas.isEmpty())
            System.out.println("Lista de candidaturas vazia.");
        else if (obj.equals(propostasAtribuidas) && propostasAtribuidas.isEmpty())
            System.out.println("Lista de propostas atribuidas vazia.");
        else
            return false;
        return true;
    }
}