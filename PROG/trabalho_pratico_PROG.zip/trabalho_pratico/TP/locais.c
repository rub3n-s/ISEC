/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   locais.c
 * Author: rubensantos
 * 
 * Created on 29 de Maio de 2020, 12:24
 */

#include "locais.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void initRandom() {
    srand(time(NULL));
}

int intUniformRnd(int a, int b) {
    return a + rand() % (b - a + 1);
}

int probEvento(float prob) {
    return prob > ((float) rand() / RAND_MAX);
}

int menu() {
    int op;

    printf("\n1 - Avançar 1 iteração\n");
    printf("2 - Recuar 1 iteração\n");
    printf("3 - Apresentar estatística\n");
    printf("4 - Adicionar doente\n");
    printf("5 - Transferir pessoas\n");
    printf("6 - Terminar simulação\n");
    printf("Opção: ");
    scanf("%d", &op);
    puts("\n");

    return op;
}

void criaFicheiroEspaco() {
    FILE *f;
    char nome[10];

    printf("Nome do espaço: ");
    scanf("%9s", nome);

    if ((f = fopen(nome, "wb")) != NULL) {
        fprintf(f, "Local: 1 Capacidade: 50\n");
        fprintf(f, "Local: 2 Capacidade: 50\n");
        fprintf(f, "Local: 3 Capacidade: 50\n");

        fclose(f);
    } else {
        printf("Erro com o ficheiro para escrita\n");
    }
}

void mostraSalas(char* nome) {
    FILE *f;
    local *aux;
    char c;

    printf("-----------------------------------\n");
    printf("\t      Salas:\n");
    printf("-----------------------------------\n");
    if ((f = fopen(nome, "rb")) != NULL) {
        while ((c = fgetc(f)) != EOF)
            putchar(c);

        fclose(f);
    } else {
        printf("Erro com o ficheiro %s para leitura\n", nome);
    }
}

void mostraEspaco(plocal p, local *l) {
    ppessoa aux;

    printf("\n-----------------------------------\n");
    printf("\t     Espaços:\n");
    printf("-----------------------------------");
    while (p != NULL) {
        printf("\nLocal: %d\n", p->id);
        aux = p->lista;
        while (aux != NULL) {
            if (aux->estado == 'D')
                printf("%s %d %c %d\n", aux->nome, aux->idade, aux->estado, aux->dias);
            else
                printf("%s %d %c\n", aux->nome, aux->idade, aux->estado);
            aux = aux->prox;
        }
        p = p->prox;
    }
}

void lerNumeroLocais(char*nome, int *nrlocais) {
    FILE *f;
    local c;
    *nrlocais = 0;

    f = fopen(nome, "rb");

    if ((f = fopen(nome, "rb")) != NULL) {
        while (fread(&c, sizeof (local), 1, f))
            (*nrlocais)++;

        fclose(f);
    } else {
        printf("Erro com o ficheiro %s para leitura\n", nome);
        return;
    }
}

void lerNumeroPessoas(char*nome, int *nrpessoas) {
    FILE *f;
    char c;
    *nrpessoas = 1;

    f = fopen(nome, "rt");

    if ((f = fopen(nome, "rt")) != NULL) {
        for (c = getc(f); c != EOF; c = getc(f)) {
            if (c == '\n')
                (*nrpessoas)++;
        }
        fclose(f);
    } else {
        printf("Erro com o ficheiro %s para leitura\n", nome);
        return;
    }
}

local* lerFicheiroLocais(char* fichEspaco) {
    FILE*f;
    local *l = NULL;
    int nrlocais = 0;

    lerNumeroLocais(fichEspaco, &nrlocais);

    printf("Nº Locais: %d\n\n", nrlocais);

    l = malloc(sizeof (local) * nrlocais);
    if (l == NULL) {
        printf("Erro a alocar a memória!\n");
        return l;
    }

    if ((f = fopen(fichEspaco, "rb")) != NULL) {
        for (int i = 0; i < nrlocais; i++) {
            fscanf(f, "Local: %d Capacidade: %d\n", &l[i].id, &l[i].capacidade);

            if (l[i].id < 0) {
                printf("Apenas ID's positivos são permitidos!\n");
                return 0;
            }
        }
        fclose(f);
    } else {
        printf("Erro com o ficheiro %s para leitura\n", fichEspaco);
        return l;
    }

    for (int i = 0; i < nrlocais; i++) // ciclo apenas para verificar "l" guardou os valores
        printf("Local: %d Capacidade: %d\n", l[i].id, l[i].capacidade);
    puts("\n");

    return l;
}

pessoa* lerFicheiroPessoas(char *nome) {
    FILE *f;
    pessoa *p = NULL;
    int nrpessoas = 0;

    lerNumeroPessoas(nome, &nrpessoas);

    p = malloc(sizeof (pessoa) * nrpessoas);
    if (p == NULL) {
        printf("Erro a alocar a memória!\n");
        return p;
    }

    if ((f = fopen(nome, "rt")) != NULL) {
        for (int i = 0; i < nrpessoas; i++) {
            fscanf(f, "%s %d %c ", p[i].nome, &p[i].idade, &p[i].estado);

            if (p[i].estado == 'D')
                fscanf(f, "%d", &p[i].dias);

            if (p[i].idade < 0 || (p[i].estado != 'S' && p[i].estado != 'I' && p[i].estado != 'D')) {
                printf("Erro na leitura do ficheiro %s, o ficheiro contém dados inválidos\n", nome);
                return 0;
            }
        }
        fclose(f);
    } else {
        printf("Erro com o ficheiro %s para leitura\n", nome);
        return p;
    }

    printf("-----------------------------------\n");
    printf("\tFicheiro Pessoas: \n");
    printf("-----------------------------------\n");
    for (int j = 0; j < nrpessoas; j++) {
        if (p[j].estado == 'D')
            printf("%s %d %c %d\n", p[j].nome, p[j].idade, p[j].estado, p[j].dias);
        else
            printf("%s %d %c \n", p[j].nome, p[j].idade, p[j].estado);
    }
    return p;
}

plocal inicializaEspaco(char* fichEspaco, local *l, pessoa *p) {
    FILE *f;
    plocal lista = NULL, novoL;
    ppessoa novaP;
    int nrlocais = 0, npessoas = 0, nrand = 0, k = 0;

    if ((f = fopen(fichEspaco, "rb")) != NULL) {
        lerNumeroPessoas("pessoasA.txt", &npessoas); // função para obter o numero de pessoas ao ler o ficheiro e guardar na variavel npessoas      
        nrand = intUniformRnd(1, npessoas); // função que devolve um numero uniforme consoante o numero de pessoas        
        lerNumeroLocais(fichEspaco, &nrlocais); // função que lê o ficheiro locais para obter o numero de locais na função de inicialização

        //printf("\nNumero pessoas -> %d", npessoas);
        //printf("nrand = %d\n", nrand);

        for (int i = 0; i < nrlocais; i++) { // percorre o numero de locais obtido na função lerNumeroLocais
            novoL = malloc(sizeof (local));
            if (novoL == NULL) {
                libertaTudo(lista);
                return NULL;
            }

            *novoL = l[i];
            for (int j = 0; j < nrand; j++) { // percorre as 'n' pessoas geradas pela função intUniformRnd

                novaP = malloc(sizeof (pessoa));
                if (novaP == NULL) {
                    libertaTudo(lista);
                    return NULL;
                }
                *novaP = p[k++];
                novaP->prox = novoL->lista;
                novoL->lista = novaP;

            }
            novoL->prox = lista;
            lista = novoL;
        }
        fclose(f);
    } else {
        printf("Erro com o ficheiro %s para leitura\n", fichEspaco);
        return lista;
    }

    return lista;
}

void libertaPessoas(ppessoa p) {
    ppessoa aux;

    while (p != NULL) {
        aux = p;
        p = p->prox;
        free(aux);
    }
}

void libertaTudo(plocal p) {
    plocal aux;

    while (p != NULL) {
        libertaPessoas(p->lista);
        aux = p;
        p = p->prox;
        free(aux);
    }
}

void modeloPropagacao(plocal p) {
    ppessoa aux;

    float taxaD; // taxa de disseminação, 5% do total de pessoas no local
    float probR; // probabilidade de recuperação
    float duracaoMax; // duração máxima doente: 5 dias + 1*(nº de dezenas da idade da pessoa)
    float probImune = 0.2; // prob de ficar imune, caso se recupere (não volta a contrair a doença)

    while (p != NULL) {
        taxaD = 0.05 * 2;
        aux = p->lista;

        while (aux != NULL) {
            duracaoMax = 0; // inicializa a variavel a 0 cada vez que se percorre uma pessoa

            if (aux->estado == 'D') {
                /*if (probEvento(taxaD) == 1) // probabilidade de passar a um dos membros da sala
                    aux->prox->estado = 'D'; */

                probR = 1 / aux->idade;

                if (probEvento(probR) == 1) { // caso se recupere, estado = 'S'
                    aux->estado = 'S';
                    printf("%s, atingiu a probabilidade de recuperação\n", aux->nome);

                    if (probEvento(probImune) == 1) { // caso se recupere, tem 20% de chance de ficar imune (estado 'I')
                        aux->estado = 'I';
                        printf("%s, tornou-se imune\n", aux->nome);
                    }
                }

                duracaoMax = 5 + 1 * (aux->idade / 10); // duração maxima da infeção
                printf("%s, duração max de %.0f dias\n", aux->nome, duracaoMax);
                if (duracaoMax <= aux->dias) { // caso a duracaoMax for menor ou igual que o numero de dias infetado, torna-se saudavel 'S'
                    aux->estado = 'S';
                    printf("%s, recuperou passando o limite maximo de dias infetado\n", aux->nome);

                    if (probEvento(probImune) == 1) { // caso se recupere, tem 20% de chance de ficar imune (estado 'I')
                        aux->estado = 'I';
                        printf("%s, ultrapassou a duração max e tornou-se imune\n", aux->nome);
                    }
                }

                (aux->dias)++; // cada iteração é 1 dia, é necessario incrementar 1 dia caso esteja doente
            }
            aux = aux->prox;
        }
        p = p->prox;
    }
}

void recuarPropagacao(plocal p) {

}

void apresentaEstatistica(plocal p) {
    ppessoa aux;
    int nsaudaveis = 0, nimunes = 0, ndoentes = 0;

    while (p != NULL) {
        printf("Estatística do Local %d:\n", p->id);

        aux = p->lista;
        while (aux != NULL) {
            if (aux->estado == 'S')
                nsaudaveis++;
            else if (aux->estado == 'I')
                nimunes++;
            else if (aux->estado == 'D')
                ndoentes++;

            aux = aux->prox;
        }
        printf("\tNúmero de pessoas saudáveis: %d\n", nsaudaveis);
        printf("\tNúmero de pessoas imunes: %d\n", nimunes);
        printf("\tNúmero de pessoas doentes: %d\n\n", ndoentes);

        nsaudaveis = 0;
        nimunes = 0;
        ndoentes = 0;
        p = p->prox;
    }
}

void adicionaDoente(plocal p) {
    ppessoa novo, aux, ver = aux;
    int id, idade, dias, flag;
    char nome[15], estado;
    plocal pInicio = p;

    printf("Id do local: ");
    scanf("%d", &id);

    do {
        p = pInicio; //aponta para o inicio da lista locais        
        flag = 0;

        printf("Nome: ");
        scanf("%14s", nome);
        printf("Idade: ");
        scanf("%d", &idade);
        printf("Dias: ");
        scanf("%d", &dias);

        while (p != NULL) {
            aux = p->lista;
            while (aux != NULL) {
                if (strcmp(nome, aux->nome) == 0)
                    flag = 1;

                aux = aux->prox;
            }
            p = p->prox;
        }

        if (flag == 1)
            printf("\n%s já existe, escolha outro nome!\n\n", nome);

    } while (flag == 1 || idade <= 0 || dias <= 0);


    while (pInicio != NULL && pInicio->id != id)
        pInicio = pInicio->prox;

    if (pInicio == NULL) {
        printf("Valor de local inválido\n");
        return;
    }

    novo = malloc(sizeof (pessoa));
    if (novo == NULL)
        return;

    strcpy(novo->nome, nome);
    novo->idade = idade;
    novo->estado = 'D';
    novo->dias = dias;

    novo->prox = pInicio->lista;
    pInicio->lista = novo;
}

ppessoa pesquisaPessoa(plocal p, char*nome, int* id) {
    ppessoa aux, anterior = NULL, transf = NULL;

    while (p != NULL) {
        aux = p->lista;
        while (aux != NULL) {
            if (strcmp(aux->nome, nome) == 0) {
                *id = p->id;
                //printf("%s %d %c %d\n", aux->nome, aux->idade, aux->estado, aux->dias);
                transf = malloc(sizeof (pessoa));

                strcpy(transf->nome, aux->nome);
                transf->idade = aux->idade;
                transf->estado = aux->estado;
                transf->dias = aux->dias;

                printf("Pessoa a transferir: %s %d %c %d\n", transf->nome, transf->idade, transf->estado, transf->dias);

                return transf;
            }
            aux = aux->prox;
        }
        p = p->prox;
    }

    return transf;
}

plocal eliminaPessoa(plocal p, int id) {
    ppessoa aux, auxAnterior = NULL;
    char nome[15] = "LuisaSantos";

    while (p != NULL) {
        aux = p->lista;
        while (aux != NULL) {
            if (strcmp(aux->nome, nome) == 0) {
                printf("Encontrou -> %s\n", aux->nome);
                if (auxAnterior == NULL) {
                    p->lista = aux->prox;
                    free(aux);
                    return p;
                } else {
                    auxAnterior-> prox = aux->prox;
                    free(aux);
                    aux = auxAnterior;
                    return p;
                }
            }
            auxAnterior = aux; //passa para o próximo elemento da lista principal
            aux = aux->prox;
        }
        aux = aux->prox;
    }
    p = p->prox;

    return p;
}

void transferePessoa(plocal p, int *idOriginal) {
    ppessoa aux, transf;
    int id;
    char nome[15] = "LuisaSantos";

    /* printf("Nome da pessoa a transferir: ");
    scanf("%14s", nome); */

    transf = pesquisaPessoa(p, nome, idOriginal); // variavel que guarda a pessoa, devolve NULL caso o nome não exista
    if (transf == NULL) {
        printf("Pessoa inexistente\n");
        return;
    }

    printf("\nPara onde quer transferir? ");
    scanf("%d", &id);

    while (p != NULL && p->id != id) // se encontrar o id, 'p' aponta para a lista que o contém, caso seja NULL percorreu a lista toda e nao encontrou
        p = p->prox;

    if (p == NULL) {
        printf("Valor de local inválido\n");
        return;
    }

    printf("Local encontrado: %d\n", p->id);
    printf("\nPessoa recebida: %s %d %c %d\n", transf->nome, transf->idade, transf->estado, transf->dias);

    transf->prox = p->lista;
    p->lista = transf;
}

void guardaFicheiro(plocal p) {
    FILE* f;
    ppessoa aux;
    int nsaudaveis = 0, nimunes = 0, ndoentes = 0;

    if ((f = fopen("report.txt", "wt")) != NULL) {
        while (p != NULL) {
            fprintf(f, "Local: %d\n", p->id);
            aux = p->lista;
            while (aux != NULL) {
                if (aux->estado == 'D')
                    fprintf(f, "%s %d %c %d\n", aux->nome, aux->idade, aux->estado, aux->dias);
                else
                    fprintf(f, "%s %d %c\n", aux->nome, aux->idade, aux->estado);

                if (aux->estado == 'S')
                    nsaudaveis++;
                else if (aux->estado == 'I')
                    nimunes++;
                else if (aux->estado == 'D')
                    ndoentes++;

                aux = aux->prox;
            }
            fprintf(f, "Número de pessoas saudáveis: %d\n", nsaudaveis);
            fprintf(f, "Número de pessoas imunes: %d\n", nimunes);
            fprintf(f, "Número de pessoas doentes: %d\n", ndoentes);

            nsaudaveis = 0;
            nimunes = 0;
            ndoentes = 0;

            p = p->prox;
            fprintf(f, "\n");
        }
        fclose(f);
    } else {
        printf("Erro com o ficheiro para escrita\n");
        return;
    }
}