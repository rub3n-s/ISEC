/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.c
 * Author: rubensantos
 *
 * Created on 28 de Maio de 2020, 22:23
 */

#include <stdio.h>
#include <stdlib.h>
#include "locais.h"

int main(int argc, char** argv) {    
    plocal salas = NULL;
    local *l = NULL;
    pessoa *p = NULL;
    char fichEspaco[15], fichPessoas[15];
    int op, id;
    
    //criaFicheiroEspaco();
    //mostraSalas("E5.bin");

    printf("Nome do ficheiro espaço: ");
    scanf("%s", fichEspaco);
    printf("Nome do ficheiro pessoas: ");
    scanf("%s", fichPessoas);
    
    
    l = lerFicheiroLocais(fichEspaco);
    p = lerFicheiroPessoas(fichPessoas);
    salas = inicializaEspaco(fichEspaco, l, p);
    mostraEspaco(salas, l);

    do {
        op = menu();

        switch (op) {
            case 1: 
                modeloPropagacao(salas);
                //mostraEspaco(salas);
                break;
            case 2: 
                
                break;
            case 3: 
                apresentaEstatistica(salas);
                break;
            case 4: 
                adicionaDoente(salas);
                //mostraEspaco(salas);
                break;
            case 5: 
                transferePessoa(salas, &id);
                salas = eliminaPessoa(salas, id);
                //mostraEspaco(salas);
                break;
        }
    } while (op != 6);

    guardaFicheiro(salas);
    libertaTudo(salas);

    return (EXIT_SUCCESS);
}

