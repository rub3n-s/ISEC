
#include <stdio.h>
#include "ponto.h"

// alinea b)
void printPonto(ponto2D a){
    printf("Ponto: (%d,%d)\n", a.x, a.y);
}

// alinea c)
void initPonto(ponto2D* p){
    // completar a função
}

// alinea d)
void movePonto(ponto2D* p, int dx, int dy){
    // completar a função
}