/*
 * File:   TstG3E14.c
 * Author: ans
 *
 * Created on April 25, 2017, 6:01 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "viagens_cp.h"

int main(int argc, char** argv) {

    char *fich = "cp_ex1.dat";
    char *cidadeA = "Aveiro";
    char *cidadeB = "Lisboa";

    mostra_percurso(fich);
    printf("\nA duracao completa do percurso e: %d", tempo_percurso_completo(fich));
    int minutos = viagem2(fich,cidadeA,cidadeB);
    if (minutos>=0)
        printf("\nExiste caminho entre %s e %s que demora %d minutos.\n",cidadeA,cidadeB,minutos);
    else
        printf("\nNao existe caminho entre %s e %s.\n",cidadeA,cidadeB);

    /*puts("\n**********************\n");

    char *percurso = "percurso.txt";
    char *novofich = "cp_novo.dat";

    cria_ficheiro(percurso,novofich);

    mostra_percurso(novofich);*/

    return (EXIT_SUCCESS);
}

