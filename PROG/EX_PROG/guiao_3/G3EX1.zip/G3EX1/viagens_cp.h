#ifndef VIAGENS_CP_H_INCLUDED
#define VIAGENS_CP_H_INCLUDED

typedef struct paragem{
    char nome[50];
    int minutos;
} Paragem;

void mostra_percurso(char * nomefich);
int tempo_percurso_completo(char * nomefich);
//int viagem1(char *nomefich,char *localA,char *localB);

#endif // VIAGENS_CP_H_INCLUDED
