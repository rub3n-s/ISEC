#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "viagens_cp.h"

void mostra_percurso(char * nomefich) {
    Paragem par;

    FILE *f = fopen(nomefich,"rb");
    if (!f) {
        fprintf(stderr,"Erro a abrir o ficheiro %s\n",nomefich);
        return;
    }
    while (fread(&par,sizeof(Paragem),1,f)==1)
        printf("%-25s %3d\n",par.nome,par.minutos);

    /*fread(&par, sizeof(Paragem), 1, f);
    while (feof(f) == 0)
    {
        printf("%-25s %3d\n",par.nome,par.minutos);
        fread(&par, sizeof(Paragem), 1, f);
    }*/

    fclose(f);
}

int tempo_percurso_completo(char * nomefich)
{
    Paragem par;
    int duracao_total=0;

    FILE *f = fopen(nomefich,"rb");
    if (!f) {
        fprintf(stderr,"Erro a abrir o ficheiro %s\n",nomefich);
        return;
    }

   // while (fread(&par,sizeof(Paragem),1,f)==1)
     //   duracao_total+=par.minutos;
    fread(&par, sizeof(Paragem), 1, f);
    while (feof(f) == 0)
    {
        duracao_total+=par.minutos;
        fread(&par, sizeof(Paragem), 1, f);
    }

    fclose(f);
    return duracao_total;
}

int viagem1(char *nomefich,char *localA,char *localB) {
    Paragem par;
    int estado = 0,minutos=0;

    FILE *f = fopen(nomefich,"rb");
    if (!f) {
        fprintf(stderr,"Erro a abrir o ficheiro %s\n",nomefich);
        return -1;
    }

    while (estado!=2 && fread(&par,sizeof(Paragem),1,f)==1) {
        switch (estado) {
            case 0:
                if (!strcmp(par.nome,localA))
                    estado = 1;
                break;
            case 1:
                minutos += par.minutos;
                if (!strcmp(par.nome,localB))
                    estado = 2;
        }
    }
    fclose(f);
    if (estado==2)
        return minutos;
    return -1;
}

int viagem2(char *nomefich,char *localA,char *localB) {
    Paragem par;
    int minutos=-1;

    FILE *f = fopen(nomefich,"rb");
    if (!f) {
        fprintf(stderr,"Erro a abrir o ficheiro %s\n",nomefich);
        return -1;
    }

    while (fread(&par,sizeof(Paragem),1,f)==1 && strcmp(par.nome,localA));

    if (!feof(f)) {
        minutos = 0;
        while (fread(&par,sizeof(Paragem),1,f)==1 && strcmp(par.nome,localB))
            minutos += par.minutos;
        if (feof(f))
            minutos = -1;
        else
            minutos += par.minutos; // ultima paragem do percurso
    }
    fclose(f);

    return minutos;
}

void cria_ficheiro(char *fichtxt,char *fichbin) {
    FILE *f, *g;
    char nomepercurso[50];
    int horas,minutos,marca1,marca2;
    Paragem par;

    if ((f=fopen(fichtxt,"rt"))==NULL) {
        fprintf(stderr,"Erro a abrir o ficheiro %s\n",fichtxt);
        return;
    }
    if ((g=fopen(fichbin,"wb"))==NULL) {
        fclose(f);
        fprintf(stderr,"Erro a criar o ficheiro %s\n",fichbin);
        return;
    }

    if (fscanf(f," %50s",nomepercurso)!=1) {
        fclose(f);fclose(g);
        fprintf(stderr,"Erro a ler o ficheiro %s\n",fichbin);
        return;
    }
    printf("\nProcessar percurso %s => %s\n",nomepercurso,fichbin);
    marca1=-1;
    while (3==fscanf(f," %50s %d.%d",par.nome,&horas,&minutos)) {
        printf("\t- %s\n",par.nome);
        marca2 = horas * 60 + minutos;
        if (marca1==-1)
            par.minutos = 0;
        else
            par.minutos = marca2-marca1;
        fwrite(&par,sizeof(Paragem),1,g);
        marca1 = marca2;
    }

    fclose(g);
    fclose(f);
}
