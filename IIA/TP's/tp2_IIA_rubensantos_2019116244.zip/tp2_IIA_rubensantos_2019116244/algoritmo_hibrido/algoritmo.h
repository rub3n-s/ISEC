#define MAX_OBJ 10000		// Numero maximo de objectos

// Estrutura para armazenar parametros
struct info
{
    // Tamanho da população
    int     popsize;
    // Número de objetos (vertices)
    int     numGenes;
    // Número de arestas
    int     arestas;
    // Lista de vertices ordenada
    int     *vertices;

    // Probabilidade de mutação
    float   pm;
    // Probabilidade de recombinação
    float   pr;
    // Tamanho do torneio para seleção do pai da próxima geração
	int     tsize;
	// Constante para avaliação com penalização
	float   ro;
	// Capacidade da mochila
	int     capacity;
	// Número de gerações
    int     numGenerations;

    // Temperatura máxima
    float     tempMax;
    // Temperatura mínima
    float     tempMin;
    // Fator de arrefecimento
    float fatorArrefecimento;
    // Numero de iterações
    int numIter;
    // Probabilida de aceitar (Trepa Colinas Probabilistico)
    float probAceitar;
};

// Individuo (solução)
typedef struct individual chrom, *pchrom;

struct individual
{
    // Solução (objetos que estão dentro da mochila)
    int     p[MAX_OBJ];
    // Valor da qualidade da solução
	int   fitness;
    // 1 se for uma solução válida e 0 se não for
	int     valido;
    // 1 se população for valida e 0 se não for
};

void tournament(pchrom pop, struct info d, pchrom parents);

void genetic_operators(pchrom parents, struct info d, pchrom offspring);

void crossover(pchrom parents, struct info d, pchrom offspring);

void mutation(pchrom offspring,struct info d);

void tournament_tsize(pchrom pop, struct info d, pchrom parents);
