#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <stdlib.h>
#include "algoritmo.h"
#include "utils.h"

// Preenche uma estrutura com os progenitores da próxima geração, de acordo com o resultados do torneio binario (tamanho de torneio: 2)
// Parâmetros de entrada: população actual (pop), estrutura com parâmetros (d) e população de pais a encher
void tournament(pchrom pop, struct info d, pchrom parents)
{
	int i, x1, x2;

	// Realiza popsize torneios
	for(i=0; i<d.popsize;i++)
	{
		x1 = random_l_h(0, d.popsize-1);
		do
			x2 = random_l_h(0, d.popsize-1);
		while(x1==x2);
		if(pop[x1].fitness > pop[x2].fitness)		// Problema de maximizacao
			parents[i]=pop[x1];
		else
			parents[i]=pop[x2];
	}
}

// Mutação binária com vários pontos de mutação
// Parâmetros de entrada: estrutura com os descendentes (offspring) e estrutura com parâmetros (d)
void tournament_tsize(pchrom pop, struct info d, pchrom parents) {
	int i, j, x, k, winner;
	int pos[d.tsize];

	// if (T_SIZE < 2 || T_SIZE > M) {
	// 	fprintf(stderr, "<ERRO> T_SIZE tem de estar entre 2 e M.\n");
	// 	exit(-1);
	// }

	// Realiza d.popsize torneios
	for (i = 0; i < d.popsize; i++) {
		for (k = 0; k < d.tsize; k++) {
			pos[k] = -1;
			do {
				x = random_l_h(0, d.popsize - 1);
				for (j = 0; j < k; j++)
					if (pos[j] == x)
						break;
			} while (j != k);

			pos[k] = x;
		}
		
		winner = -1;
		for (k = 0; k < d.tsize; k++)
			if (winner == -1 || pop[pos[k]].fitness > pop[winner].fitness)
				winner = pos[k];
	}
}

// Operadores geneticos a usar na geração dos filhos
// Parâmetros de entrada: estrutura com os pais (parents), estrutura com par�metros (d), estrutura que guardar� os descendentes (offspring)
void genetic_operators(pchrom parents, struct info d, pchrom offspring)
{
    // Recombinação com um ponto de corte ou dois pontos de corte
	crossover(parents, d, offspring);
	// Mutação binária
	mutation(offspring, d);
}

// Preenche o vector descendentes com o resultado das operações de recombinação
// Parâmetros de entrada: estrutura com os pais (parents), estrutura com parâmetros (d), estrutura que guardará os descendentes (offspring)
void crossover(pchrom parents, struct info d, pchrom offspring)
{
	// int i, j, point;

	// //================== com um ponto de corte ==================
	// for (i=0; i<d.popsize; i+=2)
	// {
	// 	if (rand_01() < d.pr)
	// 	{
	// 		point = random_l_h(0, d.numGenes-1);
	// 		for (j=0; j<point; j++)
	// 		{
	// 			offspring[i].p[j] = parents[i].p[j];
	// 			offspring[i+1].p[j] = parents[i+1].p[j];
	// 		}
	// 		for (j=point; j<d.numGenes; j++)
	// 		{
	// 			offspring[i].p[j]= parents[i+1].p[j];
	// 			offspring[i+1].p[j] = parents[i].p[j];
	// 		}
	// 	}
	// 	else
	// 	{
	// 		offspring[i] = parents[i];
	// 		offspring[i+1] = parents[i+1];
	// 	}
	// }

	//================== com dois pontos de corte ==================
	/* int i, j, point, point2;

	for (i=0; i<d.popsize; i+=2)
	{
		if (rand_01() < d.pr)
		{
			point = random_l_h(0, d.numGenes-2);        // d.numGenes - 2
			point2 = random_l_h(0, d.numGenes-1);
			for (j=0; j<point; j++)
			{
				offspring[i].p[j] = parents[i].p[j];
				offspring[i+1].p[j] = parents[i+1].p[j];
			}
			for ( ; j < point2; j++) { // copiar genes do ponto 1 ao ponto 2
				offspring[i].p[j] = parents[i+1].p[j];
				offspring[i+1].p[j] = parents[i].p[j];
			}
			for (j=point; j<d.numGenes; j++)
			{
				offspring[i].p[j]= parents[i+1].p[j];
				offspring[i+1].p[j] = parents[i].p[j];
			}

			// A=000000, B=111111   =>    AB1 = 001100, AB2 = 110011
		}
		else
		{
			offspring[i] = parents[i];
			offspring[i+1] = parents[i+1];
		}
	} */

	//================== recombinação uniforme ==================

    int i, j, point, point2;

    for (i=0; i<d.popsize; i+=2)
    {
        if (rand_01() < d.pr) {
            for (j = 0; j < d.numGenes; j++) {
                if (rand_01() < 0.5)    // Escolher se gene vem do pai ou da mãe
                {
                    offspring[i].p[j] = parents[i].p[j];
                    offspring[i+1].p[j] = parents[i+1].p[j];
                }
                else
                {
                    offspring[i].p[j] = parents[i+1].p[j];
                    offspring[i+1].p[j] = parents[i].p[j];
                }
            }
        } else {
            offspring[i] = parents[i];
            offspring[i+1] = parents[i+1];
        }
    }
}

// Mutação binária com vários pontos de mutação
// Parâmetros de entrada: estrutura com os descendentes (offspring) e estrutura com parâmetros (d)
void mutation(pchrom offspring, struct info d)
{
	int i, j;

	for (i=0; i<d.popsize; i++)
		for (j=0; j<d.numGenes; j++)
			if (rand_01() < d.pm)
				offspring[i].p[j] = !(offspring[i].p[j]);
}
