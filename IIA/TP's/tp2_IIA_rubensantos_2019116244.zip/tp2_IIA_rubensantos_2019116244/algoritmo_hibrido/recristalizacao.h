int trepa_colinas(int sol[], struct info d, int mat[][2]);

int esfriamento(int sol[], struct info d, int mat[][2]);
