#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <stdlib.h>
#include "algoritmo.h"
#include "utils.h"
#include "funcao.h"
#include "recristalizacao.h"

#define PROB 0.0005

// Gera um vizinho
// Parametros: solucao actual, vizinho, numero de vertices
// swap two vertices
void gera_vizinho(int a[], int b[], int n)
{
    int p1, p2;

    for(int i = 0; i < n; i++)
        b[i] = a[i];
	// Encontra posicao com valor 0
    do
        p1 = random_l_h(0, n-1);
    while(b[p1] != 0);
	// Encontra posicao com valor 0
    do
        p2 = random_l_h(0, n-1);
    while(b[p2] != 1);
	// Troca
    b[p1] = 1;
    b[p2] = 0;
}

// Trepa colinas first-choice
// Parametros: solucao, matriz de adjacencias, numero de vertices e numero de iteracoes
// Devolve o custo da melhor solucao encontrada
int trepa_colinas(int sol[], struct info d, int mat[][2])
{
    int *nova_sol, custo, custo_viz, temp; 
    //int *nova_sol, *nova_sol2, custo, custo_viz, custo_viz2, i; //4.3 - novas vizinhanças (steepest-ascent, melhor primeiro)
	int matriz[MAX_OBJ][2];
	for (int i = 0; i < d.arestas; i++) {
		matriz[i][0] = mat[i][0];
		matriz[i][1] = mat[i][1];
	}
		
	nova_sol = malloc(sizeof(int)*d.numGenes);
    //nova_sol2 = malloc(sizeof(int)*vert); /* 4.3 */

    if(nova_sol == NULL /*|| nova_sol2 == NULL*/)
    {
        printf("Erro na alocacao de memoria");
        exit(1);
    }

	// Avalia solucao inicial
	custo = eval_individual(sol, d, matriz, &temp);

    for(int i = 0; i < d.numIter; i++)
    {
		// Gera vizinho
		gera_vizinho(sol, nova_sol, d.numGenes);
        //gera_vizinho(sol, nova_sol2, d.numGenes); /* 4.3 */
		
        // Avalia vizinho
		custo_viz = eval_individual(sol, d, matriz, &temp);
        //custo_viz2 = eval_individual(nova_sol2, d, matriz, &temp);    /* 4.3 */

        // Aceita vizinho se o custo diminuir (problema de minimizacao)
        //if(custo_viz > custo) //  com vizinhança 1
        /*if(custo_viz >= custo)  //  vizinhança 1 e aceitando soluções de custo igual
        {
            substitui(sol, nova_sol, d.numGenes);
            custo = custo_viz;
        }*/

        /*if (custo_viz < custo_viz2) {     // 4.3
            if (custo_viz < custo) {
                substitui(sol, nova_sol, d.numGenes);
                custo = custo_viz;
            }
        } else {
            if (custo_viz2 < custo) {
                substitui(sol, nova_sol, d.numGenes);
                custo = custo_viz2;
            }
        } */

        if (custo_viz >= custo) {       // probabilistico   -   4.4
            //solução melhor ou igual e sempre aceite
            substitui(sol, nova_sol, d.numGenes);
            custo = custo_viz;
        } else {    // solução pior tambem pode ser aceite
            if (rand_01() < PROB) {   // isto ajuda a fugir a maximos locais
                substitui(sol, nova_sol, d.numGenes);
                custo = custo_viz;
            }
        }
    }

    free(nova_sol);
    //free(nova_sol2); //   4.3
    return custo;
}

// recristalização
// Parametros: solucao, matriz de adjacencias, numero de vertices e numero de iteracoes
// Devolve o custo da melhor solucao encontrada
int esfriamento(int sol[], struct info d, int mat[][2])
{
    int *nova_sol, *nova_sol2, custo, custo_viz, custo_viz2, i, temp2;
    float temp, erro; // temperaturas inicial e final
    int iteracoes = 0;

	int matriz[MAX_OBJ][2];
	for (int i = 0; i < d.arestas; i++) {
		matriz[i][0] = mat[i][0];
		matriz[i][1] = mat[i][1];
	}

    nova_sol = malloc(sizeof(int)*d.numGenes);
    nova_sol2 = malloc(sizeof(int)*d.numGenes); /* vizinhança 2 */
    if(nova_sol == NULL || nova_sol2 == NULL)
    {
        printf("Erro na alocacao de memoria");
        exit(1);
    }

    // Avalia solucao inicial
    custo = eval_individual(sol, d, matriz, &temp2);
    
    temp = d.tempMax;

    while(temp > d.tempMin) {     // printf("Temperatura: num=%i, %f\n", num_iter,temp);
        temp -= (d.tempMax-d.tempMin) / (float)d.numIter; // descer a temperatura

        // Gera vizinho
        gera_vizinho(sol, nova_sol, d.numGenes);
        gera_vizinho(sol, nova_sol2, d.numGenes); /* vizinhança 2 */

        // Avalia vizinho
        custo_viz = eval_individual(nova_sol, d, matriz, &temp2);
        custo_viz2 = eval_individual(nova_sol2, d, matriz, &temp2); /* vizinhança 2 */

        if (custo_viz >= custo_viz2) {     /* vizinhança 2 */
           if (custo_viz > custo) {
               substitui(sol, nova_sol, d.numGenes);
               custo = custo_viz;
           }
       } else {
           if (custo_viz2 >= custo) {
               substitui(sol, nova_sol2, d.numGenes);
               custo = custo_viz2;
           }
       }

        /*if (custo_viz >= custo) {
            substitui(sol, nova_sol2, d.numGenes);
            custo = custo_viz;
        } else {
            erro = custo-custo_viz;
            // aceitar com determinada probabilidade - calcular probabilidade usando a funcao exp()s
            //d.probAceitar =  exp(erro/temp);
            if (rand_01() < exp(erro/temp)) {   // isto ajuda a fugir a maximos locais
                substitui(sol, nova_sol2, d.numGenes);
                custo = custo_viz;
            }
        }*/

		// Atualiza a temperatura (geometrica)
        temp *= d.fatorArrefecimento; // O fator deve ser < 1

        // Atualiza a temperatura (linear)
        //temp -= d.fatorArrefecimento;

        iteracoes++;
    }

    free(nova_sol);
    free(nova_sol2);    /* vizinhança 2 */
    return custo;
}