void evaluate(pchrom pop, struct info d, int mat[][2]);

int eval_individual(int sol[], struct info d, int mat[][2], int *v);