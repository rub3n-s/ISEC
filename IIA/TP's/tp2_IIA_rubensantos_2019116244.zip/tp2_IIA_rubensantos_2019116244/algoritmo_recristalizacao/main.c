#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "algoritmo.h"
#include "funcao.h"
#include "utils.h"

#define DEFAULT_RUNS	50

int main(int argc, char *argv[])
{
	char        nome_fich[100];
	struct info EA_param;
	pchrom      pop = NULL;
	int 		*sol, *best;
	chrom       best_run, best_ever;
	int         gen_actual, r, runs, i, inv, mat[MAX_OBJ][2];
	float       mbf = 0.0;
	int custo = 0, best_custo = 0;

    // Lê os argumentos de entrada
	if (argc == 3)
	{
		runs = atoi(argv[2]);
		strcpy(nome_fich, argv[1]);
	}
	else
        // Se o número de execuções do processo não for colocado nos argumentos de entrada, define-o com um valor por defeito
        if (argc == 2)
        {
            runs = DEFAULT_RUNS;
            strcpy(nome_fich, argv[1]);
        }
        // Se o nome do ficheiro de informações não for colocado nos argumentos de entrada, pede-o novamente
        else
        {
            runs = DEFAULT_RUNS;
            printf("Nome do Ficheiro: ");
            gets(nome_fich);
        }
    
	// Se o número de execuções do processo for menor ou igual a 0, termina o programa
	if (runs <= 0)
		return 0;
    
	//Inicializa a geração dos números aleat�rios
	init_rand();

    // Preenche a matriz com dados dos objectos (peso e valor) e a estrutura EA_param que foram definidos no ficheiro de input
	EA_param = init_data(nome_fich, mat);
	sol = malloc(sizeof(int)*EA_param.numGenes);
	best = malloc(sizeof(int)*EA_param.numGenes);
	if(sol == NULL || best == NULL)
	{
		printf("Erro na alocacao de memoria");
		exit(1);
	}

	// Faz um ciclo com o número de execuções definidas
	for (r=0; r<runs; r++)
	{
		printf("Repetição %d\n",r+1);

		sol = init_pop(EA_param);

		// Escrever solução inicial
		escreve_sol(sol, EA_param);

		// Chamar trepa_colinas() aqui, para cada elemento
		custo = esfriamento(sol, EA_param, mat);

		// Escreve resultados da repetição r
		printf("\n[RESULTADOS] Repeticao %d:\n", r+1);
		escreve_sol(sol, EA_param);
		printf("Custo final: %2d\n", custo);

		mbf += custo;
		if(r==0 || best_custo < custo)
		{
			best_custo = custo;
			substitui(best, sol, EA_param.numGenes);
		}
		printf("______________________________________________________________\n");
	}
	// Escreve resultados globais
	printf("\n\nMBF: %f\n", mbf/r);
	printf("\nMelhor solucao encontrada");
	escreve_sol(best, EA_param);
	printf("Custo final: %2d\n", best_custo);
	free(sol);
	free(best);
	return 0;
}
