#define _CRT_SECURE_NO_WARNINGS 1
#include "algoritmo.h"
#include "funcao.h"
#include "math.h"
#include "utils.h"
#include <stdlib.h>
#include <stdio.h>

int verificaAdjacencia(int x, int y, struct info d, int mat[][2]) {
    for (int i = 0; i < d.arestas; i++) {
        if (mat[i][0] == x && mat[i][1] == y)
            return 1;
        /*else if (mat[i][0] == y && mat[i][1] == x)
            return 1;*/
    }
    return 0;
}

int eval_individual(int sol[], struct info d, int mat[][2]) {
    int *vertices, nVertices = 0, invalida = 0, rand = 0;
    int tudoZero = 1, tudoUm = 1;

    printf("\n\nPopulação: ");
    for (int i=0; i < d.numGenes; i++)
        printf("%d", sol[i]);
    printf("\n");

    /* Verifica se o cromossoma é composto apenas por 1 ou 0 */
    for (int i=0; i < d.numGenes; i++) {
        if (sol[i] != 0) {
            tudoZero = 0;
            break;
        }
    }
            
    for (int i=0; i < d.numGenes; i++) {
        if (sol[i] != 1) {
            tudoUm = 0;
            break;
        }
    }

    /* Reparação para quando o cromossoma é composto apenas por 1 ou 0 */
    if (tudoZero == 1) {
        for (int i=0; i < d.numGenes; i++)
            if (rand_01() < 0.5)
                sol[i] = 1;
    } else if (tudoUm == 1) {
        for (int i=0; i < d.numGenes; i++)
            if (rand_01() < 0.5)
                sol[i] = 0;
    }

    for (int i = 0; i < d.numGenes; i++) {
        if (sol[i]==1) {
            for (int j = 0; j < d.numGenes; j++) {
                if (verificaAdjacencia(i+1,j+1,d,mat)==1 && sol[j]==1) { // solução inválida
                    //=================  [INICIO] reparação 1 -> aleatoria =================
                    // escolhe aleatoriamente 1 elemento para ficar a zero
                    // do {
                    //     rand = random_l_h(0,d.numGenes-1);
                    //     printf("rand[%d]\n", rand+1);
                    // } while(sol[rand] == 0);
                    // sol[rand] = 0;
                    //
                    // break;
                    //=================  [FIM] reparação 1 -> aleatoria =================

                    
                    //=================  [INICIO] reparação 2 -> aleatoria =================
                    // escolhe aleatoriamente 1 elemento para ficar a zero se a prob se verificar
                    if (rand_01() < 0.5) {
                        do {
                            rand = random_l_h(0,d.numGenes-1);
                        } while(sol[rand] == 1 && rand == j);
                        sol[rand] = 1;
                        if (rand_01() < 0.5)
                            sol[j] = 0;
                    }
                    //=================  [FIM] reparação 2 -> aleatoria =================
                }
            }
        }
    }

    for (int i = 0; i < d.numGenes; i++) {
        if (sol[i]==1){    
            for (int j = 0; j < d.numGenes; j++) {
                if (verificaAdjacencia(i+1,j+1,d,mat)==1 && sol[j]==1) { // solução inválida
                    invalida = 1;
                }
            }
            if (nVertices == 0) {
                vertices = malloc(sizeof(int));
                vertices[nVertices] = i+1;
                nVertices++;
            } else {
                vertices = realloc(vertices,sizeof(int)*nVertices+1);
                vertices[nVertices] = i+1;
                nVertices++;
            }
        }
    }

    printf("Solução Encontrada: ");
    for (int i=0; i < nVertices; i++)
        printf("[%d] ", vertices[i]);
    printf("\n");

    if (invalida == 1) {
        printf("Solução Inválida\n");

       //   [penalizacao] - em vez de devolver zero, devolve o profit penalizado
       /* neste caso remover os pontos que são adjacentes e subtrair o nVertices*/
       //*v = 1;
       //ro = ceil(sum_profit/sum_weight);   //calcular penalização
       //return sum_profit - ro * (sum_weight - d.capacity); // penalizar

        return 0;
    } else {
        printf("Solução Válida\n");
        return nVertices;
    }
}