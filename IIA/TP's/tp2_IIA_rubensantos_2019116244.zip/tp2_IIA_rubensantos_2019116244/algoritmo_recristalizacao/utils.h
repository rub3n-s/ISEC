struct info init_data(char *s, int mat[][2]);

int *init_pop(struct info d);

void init_rand();

int random_l_h(int min, int max);

float rand_01();

int flip();

void escreve_sol(int *sol, struct info d);

void substitui(int a[], int b[], int n);