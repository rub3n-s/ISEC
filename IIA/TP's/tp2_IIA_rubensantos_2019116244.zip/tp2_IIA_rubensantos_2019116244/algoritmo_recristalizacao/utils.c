#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "algoritmo.h"
#include "utils.h"

// Inicializa��o do gerador de n�meros aleat�rios
void init_rand()
{
	srand((unsigned)time(NULL));
}

// Leitura dos par�metros e dos dados do problema
// Par�metros de entrada: Nome do ficheiro e matriz a preencher com os dados dos objectos (peso e valor)
// Par�metros de sa�da: Devolve a estrutura com os par�metros
struct info init_data(char *filename, int mat[][2])
{
	struct  info x;
	FILE    *f;
	int     i;

	f = fopen(filename, "rt");
	if (!f)
	{
		printf("File not found\n");
		exit(1);
	}

	// Leitura dos parâmetros do problema
	x.tempMax = 100;
	x.tempMin = 1;
	x.fatorArrefecimento = 0.99;
	x.numIter = 230;

	fscanf(f, " p edge %d %d", &x.numGenes, &x.arestas);
	printf("vertices[%d] arestas[%d]\n", x.numGenes,x.arestas);

	if (x.numGenes > MAX_OBJ)
	{
		printf("Number of itens is superior to MAX_OBJ\n");
		exit(1);
	}
	
	// Leitura dos dados para criar adjacêncais
	for (i=0; i < x.arestas; i++)
		fscanf(f, " e %d %d", &mat[i][0], &mat[i][1]);
	fclose(f);
	
	// Devolve a estrutura com os par�metros
	return x;
}

// Simula o lan�amento de uma moeda, retornando o valor 0 ou 1
int flip()
{
	if ((((float)rand()) / RAND_MAX) < 0.5)
		return 0;
	else
		return 1;
}

// Criacao da populacao inicial. O vector e alocado dinamicamente
// Parâmetro de entrada: Estrutura com parâmetros do problema
// Parâmetro de saída: Preenche da estrutura da população apenas o vector binário com os elementos que estão dentro ou fora da mochila
int *init_pop(struct info d)
{
	int     i, j;
	int  *indiv;

	indiv = malloc(sizeof(int)*d.numGenes);
	if (indiv==NULL)
	{
		printf("Erro na alocacao de memoria\n");
		exit(1);
	}
	for (j=0; j<d.numGenes; j++)
		indiv[j] = flip();

	for (j=0; j<d.numGenes; j++)
		printf("%d ", indiv[j]);
	printf("\n");
	return indiv;
}

// Devolve um valor inteiro distribuido uniformemente entre min e max
int random_l_h(int min, int max)
{
	return min + rand() % (max-min+1);
}

// Devolve um valor real distribuido uniformemente entre 0 e 1
float rand_01()
{
	return ((float)rand())/RAND_MAX;
}

// Escreve solucao
// Parametros: solucao e numero de vertices
void escreve_sol(int *sol, struct info d) {
	printf("\nConjunto A: ");
	for(int i = 0; i < d.numGenes; i++)
		if(sol[i]==0)
			printf("%2d  ", i+1);
			
	printf("\nConjunto B: ");
	for(int i = 0; i < d.numGenes; i++)
		if(sol[i]==1)
			printf("%2d  ", i+1);
	printf("\n");
}

// copia vector b para a (tamanho n)
void substitui(int a[], int b[], int n) {
    int i;
    for(i=0; i<n; i++)
        a[i]=b[i];
}