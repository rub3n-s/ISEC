package pt.isec.pa.exerc30;

import javafx.application.Application;
import pt.isec.pa.exerc30.ui.gui.MainJFX;

public class Main {
    public static void main(String[] args) {
        Application.launch(MainJFX.class,args);
    }
}