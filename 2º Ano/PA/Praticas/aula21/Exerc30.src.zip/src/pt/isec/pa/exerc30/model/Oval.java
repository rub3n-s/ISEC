package pt.isec.pa.exerc30.model;

public class Oval extends Rectangle {
    @Override
    public FigureType getType() {
        return FigureType.OVAL;
    }
}
