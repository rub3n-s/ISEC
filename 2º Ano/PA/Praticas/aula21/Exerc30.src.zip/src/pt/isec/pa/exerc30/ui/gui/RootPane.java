package pt.isec.pa.exerc30.ui.gui;

import javafx.scene.layout.BorderPane;
import pt.isec.pa.exerc30.model.Drawing;

public class RootPane extends BorderPane {
    Drawing drawing;

    public RootPane(Drawing drawing) {
        this.drawing = drawing;

        createViews();
        registerHandlers();
        update();
    }

    private void createViews() {
    }

    private void registerHandlers() {
    }

    private void update() {
    }
}
