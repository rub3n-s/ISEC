package pt.isec.pa.exerc30.model;

public class Line extends Figure {
    @Override
    public FigureType getType() {
        return FigureType.LINE;
    }
}
