package pt.isec.pa.teostatejfx;

import javafx.application.Application;
import pt.isec.pa.teostatejfx.ui.gui.MainJFX;

public class Main {
    public static void main(String[] args) {
        Application.launch(MainJFX.class,args);
    }
}