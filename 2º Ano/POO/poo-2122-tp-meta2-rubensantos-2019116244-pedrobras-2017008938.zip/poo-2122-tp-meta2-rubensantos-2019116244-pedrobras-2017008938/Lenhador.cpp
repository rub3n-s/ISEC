//
// Created by rsantos on 26/12/2021.
//

#include "Lenhador.h"

Lenhador::Lenhador(const char& tip, int prec, int di) : tipo(tip), preco(prec), dia(di), Trabalhador(tip,prec,di) {}

char Lenhador::getTipo() const { return tipo; }

int Lenhador::getPreco() const { return preco; }

void Lenhador::setPreco(int p) { preco = p; }