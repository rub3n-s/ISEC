//
// Created by rsantos on 26/12/2021.
//

#include "Mineiro.h"

Mineiro::Mineiro(const char& tip, int prec, int di) : tipo(tip), preco(prec), dia(di), Trabalhador(tip,prec,di) {}

char Mineiro::getTipo() const { return tipo; }

int Mineiro::getPreco() const { return preco; }

void Mineiro::setPreco(int p) { preco = p; }