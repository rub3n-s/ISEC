//
// Created by rsantos on 24/12/2021.
//

#include "Bateria.h"

Bateria::Bateria(string const& desig, int prec) : designacao(desig), preco(prec), Edificio(desig,prec) {
    recurso = "eletricidade";
    nivel = 1;
    precoNivel = 5;
    capacidade = 100;
    armazenado = 0;
}

string Bateria::getDesignacao() const { return designacao; }

string Bateria::getRecurso() const { return recurso; }

int Bateria::getPreco() const { return preco; }

void Bateria::setPreco(int p) { preco = p; }

int Bateria::getCapacidade() const { return capacidade; }

int Bateria::getNivel() const { return nivel; }

int Bateria::getPrecoNivel() const { return precoNivel; }

void Bateria::aumentaNivel() {
    if (nivel < 5) {
        capacidade+=10;
        nivel++;
        cout << "Nível aumentado com sucesso. Nivel atual: " << nivel << endl;
    }
}

void Bateria::armazena(int quantidade) {
    if (armazenado+quantidade <= capacidade)
        armazenado += quantidade;
    else {
        armazenado = capacidade;
        cout << "Lotação máxima atingida na mina de ferro." << endl;
    }
}

int Bateria::getArmazenado() const { return armazenado; }

void Bateria::setArmazenado(int quantidade) { armazenado -= quantidade; }
