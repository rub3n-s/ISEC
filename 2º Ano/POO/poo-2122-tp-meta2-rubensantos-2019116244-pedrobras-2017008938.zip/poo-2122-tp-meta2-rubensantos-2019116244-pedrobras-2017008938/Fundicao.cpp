//
// Created by rsantos on 24/12/2021.
//

#include "Fundicao.h"

Fundicao::Fundicao(string const& desig, int prec) : designacao(desig), preco(prec), Edificio(desig,prec) {
    recurso = "aco";
}

string Fundicao::getDesignacao() const { return designacao; }

string Fundicao::getRecurso() const { return recurso; }

int Fundicao::getPreco() const { return preco; }

void Fundicao::setPreco(int p) { preco = p; }