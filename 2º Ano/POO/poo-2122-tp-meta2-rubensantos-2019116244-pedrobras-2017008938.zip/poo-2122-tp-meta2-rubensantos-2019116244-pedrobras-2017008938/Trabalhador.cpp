//
// Created by rsantos on 04/11/2021.
//

#include "Trabalhador.h"

int Trabalhador::contID = 0;

Trabalhador::Trabalhador(const char& t, int p, int d) : id(++contID), preco(p), dia(d) {
    if (t == 'O') {
        diaDespedimento = 10;
        probDespedir = 5;
    }
    else if (t == 'M') {
        diaDespedimento = 2;
        probDespedir = 10;
    }
}

Trabalhador::Trabalhador() {}

Trabalhador::~Trabalhador() {}

int Trabalhador::getId() const { return id;}

char Trabalhador::getTipo() const { return tipo; }

void Trabalhador::setPreco(int p) { preco = p; }

int Trabalhador::getPreco() const { return preco; }

int Trabalhador::getDia() const { return dia; }

bool Trabalhador::despedir(int d) {
    if ((d-dia) >= diaDespedimento && tipo != 'L' && !pas) {
            bool random = (rand() % 100) <= probDespedir;
            if (random)
                return true;    // trabalhador despede-se
    }
    return false;
}

void Trabalhador::lenhadorDescansa(int d) {
    if (d-dia >= 4)
        descansa = true;
}

bool Trabalhador::verificaDescansa() {
    if (descansa)
        return true;
    return false;
}

void Trabalhador::acabouDescanso() { descansa = false; }

void Trabalhador::setProbDespedir(int prob) {
    probDespedir += prob;
}

void Trabalhador::setMovido() {
    if (!movido)
        movido = true;  // true ao mover o trabalhador
    else
        movido = false; // false na fase do amanhecer (inicio de um novo dia)
}

bool Trabalhador::getMovido() { return movido; }