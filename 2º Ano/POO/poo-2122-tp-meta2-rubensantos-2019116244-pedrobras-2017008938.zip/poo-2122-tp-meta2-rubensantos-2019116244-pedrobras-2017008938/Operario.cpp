//
// Created by rsantos on 26/12/2021.
//

#include "Operario.h"

Operario::Operario(const char& tip, int prec, int di) : tipo(tip), preco(prec), dia(di), Trabalhador(tip,prec,di) {}

char Operario::getTipo() const { return tipo; }

int Operario::getPreco() const { return preco; }

void Operario::setPreco(int p) { preco = p; }