//
// Created by rsantos on 26/12/2021.
//

#ifndef POO_TP1_RUBENSANTOS_PEDROBRAS_OPERARIO_H
#define POO_TP1_RUBENSANTOS_PEDROBRAS_OPERARIO_H

#include "Trabalhador.h"

class Operario : public Trabalhador {
protected:
    char tipo;
    int preco;
    int dia;
public:
    Operario(const char& tip, int prec, int di);

    char getTipo() const override;
    int getPreco() const override;
    void setPreco(int p) override;
};


#endif //POO_TP1_RUBENSANTOS_PEDROBRAS_OPERARIO_H
