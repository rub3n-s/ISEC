//
// Created by rsantos on 04/11/2021.
//

#include "Comando.h"

#define MIN_LINHAS 3
#define MIN_COLUNAS 3
#define MAX_LINHAS 8
#define MAX_COLUNAS 16

vector<string> listaHelp = {
        "criar <linhas> <colunas> - cria a ilha",   // feito
        "exec ../inicializa.txt - executa o ficheiro teste",    // feito
        "cons <tipo> <linha> <coluna> constroi um edificio",    // feito
        "liga <linha> <coluna> - liga o edificio",  // feito
        "des <linha> <coluna> - desliga o edificio",    // feito
        "move <id> <linha> <coluna> - move o trabalhador",  // feito
        "cont <tipo> - contrata trabalhador",   // feito
        "vende <tipo> <quantidade> - vende recursos", // feito
        "vende <linha> <coluna> - vende edificio na zona",  // feito
        "list <linha> <coluna> - obtem info do jogo, globalmente se nao indicar linha e coluna",    // feito (falta caso nao indique zona - listar tudo)
        "next - termina a fase de recolha de comandos e desencadeia acoes",
        "save <nome> - grava o estado do jogo",  // feito
        "load <nome> - carrega o estado do jogo",   // feito
        "apaga <nome> - apaga savegame",    // feito
        "config <ficheiro> - le o ficheiro de texto e extrai os preços de contratacao e compra dos eficios",   // feito
        "debcash <valor> adiciona a quantidade dinheiro especifica",    // feito
        "debed <tipo> <linha> <coluna> - adiciona um edifico a custo zero",   // feito
        "debkill <id> - remove trabalhador",    // feito
        "saves - lista com o nome dos save games",    // feito
        "recursos - lista com os recursos do jogador",  // feito
        "recolher - recolhe todos os recursos disponiveis (zonas e edificios)",
        "transformar <recurso> - transforma o recurso pretendido em outro recurso", // feito
        "upgrade <linha> <coluna> - aumenta o nivel do edificio na zona escolhida", // feito
        "saldo - saldo do jogador", //feito
        "precos - lista os precos dos edificios e trabalhadores",
        "exit"  // feito
};

vector<string> listaComandos = {
        "help",
        "criar",
        "exec",
        "cons",
        "liga",
        "des",
        "move",
        "cont",
        "list",
        "vende",
        "next",
        "save",
        "load",
        "apaga",
        "saves",
        "recursos",
        "recolher",
        "transformar",
        "saldo",
        "upgrade",
        "precos",
        "config",
        "debcash",
        "debed",
        "debkill",
        "exit"
};

vector<string> listaZonas = {
        "dsr", // deserto
        "pas",  // pastagem
        "flr",  // floresta
        "pnt",  // pantano
        "znX",  // zonaX
        "mnt" // montanha
};

vector<pair<string,string>> listaEdificios = {
        {"minaferro", "mnF"},
        {"minacarvao", "mnC"},
        {"centraleletrica", "ele"},
        {"bateria", "bat"},
        {"fundicao", "fun"},
        {"serracao", "ser"}
};

vector<pair<string,char>> listaTrabalhadores = {
        {"operario",'O'},
        {"mineiro",'M'},
        {"lenhador",'L'}
};

vector<string> listaRecursos = {
        "ferro",
        "aco",
        "carvao",
        "madeira",
        "viga",
        "eletricidade"
};

Comando::Comando(Ilha &i, Jogador &j) {
    ilha = &i;
    jogador = &j;
}

void comandosHelp() {
    for (auto h : listaHelp)
        cout << h << endl;
}

bool Comando::carregaFicheiro(string f) {      // carrega o ficheiro
    ifstream fich(f);   // nome do ficheiro
    if (fich) {
        string comando;
        while (getline(fich, comando)) {
            cout << "comando encontrado: " << comando << "\n" << endl;
            criaCmd(comando);
        }
        fich.close();
        if (config) config = false; // se acabou de ler o ficheiro config var volta false
    }
    else {
        cout << "Ficheiro não abriu" << endl;
        return false;
    }
    cout << "Sucesso a carregar o ficheiro!\n" << endl;
    return true;
}

void Comando::eliminaSave(string nome) {
    int it = 0;
    for (auto s : saveGames) {
        if (get<2>(s) == nome)
            saveGames.erase(saveGames.begin() + it);
        it++;
    }
}

bool Comando::criaCmd(string cmd) {
    string arg1, arg2;
    char argc;
    int narg2, narg3, narg4;
    double narg5;
    istringstream iss;
    iss.clear();
    arg1.clear();
    iss.str(cmd);
    iss >> arg1;    // para saber qual é o comando

    if (config) {   // nao precisa de verificar comando, so entra no if depois de vir da func carregaFicheiro
                    //ou seja, já foi valido
        if (arg1 == "O" || arg1 == "L" || arg1 == "M") {
            iss.clear();
            iss.str(cmd);
            iss >> argc;
            for (auto t : listaTrabalhadores) {
                if (t.second == argc) {
                    iss >> narg2;
                    ilha->procuraTrabalhador(argc,narg2);   // envia designacao e preco
                    return true;
                }
            }
        }
        for (auto e : listaEdificios) {
            if (e.second == arg1) {
                iss >> narg2;
                ilha->procuraEdificio(arg1,narg2);  // envia designacao e preco
                return true;
            }
        }
    } else
        verificaCmd(arg1);  // verifica se o comando introduzido é valido

    if (arg1 == "help") {
        comandosHelp();
        return true;
    }

    if (arg1 == "exec") {
        iss >> arg2;   // nome do ficheiro de texto
        carregaFicheiro(arg2);  // função que carrega o ficheiro
        return true;
    }

    if (arg1 == "criar" && !ilhaCriada){
        iss >> narg2 >> narg3;
        if (verificaDimensoes(narg2, narg3)) {     // função verifica se esta dentro dos limites
            ilha->setLinhas(narg2);
            ilha->setColunas(narg3);    // define a dimensao da ilha (linhas x colunas)
            ilha->criaZonas(listaZonas);  // envia lista de zonas para escolher elemento aleatorio
            ilha->listaIlha();
            ilhaCriada = true;
            cout << "Ilha criada com sucesso!" << endl;
        }
        return true;
    }

    if (arg1 == "criar" && ilhaCriada) {
        cout << "\nA ilha já foi criada!" << endl;
        return false;
    }

    if (ilhaCriada) {   // se a ilha já tiver sido criada estes comandos são "desbloqueados"
        // constroi um edificio dado o seu tipo e a posicao
        if (arg1 == "cons") {
            iss >> arg2 >> narg2 >> narg3;
            if (verificaEdificio(arg2) && verificaDimensoes(narg2, narg3))
                verificaConstrucao(arg2,narg2,narg3);
        }

        // contrata um trabalhador
        if (arg1 == "cont") {
            iss >> arg2;
            if (verificaTrabalhador(arg2)) {
                for (auto t : listaTrabalhadores)
                    if (arg2 == t.first)
                        argc = t.second;
                // verifica se trabalhador existe e o dinheiro do jogador
                if (!jogador->tiraDinheiro(ilha->devolvePrecoTrabalhador(argc))) { // retira ao dinheiro o preco do trabalhador
                    cout << "Saldo atual: " << jogador->getDinheiro() << endl;
                    return false;
                }
                ilha->recebeTrabalhador(arg2);
            }
        }

        // lista uma zona especifica ou todas
        if (arg1 == "list") {
            if (cmd.size() == 4) // se apenas for detetado "list", imprime todas as zonas
                ilha->listaTodasZonas();
            else {
                iss >> narg2 >> narg3;
                if (verificaDimensoes(narg2, narg3))
                    ilha->listaZona(narg2, narg3);
            }
        }

        // le o ficheiro de configuracao
        if (arg1 == "config") {
            iss >> arg2;
            config = true;
            carregaFicheiro(arg2);
        }

        // liga um edificio
        if (arg1 == "liga") {
            iss >> narg2 >> narg3;
            if (verificaDimensoes(narg2, narg3))
                ilha->onOffEdificio(arg1,narg2,narg3);
        }

        // desliga um edificio
        if (arg1 == "des") {
            iss >> narg2 >> narg3;
            if (verificaDimensoes(narg2, narg3))
                ilha->onOffEdificio(arg1,narg2,narg3);
        }

        // move um trabalhador
        if (arg1 == "move") {
            iss >> narg2 >> narg3 >> narg4;
            if (verificaDimensoes(narg3,narg4))
                ilha->moverTrabalhador(narg2,narg3,narg4);
        }

        // vende um edificio ou um recurso dependendo dos parametros escritos
        if (arg1 == "vende") {
            iss >> arg2;
            if (!verificaNumero(arg2)) { // false, é string
                if (verificaRecursos(arg2)) {
                    iss >> narg5;
                    jogador->vendeRecursos(arg2, narg5);
                }
            } else {    // true, é inteiro
                iss.clear();
                iss.str(cmd);
                iss >> arg1 >> narg2 >> narg3;
                if (verificaDimensoes(narg2,narg3)) {
                    int precoEdificio = 0;
                    precoEdificio = ilha->getPrecoEdificio(narg2,narg3);
                    jogador->depositaDinheiro(precoEdificio);
                }
            }
        }

        // debita uma quantia de dinheiro deseja
        if (arg1 == "debcash") {
            iss >> narg2;
            jogador->depositaDinheiro(narg2);
        }

        // constroi um edificio gratuitamente numa zona pretendida
        if (arg1 == "debed") {
            iss >> arg2 >> narg2 >> narg3;
            if (verificaEdificio(arg2) && verificaDimensoes(narg2,narg3))
                ilha->recebeEdificio(arg2,narg2,narg3);
        }

        // remove trabalhador dado o seu id
        if (arg1 == "debkill") {
            iss >> narg2;
            ilha->removerTrabalhador(narg2);
        }

        // guarda em memoria o estado do jogo (ilha e jogador)
        if (arg1 == "save") {
            iss >> arg2;
            if (!verificaNomeSave(arg2)) { // se ainda não existir o nome na lista de saves
                saveGames.push_back(make_tuple(new Ilha(*ilha),new Jogador(*jogador),arg2));
                cout << "Save game com o nome '" << arg2 << "' guardado com sucesso." << endl;
            }
            else
                cout << "Já existe um save com o nome '" << arg2 << "'." << endl;
        }

        // carrega um save game guardado em memoria
        if (arg1 == "load") {
            iss >> arg2;
            if (verificaNomeSave(arg2)) {
                for (auto s : saveGames) {
                    if (get<2>(s) == arg2) {
                        ilha = get<0>(s);
                        jogador = get<1>(s);
                    }
                }
                cout << "Save game '" << arg2 << "' carregado com sucesso." << endl;
            } else
                cout << "Save game não econtrado." << endl;
        }

        // apaga um save dado o seu nome
        if (arg1 == "apaga") {
            iss >> arg2;
            if (verificaNomeSave(arg2))
                eliminaSave(arg2);
        }

        // faz a listagem dos saves existentes
        if (arg1 == "saves") {
            cout << "Lista de save games:" << endl;
            for (auto s : saveGames)
                cout << "\t" << get<2>(s) << endl;
        }

        // desencadeia as ações do anoitecer e amanhecer
        if (arg1 == "next") {
            ilha->acoesAnoitecer();
            ilha->incrementaDia();
            jogador->getListaRecursos();
            cout << "Saldo atual : " << jogador->getDinheiro() << endl;
            ilha->acoesAmanhecer();
        }

        // faz uma listagem dos recursos em posse do jogador (nao mostra os que estao nas zonas ou edificios)
        // os que se encontram nos edificios e zonas aparecem ao fazer a listagem da zona
        if (arg1 == "recursos")
            jogador->getListaRecursos();

        if (arg1 == "recolher") {
            // retorna os recursos ao jogador
            for (int i = 0; i < ilha->getLinhas(); i++) {
                for (int j = 0; j < ilha->getColunas(); j++) {
                    // receber recursos da zona
                    string recurso = ilha->getTipoRecurso(i,j);
                    double quantidade = ilha->getQuantidadeRecurso(i,j);
                    jogador->recebeRecursos(recurso,quantidade);
                    if (ilha->verificaEdificio(i,j) && ilha->verificaEdificioLigado(i,j)) {
                        // receber recursos do edificio
                        string recursoEdf = ilha->getTipoRecursoEdificio(i,j);
                        int quantidadeEdf = ilha->getQuantidadeRecursoEdificio(i,j);
                        jogador->recebeRecursos(recursoEdf,quantidadeEdf);
                    }
                }
            }
        }

        // transforma um tipo de recurso se existir um edificio que o faça
        if (arg1 == "transformar") {
            iss >> arg2;
            if (ilha->verificaTipoDeEdificio(arg2))
                jogador->transformaRecurso(arg2);
        }

        if (arg1 == "upgrade") {
            iss >> narg2 >> narg3;
            // verifica se existe edificio na zona, e compara o dinheiro do jogador com o preço do upgrade
            if (ilha->verificaEdificio(narg2,narg3) && jogador->getDinheiro() >= ilha->getUpgradeEuros(narg2,narg3)) {
                // caso o tipo de edificio seja mnF ou mnC para alem do dinheiro requer 1 viga de madeira
                if (ilha->getTipoEdificio(narg2, narg3) == "mnF" && ilha->getTipoEdificio(narg2, narg3) == "mnC") {
                    if (jogador->getVigas() >= 1) {
                        jogador->tiraDinheiro(ilha->getUpgradeEuros(narg2,narg3));
                        jogador->tiraViga(1);
                        ilha->levelUp(narg2,narg3);
                    }
                }
                else {
                    jogador->tiraDinheiro(ilha->getUpgradeEuros(narg2,narg3));
                    ilha->levelUp(narg2,narg3);
                }
            }
        }

        // retorna o saldo do jogador
        if (arg1 == "saldo")
            cout << "Saldo atual : " << jogador->getDinheiro() << endl;

        // faz a listagem dos preços dos edificios e trabalhadores
        if (arg1 == "precos")
            ilha->listaPrecos();

        // lista a ilha completa cada vez que pede um comando
        if (arg1 != "list" && ilhaCriada)
            ilha->listaIlha();

        return true;
    } else
        cout << "\nA ilha ainda não foi criada!" << endl;

    return false;
}

void Comando::configuracao() {
    string comando;
    cout << "\nhelp (saber os comandos)\n\n";
    do {
        cin.clear();
        fflush(stdin);
        cout << "\ncomando: ";
        getline(cin, comando);
        cout << endl;
        criaCmd(comando);
    } while(comando!="exit");
}

/*==============================  Verificações ==============================*/

bool Comando::verificaCmd(string cmd) {     // valida os comandos inseridos
    for (auto c : listaComandos)
        if (c == cmd)
            return true;
    cout << "\nComando inválido!" << endl;
    return false;
}

bool Comando::verificaDimensoes(int narg2, int narg3) {
    if (!ilhaCriada) {  // se a ilha nao foi criada, min 3x3 ; max 8x16
        if (narg2 >= MIN_LINHAS && narg3 >= MIN_COLUNAS && narg2 <= MAX_LINHAS && narg3 <= MAX_COLUNAS)
            return true;
    }
    else {  // se ja foi criada verifica a dimensao da ilha
        if (narg2 >= 0 && narg2 < ilha->getLinhas() && narg3 >= 0 && narg3 < ilha->getColunas())
            return true;
    }
    cout << "\nDimensões introduzidas inválidas!\n";
    return false;
}

bool Comando::verificaZona(string zona) {
    for (auto e : listaZonas)
        if (e == zona)
            return true;
    cout << "\nNão existe nenhuma zona com essa designação!" << endl;
    return false;
}

bool Comando::verificaEdificio(string edificio) {
    for (auto e : listaEdificios)
        if (e.first == edificio)
            return true;
    cout << "\nNão existe nenhum edificio com essa designação!" << endl;
    return false;
}

bool Comando::verificaTrabalhador(string trabalhador) {
    for (auto e : listaTrabalhadores)
        if (e.first == trabalhador)
            return true;
    cout << "\nNão existe nenhum trabalhador com essa designação!" << endl;
    return false;
}

bool Comando::verificaRecursos(string recurso) {
    for (auto r : listaRecursos)
        if (r == recurso)
            return true;
    cout << "\nNão existe nenhum recurso com essa designação!" << endl;
    return false;
}

bool Comando::verificaNomeSave(string nome) {
    for (auto s : saveGames)
        if (get<2>(s) == nome)
            return true;
    return false;
}


bool Comando::verificaNumero(const string& s) {
    for (char const &ch : s) {
        if (isdigit(ch) == 0)
            return false;
    }
    return true;
}

bool Comando::verificaConstrucao(string arg2, int narg2, int narg3) {
    // verifica se edificio existe na zona, as dimensoes da ilha e o dinheiro do jogador
    if (arg2 == "minaferro" || arg2 == "minacarvao") {
        char resposta;
        do {
            cout << "Substituir vigas por euros? (S/N)";
            cin >> resposta;
        } while(resposta != 'S' && resposta != 'N');
        if (resposta == 'S') {
            int quantas = 0;
            do {
                cout << "Quantas? ";
                cin >> quantas;
            } while(quantas <= 0 && quantas > jogador->getVigas());
            if (jogador->getDinheiro() >= ilha->devolvePrecoEdificio(arg2,narg2,narg3) * quantas
                && jogador->getVigas() >= ilha->devolvePrecoEdificio(arg2,narg2,narg3) - quantas) {
                jogador->tiraViga(ilha->devolvePrecoEdificio(arg2,narg2,narg3)-quantas);
                jogador->tiraDinheiro(ilha->devolvePrecoEdificio(arg2,narg2,narg3)*quantas);
                ilha->recebeEdificio(arg2, narg2, narg3); // caso não exista insere na zona
            } else {
                cout << "Não tem dinheiro/vigas suficiente(s)." << endl;
                cout << "Saldo atual: " << jogador->getDinheiro() << endl;
                cout << "Numero de vigas: " << jogador->getVigas() << endl;
                return false;
            }
        }
        else if (jogador->getVigas() >= ilha->devolvePrecoEdificio(arg2,narg2,narg3)){
            jogador->tiraViga(ilha->devolvePrecoEdificio(arg2,narg2,narg3));
            ilha->recebeEdificio(arg2, narg2, narg3); // caso não exista insere na zona
        } else {
            cout << "Não tem vigas suficientes." << endl;
            cout << "Numero de vigas: " << jogador->getVigas() << endl;
            return false;
        }
    } else if (arg2 == "bateria") {
        if (jogador->getDinheiro() >= ilha->devolvePrecoEdificio(arg2,narg2,narg3) &&
            jogador->getVigas() >= 10) {  // 10 vigas
            jogador->tiraViga(10);
            jogador->tiraDinheiro(ilha->devolvePrecoEdificio(arg2,narg2,narg3));
            ilha->recebeEdificio(arg2, narg2, narg3); // caso não exista insere na zona
        } else {
            cout << "Não tem dinheiro/vigas suficiente(s)." << endl;
            cout << "Saldo atual: " << jogador->getDinheiro() << endl;
            cout << "Numero de vigas: " << jogador->getVigas() << endl;
            return false;
        }
    } else if (!jogador->tiraDinheiro(ilha->devolvePrecoEdificio(arg2,narg2,narg3))) { // retira ao dinheiro o preco do edificio
        cout << "Saldo atual: " << jogador->getDinheiro() << endl;
        return false;
    } else {
        ilha->recebeEdificio(arg2, narg2, narg3); // caso não exista insere na zona
        cout << "Saldo atual: " << jogador->getDinheiro() << endl;
        cout << "Numero de vigas: " << jogador->getVigas() << endl;
    }
    return true;
}

/*==============================  Apresentação ==============================*/

void Comando::apresentacao() {
    cout << "┌──────────────────────────────────────────────┐" << endl;
    cout << "|                                              |" << endl;
    cout << "| Trabalho Pratico POO - Projeto C++           |" << endl;
    cout << "|                                              |" << endl;
    cout << "|  Realizado por:                              |" << endl;
    cout << "|                                              |" << endl;
    cout << "|       Rúben Santos - 2019116244              |" << endl;
    cout << "|       Pedro Brás   - 2017008938              |" << endl;
    cout << "|                                              |" << endl;
    cout << "└──────────────────────────────────────────────┘" << endl;
}