//
// Created by rsantos on 10/11/2021.
//

#include "Edificio.h"

Edificio::Edificio(string const& desig, int prec) : designacao(desig), preco(prec) {}

Edificio::Edificio() {}

Edificio::~Edificio() {}

string Edificio::getDesignacao() const { return designacao; }

string Edificio::getRecurso() const { return recurso; }

int Edificio::getPreco() const { return preco; }

void Edificio::setPreco(int p) { preco = p; }

int Edificio::getCapacidade() const { return capacidade; }

int Edificio::getNivel() const { return nivel; }

int Edificio::getPrecoNivel() const { return precoNivel; }

void Edificio::aumentaNivel() {
    if (nivel < 5) {
        capacidade+=10;
        nivel++;
        produz++;
        cout << "Nível aumentado com sucesso. Nivel atual: " << nivel << endl;
    }
}

void Edificio::armazena(int quantidade) {
    if (armazenado+quantidade <= capacidade)
        armazenado += quantidade;
    else {
        armazenado = capacidade;
        cout << "Lotação máxima atingida." << endl;
    }
}

void Edificio::producaoDiaria(int multiplicador) {   // ha zonas que produz a duplicar
    if (armazenado + produz * multiplicador <= capacidade)
        armazenado += produz * multiplicador;
    else {
        armazenado = capacidade;
        cout << "Lotação máxima atingida na mina de ferro." << endl;
    }
}

int Edificio::getArmazenado() const { return armazenado; }

void Edificio::setArmazenado(int quantidade) { armazenado -= quantidade; }