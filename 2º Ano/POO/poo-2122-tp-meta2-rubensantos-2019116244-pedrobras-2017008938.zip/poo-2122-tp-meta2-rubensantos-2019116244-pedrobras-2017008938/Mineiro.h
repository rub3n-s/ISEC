//
// Created by rsantos on 26/12/2021.
//

#ifndef POO_TP1_RUBENSANTOS_PEDROBRAS_MINEIRO_H
#define POO_TP1_RUBENSANTOS_PEDROBRAS_MINEIRO_H

#include "Trabalhador.h"

class Mineiro : public Trabalhador{
protected:
    char tipo;
    int preco;
    int dia;
public:
    Mineiro(const char& tip, int prec, int di);

    char getTipo() const override;
    int getPreco() const override;
    void setPreco(int p) override;
};


#endif //POO_TP1_RUBENSANTOS_PEDROBRAS_MINEIRO_H
