//
// Created by rsantos on 04/11/2021.
//

#ifndef POO_TP1_RUBENSANTOS_PEDROBRAS_COMANDO_H
#define POO_TP1_RUBENSANTOS_PEDROBRAS_COMANDO_H

#include <sstream>
#include <string>
#include <iostream>
#include <vector>
#include <cmath>
#include <fstream>
#include <initializer_list>
#include <tuple>
#include <limits>
#include "Ilha.h"
#include "Jogador.h"

using namespace std;

class Comando {
    Ilha * ilha;
    Jogador * jogador;
    vector<tuple<Ilha*,Jogador*,string>> saveGames; // guarda os dados da ilha e do jogador no momento
    bool ilhaCriada = false;    // parametro para verificar ao ler o ficheiro ou ao inserir manualmente
    bool config = false;    // parametro para verificar se esta a ser lido o ficheiro de configuração
public:
    Comando(Ilha & i, Jogador & j);
    void configuracao();
    bool carregaFicheiro(string f);
    void eliminaSave(string nome);
    bool criaCmd(string cmd);
    bool verificaCmd(string cmd);
    bool verificaDimensoes(int narg2, int narg3);
    bool verificaZona(string zona);
    bool verificaEdificio(string edificio);
    bool verificaTrabalhador(string trabalhador);
    bool verificaRecursos(string recurso);
    bool verificaNomeSave(string nome);
    bool verificaNumero(const string& s);
    bool verificaConstrucao(string arg2, int narg2, int narg3);
    void apresentacao();
};

#endif //POO_TP1_RUBENSANTOS_PEDROBRAS_COMANDO_H
