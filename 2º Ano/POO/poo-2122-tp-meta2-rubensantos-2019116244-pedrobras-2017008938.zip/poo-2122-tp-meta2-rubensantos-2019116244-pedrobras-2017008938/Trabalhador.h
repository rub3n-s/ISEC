//
// Created by rsantos on 04/11/2021.
//

#ifndef POO_TP1_RUBENSANTOS_PEDROBRAS_TRABALHADOR_H
#define POO_TP1_RUBENSANTOS_PEDROBRAS_TRABALHADOR_H

#include <iostream>
#include <initializer_list>
#include <string>
#include <sstream>
#include <vector>
#include <tuple>
#include <ctime>

using namespace std;

class Trabalhador {
    static int contID;
    int id;
    int diaDespedimento;
    int probDespedir;
    bool pas = false;
    bool descansa = false;
    bool movido = false;
protected:
    char tipo;
    int preco;
    int dia;
public:
    Trabalhador(const char& t, int p, int d);
    Trabalhador();
    virtual ~Trabalhador();

    virtual char getTipo() const;
    virtual int getPreco() const;
    virtual void setPreco(int p);

    int getId() const;
    int getDia() const;
    bool despedir(int dia);
    void lenhadorDescansa(int d);
    bool verificaDescansa();
    void acabouDescanso();
    void setProbDespedir(int prob);
    void setMovido();
    bool getMovido();
};


#endif //POO_TP1_RUBENSANTOS_PEDROBRAS_TRABALHADOR_H
