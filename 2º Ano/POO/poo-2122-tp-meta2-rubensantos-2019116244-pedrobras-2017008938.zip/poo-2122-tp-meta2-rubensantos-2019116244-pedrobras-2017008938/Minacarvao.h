//
// Created by rsantos on 24/12/2021.
//

#ifndef POO_TP1_RUBENSANTOS_PEDROBRAS_MINACARVAO_H
#define POO_TP1_RUBENSANTOS_PEDROBRAS_MINACARVAO_H

#include "Edificio.h"

class Minacarvao : public Edificio {
    string recurso;
    int produz;
    int precoNivelEuros;
    int nivel;
    int capacidade;
    int armazenado;
protected:
    string designacao;
    int preco;
public:
    Minacarvao(string const& desig, int prec);

    string getDesignacao() const override;
    string getRecurso() const override;
    int getPreco() const override;
    void setPreco(int p) override;
    int getCapacidade() const override;
    int getNivel() const override;
    int getPrecoNivel() const override;
    //int getPrecoNivelViga() const;
    void aumentaNivel() override;
    void armazena(int quantidade) override;
    void producaoDiaria(int multiplicador) override;

    int getArmazenado() const override;
    void setArmazenado(int quantidade) override;
};


#endif //POO_TP1_RUBENSANTOS_PEDROBRAS_MINACARVAO_H
