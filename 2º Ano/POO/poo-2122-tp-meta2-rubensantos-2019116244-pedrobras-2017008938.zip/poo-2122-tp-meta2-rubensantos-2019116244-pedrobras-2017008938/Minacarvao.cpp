//
// Created by rsantos on 24/12/2021.
//

#include "Minacarvao.h"

Minacarvao::Minacarvao(string const& desig, int prec) : designacao(desig), preco(prec), Edificio(desig,prec) {
    recurso = "carvao";
    produz = 2; // 2 kg de carvao por dia
    precoNivelEuros = 10;
    capacidade = 100; // capacidade do armazem
    nivel = 1;
    armazenado = 0;
}

string Minacarvao::getDesignacao() const { return designacao; }

string Minacarvao::getRecurso() const { return recurso; }

int Minacarvao::getPreco() const { return preco; }

void Minacarvao::setPreco(int p) { preco = p; }

int Minacarvao::getCapacidade() const { return capacidade; }

int Minacarvao::getNivel() const { return nivel; }

int Minacarvao::getPrecoNivel() const { return precoNivelEuros; }

//int Minacarvao::getPrecoNivelViga() const { return precoNivelViga; }

void Minacarvao::aumentaNivel() {
    if (nivel < 5) {
        capacidade+=10;
        nivel++;
        produz++;
        cout << "Nível aumentado com sucesso. Nivel atual: " << nivel << endl;
    }
}

void Minacarvao::armazena(int quantidade) {
    if (armazenado+quantidade <= capacidade)
        armazenado += quantidade;
    else {
        armazenado = capacidade;
        cout << "Lotação máxima atingida na mina de ferro." << endl;
    }
}

void Minacarvao::producaoDiaria(int multiplicador) {   // ha zonas que produz a duplicar
    if (armazenado + produz * multiplicador <= capacidade)
        armazenado += produz * multiplicador;
    else {
        armazenado = capacidade;
        cout << "Lotação máxima atingida na mina de ferro." << endl;
    }
}

int Minacarvao::getArmazenado() const { return armazenado; }

void Minacarvao::setArmazenado(int quantidade) { armazenado -= quantidade; }