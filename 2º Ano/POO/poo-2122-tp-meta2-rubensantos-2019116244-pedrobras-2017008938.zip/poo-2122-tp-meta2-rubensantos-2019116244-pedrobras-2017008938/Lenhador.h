//
// Created by rsantos on 26/12/2021.
//

#ifndef POO_TP1_RUBENSANTOS_PEDROBRAS_LENHADOR_H
#define POO_TP1_RUBENSANTOS_PEDROBRAS_LENHADOR_H

#include "Trabalhador.h"

class Lenhador : public Trabalhador {
protected:
    char tipo;
    int preco;
    int dia;
public:
    Lenhador(const char& tip, int prec, int di);

    char getTipo() const override;
    int getPreco() const override;
    void setPreco(int p) override;
};


#endif //POO_TP1_RUBENSANTOS_PEDROBRAS_LENHADOR_H
