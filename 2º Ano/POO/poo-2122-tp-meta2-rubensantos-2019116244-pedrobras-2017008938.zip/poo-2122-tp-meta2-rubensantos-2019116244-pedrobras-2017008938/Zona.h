//
// Created by rsantos on 04/11/2021.
//

#ifndef POO_TP1_RUBENSANTOS_PEDROBRAS_ZONA_H
#define POO_TP1_RUBENSANTOS_PEDROBRAS_ZONA_H

#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include "Trabalhador.h"
#include "Edificio.h"

using namespace std;

class Zona {
    int linha;  // identifica a linha da zona
    int coluna; // identifica a coluna da zona
    string tipoZona;    // pantano, montanha, ...
    Edificio *edificio = nullptr;  // apenas aceita 1 edificio
    //Trabalhador *trabalhadores;
    vector<Trabalhador*> trabalhadores;
    int numTrabalhadores;   // numero de trabalhadores
    bool temEdificio = false;   // verifica se já existe um edificio
    bool edificioLigado = false;

    int contDias;
    double producao;
    bool produz = false;
    int nArvores;
    int precoConstrucao;
    double armazem;
    string recursoArmazenado;
    string materialProducao;
    int probDespedir;
    double producaoDiaria;
public:
    Zona();
    Zona(int lin, int col, string tipoZ);
    ~Zona();
    bool verificaMaterial(string material);
    string getTipoZona() const;
    int getLinha() const;
    int getColuna() const;
    string getAsString() const;
    int getPrecoConstrucao() const;
    double getMaterial() const;
    void retiraMaterial(double quantidade);
    void adicionaMaterial(double quantidade);
    double getMaterialEdificio() const;
    void retiraMaterialEdificio(int quantidade);
    string getMaterialProducao() const;
    bool verificaProducao() const;
    void setRecursoArmazenado(string recurso);
    string getRecursoArmazenado() const;
    /*==== Condicoes Diarias ====*/
    void condicoesTrabalhador(int dia);
    void condicoesZona();
    void edificioProduz();
    void relatorioDiario(int dia);
    /*==== Edificio ====*/
    void setEdificio(Edificio *e);
    string getEdificio() const;
    string getRecursoEdificio() const;
    int getPrecoEdificio() const;
    void setPrecoEdificio(int preco) const;
    bool existeEdificio();
    void ligaEdificio();
    void desligaEdificio();
    void eliminaEdificio();
    bool edificioEstaLigado();
    void armazenaRecursoEdificio(int quantidade);
    void aumentaNivel();
    /*==== Trabalhadores ====*/
    void setTrabalhador(Trabalhador *t);
    bool getTrabalhador(char const& tipo) const;
    void getTrabalhadoresList() const;
    void setPrecoTrabalhador(const char& desig,int preco);
    int getNumTrabalhadores() const;
    bool existeTrabalhador(int id);
    bool trabalhadorMovido(int id);
    void podeMoverTrabalhadores();
    Trabalhador* eliminaTrabalhador(int id);
    void moveTrabalhador(Trabalhador *t);
};


#endif //POO_TP1_RUBENSANTOS_PEDROBRAS_ZONA_H
