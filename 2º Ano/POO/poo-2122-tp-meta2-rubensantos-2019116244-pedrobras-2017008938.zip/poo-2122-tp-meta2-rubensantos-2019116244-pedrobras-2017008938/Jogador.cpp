//
// Created by rsantos on 03/12/2021.
//

#include "Jogador.h"

// vector que guarda tipo de recurso, quantidade e preço
vector<tuple<string,double,double>> listaRecursosJogador = {
        {"ferro", 0.0, 1.0},    //nome, quantidade, preco p/ unidade
        {"aco", 0.0, 2.0},
        {"carvao", 0.0, 1.0},
        {"madeira", 0.0, 1.0},
        {"viga", 0.0, 2.0},
        {"eletricidade",0.0, 1.5}
};

Jogador::Jogador() { dinheiro = 0.0; }

Jogador::Jogador(const Jogador& ob) {
    *this = ob;
}

double Jogador::getDinheiro() const { return dinheiro; }

double Jogador::getVigas() const {
    for (auto r : listaRecursosJogador)
        if (get<0>(r) == "viga")
            return get<1>(r);
    return 0;
}

void Jogador::tiraViga(int quantidade) {
    for (auto &r : listaRecursosJogador)
        if (get<0>(r) == "viga")
            get<1>(r) -= quantidade;
}


void Jogador::getListaRecursos() {
    cout << "\nRecursos do jogador: " << endl;
    for (auto r : listaRecursosJogador) {
        cout << "\t" << get<0>(r) << ": " << get<1>(r) << endl;
    }
    cout << endl;
}

void Jogador::recebeRecursos(string const& recurso, double quantidade) {
    for (auto &r : listaRecursosJogador) {
        if (get<0>(r) == recurso && quantidade > 0.0) {
            get<1>(r) += quantidade; // adiciona a quantidade ao recurso da lista
            if (get<0>(r) == "eletricidade")
                cout << quantidade << " kg de " << recurso << " adicionados à lista do jogador." << endl;
            else if (get<0>(r) == "viga")
                cout << quantidade << " unidades de " << recurso << "(s) adicionadas à lista do jogador." << endl;
            else
                cout << quantidade << "kg de " << recurso << " adicionados à lista do jogador." << endl;
        }
    }
}

void Jogador::vendeRecursos(string const& recurso, double quantidade) {
    for (auto &r : listaRecursosJogador) {
        if (get<0>(r) == recurso && get<1>(r) >= quantidade) {
            cout << "Vendeu " << quantidade << " unidade(s) de '" << get<0>(r) << "' por " << quantidade * get<2>(r) << " euros\n";
            dinheiro += quantidade * get<2>(r); // adiciona a quantia ao dinheiro do jogador
            get<1>(r) -= quantidade;    // retira a quantidade vendida da lista
            cout << "Saldo atual: " << dinheiro << endl;
        } else if (get<0>(r) == recurso && get<1>(r) < quantidade)
            cout << "Não tem recursos suficientes" << endl;
    }
}

void Jogador::transformaRecurso(string const& recurso) {
    bool semRecursos = false;
    for (auto &r : listaRecursosJogador) {
        // se existe uma serração -> transforma 2kg de madeira em 1 viga
        if (recurso == "viga" && get<0>(r) == recurso) {
            for (auto &r2 : listaRecursosJogador) {
                if (get<0>(r2) == "madeira" && get<1>(r2) >= 2.0) {
                    get<1>(r2) -= 2;    // remove 2kg de madeira
                }
                else if (get<0>(r2) == "madeira" && get<1>(r2) < 2.0) {
                    cout << "Madeira insuficente para a transformação. Em falta: " << 2 - get<1>(r) << endl;
                    semRecursos = true;
                }
            }
            if (!semRecursos) { // se houver recursos suficientes
                get<1>(r) += 1; // adiciona 1 viga
                cout << "2kg de madeira transformadas em 1 viga." << endl;
            }
        }
        // se existe fundicao -> transforma 1.5 kg de ferro e 0.5 kg de carvão em 1 barra de aço
        else if (recurso == "aco" && get<0>(r) == recurso) {
            for (auto &r2 : listaRecursosJogador) {
                if (get<0>(r2) == "ferro" && get<1>(r2) >= 1.5) {
                    get<1>(r2) -= 1.5;    // remove 1.5 kg de ferro
                }
                else if (get<0>(r2) == "carvao" && get<1>(r2) >= 0.5) {
                    get<1>(r2) -= 0.5;    // remove 0.5 kg de carvao
                }
                else if (get<0>(r2) == "ferro" && get<1>(r2) < 1.5) {
                    cout << "Ferro insuficente para a transformação. Em falta: " << 1.5 - get<1>(r) << endl;
                    semRecursos = true;
                }
                else if (get<0>(r2) == "carvao" && get<1>(r2) < 0.5) {
                    cout << "Carvão insuficente para a transformação. Em falta: " << 0.5 - get<1>(r) << endl;
                    semRecursos = true;
                }
            }
            if (!semRecursos) { // se houver recursos suficientes
                get<1>(r) += 1; // adiciona 1 barra de aço
                cout << "1.5kg de ferro + 0.5kg de carvão transformados em 1 barra de aço." << endl;
            }
        }
        // se existe central eletrica -> transforma 1 kg de carvao em 1 kw de eletricidade
        else if (recurso == "eletricidade" && get<0>(r) == recurso) {
            for (auto &r2 : listaRecursosJogador) {
                if (get<0>(r2) == "carvao" && get<1>(r2) >= 1) {
                    get<1>(r2) -= 1;    // remove 1kg de carvão
                }
                else if (get<0>(r2) == "carvao" && get<1>(r2) < 1) {
                    cout << "Carvão insuficente para a transformação. Em falta: " << 1 - get<1>(r) << endl;
                    semRecursos = true;
                }
            }
            if (!semRecursos) { // se houver recursos suficientes
                get<1>(r) += 1; // adiciona 1 viga
                cout << "1kg de carvão transformadas em 1kw de eletricidade." << endl;
            }
        }
        // se existe mina de carvao -> transforma 1kg de madeira em 1 kg de carvão
        else if (recurso == "carvao" && get<0>(r) == recurso) {
            for (auto &r2 : listaRecursosJogador) {
                if (get<0>(r2) == "madeira" && get<1>(r2) >= 1) {
                    get<1>(r2) -= 1;    // remove 1kg de carvao
                }
                else if (get<0>(r2) == "madeira" && get<1>(r2) < 1) {
                    cout << "Madeira insuficente para a transformação. Em falta: " << 1 - get<1>(r) << endl;
                    semRecursos = true;
                }
            }
            if (!semRecursos) {
                get<1>(r) += 1; // adiciona 1 viga
                cout << "1kg de madeira transformada em 1kg de carvão." << endl;
            }
        }
    }
}

void Jogador::depositaDinheiro(int quantia) {
        dinheiro += quantia;
        if (quantia > 0)
            cout << "\nFoi inserida a quantia de " << quantia << " euros na conta." << endl;
        else
            cout << "\nFoi retirada a quantia de " << quantia << " euros na conta." << endl;
        cout << "Saldo atual: " << dinheiro << endl;
}

bool Jogador::tiraDinheiro(int quantia) {
    if (dinheiro >= quantia) {
        dinheiro -= quantia;
        return true;
    }
    cout << "\nNão tem dinheiro suficiente." << endl;
    return false;
}

string Jogador::getAsString() const {
    ostringstream os;
    os << "\nDinheiro: " << dinheiro << endl;
    os << "Lista de recursos: \n";
    for (auto r : listaRecursosJogador)
        os << get<0>(r) << ", quantidade: " << get<1>(r) << ", preco: " << get<2>(r) << endl;
    cout << endl;
    return os.str();
}