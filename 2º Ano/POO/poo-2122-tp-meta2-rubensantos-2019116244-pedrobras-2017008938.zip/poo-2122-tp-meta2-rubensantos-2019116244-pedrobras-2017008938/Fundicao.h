//
// Created by rsantos on 24/12/2021.
//

#ifndef POO_TP1_RUBENSANTOS_PEDROBRAS_FUNDICAO_H
#define POO_TP1_RUBENSANTOS_PEDROBRAS_FUNDICAO_H

#include "Edificio.h"

class Fundicao : public Edificio {
    string recurso;
protected:
    string designacao;
    int preco;
public:
    Fundicao(string const& desig, int prec);

    string getDesignacao() const override;
    string getRecurso() const override;
    int getPreco() const override;
    void setPreco(int p) override;
};


#endif //POO_TP1_RUBENSANTOS_PEDROBRAS_FUNDICAO_H
