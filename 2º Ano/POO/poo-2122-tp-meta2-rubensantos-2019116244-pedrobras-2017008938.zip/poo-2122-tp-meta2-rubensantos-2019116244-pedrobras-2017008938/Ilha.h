//
// Created by rsantos on 04/11/2021.
//

#ifndef POO_TP1_RUBENSANTOS_PEDROBRAS_ILHA_H
#define POO_TP1_RUBENSANTOS_PEDROBRAS_ILHA_H

#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <random>
#include <iterator>
#include <fstream>
#include <initializer_list>
#include <algorithm>
#include "Zona.h"
#include "Minacarvao.h"
#include "Minaferro.h"
#include "Fundicao.h"
#include "CentralEle.h"
#include "Bateria.h"
#include "Serracao.h"
#include "Operario.h"
#include "Mineiro.h"
#include "Lenhador.h"

using namespace std;

class Ilha {
    Zona ** zonas;
    int linhas;
    int colunas;
    static int dia;
public:
    Ilha(const Ilha& ob);
    Ilha();
    ~Ilha();
    Ilha &operator=(const Ilha & ob);
    void setLinhas(int lin);
    void setColunas(int col);
    int getLinhas() const;
    int getColunas() const;
    void incrementaDia();
    void escreveLinhaSup(int lin, int col, int cont);
    void escreveLinhaInf(int lin, int col, int cont, int i);
    void listaIlha();
    int devolvePrecoEdificio(string desig, int lin, int col) const;
    int devolvePrecoTrabalhador(char const& desig) const;
    bool verificaAdjacencia(const string& nome, int tipo, int lin, int col, int *l, int *c);
    void listaPrecos();
    bool verificaMaterialI(string material);
    /*==== Jogador ====*/
    string getTipoRecurso(int lin, int col) const;
    double getQuantidadeRecurso(int lin, int col) const;
    string getTipoRecursoEdificio(int lin, int col) const;
    int getQuantidadeRecursoEdificio(int lin, int col) const;
    int getUpgradeEuros(int lin, int col) const;
    string getTipoEdificio(int lin, int col) const;
    /*==== Zona ====*/
    void criaZonas(vector<string> listaZon);
    void listaZona(int linha, int coluna);
    void listaTodasZonas();
    void acoesAmanhecer();
    void acoesAnoitecer();
    /*==== Edificio ====*/
    void recebeEdificio(const string& edificio,int linha, int coluna);
    void procuraEdificio(string const& edificio, int preco);
    void onOffEdificio(string const& arg1, int lin, int col);
    int getPrecoEdificio(int lin,int col) const;
    bool verificaEdificio(int lin, int col);
    bool verificaTipoDeEdificio(string recurso);
    bool verificaEdificioLigado(int lin, int col);
    void levelUp(int lin, int col);
    /*==== Trabalhador ====*/
    void recebeTrabalhador(const string& tipo);
    void procuraTrabalhador(char const& trabalhador, int preco);
    Zona* getZonasPas(); // recolhe zonas de pastagem
    void moverTrabalhador(int id, int lin, int col);
    void removerTrabalhador(int id);
};
#endif //POO_TP1_RUBENSANTOS_PEDROBRAS_ILHA_H
