//
// Created by rsantos on 24/12/2021.
//

#ifndef POO_TP1_RUBENSANTOS_PEDROBRAS_CENTRALELE_H
#define POO_TP1_RUBENSANTOS_PEDROBRAS_CENTRALELE_H

#include "Edificio.h"

class CentralEle : public Edificio {
    string recurso;
    int produz;
    int capacidade;
    int armazenado;
    int nivel;
protected:
    string designacao;
    int preco;
public:
    CentralEle(string const& desig, int prec);

    string getDesignacao() const override;
    string getRecurso() const override;
    int getPreco() const override;
    void setPreco(int p) override;
    int getCapacidade() const override;
    int getNivel() const override;
    void armazena(int quantidade) override;
    void producaoDiaria(int multiplicador) override;

    int getArmazenado() const override;
    void setArmazenado(int quantidade) override;
};


#endif //POO_TP1_RUBENSANTOS_PEDROBRAS_CENTRALELE_H
