//
// Created by rsantos on 24/12/2021.
//

#include "Minaferro.h"

Minaferro::Minaferro(string const& desig, int prec) : designacao(desig), preco(prec),Edificio(desig,prec) {
    recurso = "ferro";
    produz = 2; // 2 kg de ferro por dia
    precoNivelEuros = 15;
    capacidade = 100; // capacidade do armazem
    nivel = 1;
    armazenado = 0;
}

string Minaferro::getDesignacao() const { return designacao; }

string Minaferro::getRecurso() const { return recurso; }

int Minaferro::getPreco() const { return preco; }

void Minaferro::setPreco(int p) { preco = p; }

int Minaferro::getCapacidade() const { return capacidade; }

int Minaferro::getNivel() const { return nivel; }

int Minaferro::getPrecoNivel() const { return precoNivelEuros; }

//int Minaferro::getPrecoNivelViga() const { return precoNivelViga; }

void Minaferro::aumentaNivel() {
    if (nivel < 5) {
        capacidade+=10;
        nivel++;
        produz++;
        cout << "Nível aumentado com sucesso. Nivel atual: " << nivel << endl;
    }
}

void Minaferro::armazena(int quantidade) {
    if (armazenado+quantidade <= capacidade)
        armazenado += quantidade;
    else {
        armazenado = capacidade;
        cout << "Lotação máxima atingida na mina de ferro." << endl;
    }
}

void Minaferro::producaoDiaria(int multiplicador) {   // ha zonas que produz a duplicar
    if (armazenado + produz * multiplicador <= capacidade)
        armazenado += produz * multiplicador;
    else {
        armazenado = capacidade;
        cout << "Lotação máxima atingida na mina de ferro." << endl;
    }
}

int Minaferro::getArmazenado() const { return armazenado; }

void Minaferro::setArmazenado(int quantidade) { armazenado -= quantidade; }