//
// Created by rsantos on 10/11/2021.
//

#ifndef POO_TP1_RUBENSANTOS_PEDROBRAS_EDIFICIO_H
#define POO_TP1_RUBENSANTOS_PEDROBRAS_EDIFICIO_H

#include <iostream>
#include <string>
#include <vector>
#include <tuple>

using namespace std;

class Edificio {
    string recurso;
    int capacidade;
    int precoNivel;
    int nivel;
    int produz;
    int armazenado;
protected:
    string designacao;
    int preco;
public:
    Edificio(string const& desig, int prec);
    Edificio();
    virtual ~Edificio();

    virtual string getDesignacao() const;
    virtual string getRecurso() const;
    virtual int getPreco() const;
    virtual void setPreco(int p);
    virtual int getCapacidade() const;
    virtual int getNivel() const;
    virtual int getPrecoNivel() const;
    virtual void aumentaNivel();
    virtual void armazena(int quantidade);
    virtual void producaoDiaria(int multiplicador);
    virtual int getArmazenado() const;
    virtual void setArmazenado(int quantidade);
};
#endif //POO_TP1_RUBENSANTOS_PEDROBRAS_EDIFICIO_H
