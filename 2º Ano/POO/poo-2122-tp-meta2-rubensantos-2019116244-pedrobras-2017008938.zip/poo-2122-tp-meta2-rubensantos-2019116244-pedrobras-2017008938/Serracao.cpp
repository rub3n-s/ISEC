//
// Created by rsantos on 24/12/2021.
//

#include "Serracao.h"

Serracao::Serracao(string const& desig, int prec) : designacao(desig), preco(prec), Edificio(desig, prec) {
    recurso = "madeira";
}

string Serracao::getDesignacao() const { return designacao; }

string Serracao::getRecurso() const { return recurso; }

int Serracao::getPreco() const { return preco; }

void Serracao::setPreco(int p) { preco = p; }