//
// Created by rsantos on 04/11/2021.
//

#include "Zona.h"

vector<string> listaMateriais = {
        "ferro",
        "aco",
        "madeira",
        "carvao",
        "eletricidade",
        "viga"
};

bool Zona::verificaMaterial(string material) {
    for (auto l : listaMateriais)
        if (l == material)
            return true;
    return false;
}
/*---------------------------------------------------------------------------------------------*/

Zona::Zona() {}

Zona::Zona(int lin, int col, string tipoZ) : linha(lin), coluna(col), tipoZona(tipoZ) {
    contDias = 0;
    numTrabalhadores = 0;
    probDespedir = 0;
    armazem = 0;
    if (tipoZ == "znX") {
        do {
            cout << "Insira os parametros para a zonaX: " << endl;
            cout << "\tproducao (multiplicador): "; cin >> producao;
            cout << "\tproducao (ferro/aco/madeira/elec/viga): "; cin >> materialProducao;
            cout << "\tproducao diaria: "; cin >> producaoDiaria;
            cout << "\tpreco construcao: "; cin >> precoConstrucao;
            cout << "\tprobabilidade despedir: "; cin >> probDespedir;
            if(producao < 0 || precoConstrucao < 0 || probDespedir < 0)
                cout << "Valores inseridos tem de ser maiores ou iguais a zero." << endl;
            if (!verificaMaterial(materialProducao))
                cout << "Material indisponivel." << endl;
        } while(producao < 0 || precoConstrucao < 0 || probDespedir < 0 || !verificaMaterial(materialProducao));
        nArvores = 0;
        produz = true;
    } else if (tipoZ == "flr") {
        nArvores = rand()%(40-20 + 1) + 20; // 20 a 40 arvores na zona
        producao = 1.0;
        precoConstrucao = 1;
        materialProducao = "madeira";
        produz = true;
        producaoDiaria = 1;
    } else if (tipoZ == "mnt") {
        nArvores = 0;
        producao = 1.0;
        precoConstrucao = 2; // preco de contrucao é o dobro
        materialProducao = "ferro";
        produz = true;
        producaoDiaria = 0.1;
    } else {
        nArvores = 0;
        producao = 1.0;
        precoConstrucao = 1;
        produz = false;
        producaoDiaria = 0;
    }
}
Zona::~Zona() {
    delete edificio;
    edificio = nullptr;
    for (auto t : trabalhadores)
        delete t;
    trabalhadores.clear();
}

int Zona::getLinha() const { return linha; }
int Zona::getColuna() const { return coluna; }
string Zona::getTipoZona() const { return tipoZona; }
int Zona::getPrecoConstrucao() const { return precoConstrucao; }
void Zona::setRecursoArmazenado(string recurso) { recursoArmazenado = recurso; }
string Zona::getRecursoArmazenado() const { return recursoArmazenado; }

/*==============================  Jogador  ==============================*/

double Zona::getMaterial() const { return armazem; }
void Zona::retiraMaterial(double quantidade) { armazem -= quantidade; }
void Zona::adicionaMaterial(double quantidade) { armazem += quantidade; }
double Zona::getMaterialEdificio() const { return edificio->getArmazenado(); }
void Zona::retiraMaterialEdificio(int quantidade) { edificio->setArmazenado(quantidade); }
string Zona::getMaterialProducao() const { return materialProducao; }
bool Zona::verificaProducao() const { return produz; }

/*==============================  Edificio  ==============================*/

void Zona::setEdificio(Edificio *e) {   // caso passe na verificacao de ter edificio, o edificio é atribuido à zona
    edificio = e;
    temEdificio = true;
}

string Zona::getEdificio() const {
    // devolve edificio para alterar o preco
    return edificio->getDesignacao();
}

string Zona::getRecursoEdificio() const {
    // devolve o recurso que o edificio armazena
    return edificio->getRecurso();
}

int Zona::getPrecoEdificio() const {
    // devolve o preço do edificio
    return edificio->getPreco();
}

void Zona::setPrecoEdificio(int preco) const {
    // devolve o preço do edificio
    edificio->setPreco(preco);
}

bool Zona::existeEdificio() { // para verificar fora da classe se a zona já tem um edificio
    if (temEdificio)
        return true;
    return false;
}

void Zona::ligaEdificio() {
    if (!edificioLigado && temEdificio) {
        edificioLigado = true;
        cout << "\nEdificio foi ligado com sucesso." << endl;
    }
    else if (edificioLigado && temEdificio)
        cout << "\nEdificio já está ligado." << endl;
    else
        cout << "\nNão existe edificio." << endl;
    return;
}

void Zona::desligaEdificio() {
    if (edificioLigado && temEdificio) {
        edificioLigado = false;
        cout << "\nEdificio foi desligado com sucesso." << endl;
    }
    else if (!edificioLigado && temEdificio)
        cout << "\nEdificio já está desligado." << endl;
    else
        cout << "\nNão existe edificio." << endl;
    return;
}

bool Zona::edificioEstaLigado() {
    if (edificioLigado)
        return true;
    return false;
}

void Zona::armazenaRecursoEdificio(int quantidade) {
    edificio->armazena(quantidade);
}

void Zona::eliminaEdificio() {
    delete edificio;
    edificio = nullptr;
    temEdificio = false;
}

void Zona::condicoesTrabalhador(int dia) {
    /*for (int i = 0; i < numTrabalhadores; i++) {
        if (trabalhadores[i].despedir(dia)) {   // se for verdade, elimina trabalhador[i]
            Trabalhador *aux = new Trabalhador[numTrabalhadores-1];
            for (int j = 0; j < numTrabalhadores; j++) {
                if (i != j) { // não copia o trabalhador que verificou a condicao de despedimento
                    aux[j] = trabalhadores[j];
                    numTrabalhadores--;
                    delete[] trabalhadores;
                    trabalhadores = aux;
                }
            }
        }
    }*/
    int it = 0;
    for (auto t : trabalhadores) {
        if (t->getTipo() == 'L') {
            if (t->verificaDescansa())
                t->acabouDescanso();
            else
                t->lenhadorDescansa(dia);
        }
        else {  // nao se despedem na zona de pastagem
            if (t->despedir(dia) && tipoZona != "pas") {
                trabalhadores.erase(trabalhadores.begin() + it);
                numTrabalhadores--;
            }
        }
        it++;
    }
}

void Zona::condicoesZona() {
    if (tipoZona == "dsr") {
        if (temEdificio && edificio->getDesignacao() == "mnF")
            producao = 0.5;
    } else if (tipoZona == "flr") {
        if (temEdificio) // se existir edificio, morre 1 arvore por dia e nao nascem novas arvores
            nArvores--;
        else {  // caso contrario, cresce 1 arvore a cada 2 dois
            if (contDias == 2) {
                nArvores++;
                contDias = 0;
            }
        }
        contDias++;
        double kgMadeira = 0; int lenhadores = 0;
        if (numTrabalhadores > 0) {
            for (auto t : trabalhadores)    // verifica o num de lenhadores da zona, e os que estao a descansar
                if (t->getTipo() == 'L' && !t->verificaDescansa())
                    lenhadores++;
            kgMadeira += producaoDiaria * lenhadores;
            armazem += kgMadeira;
        }
    } else if (tipoZona == "mnt") { // montanha
        if (temEdificio && edificio->getDesignacao() == "mnF")
            producao = 2;   // minas aumenta producao em 100%
        double kgFerro = 0; int funcionarios = 0;
        if (numTrabalhadores > 0) {
            for (auto t : trabalhadores)
                if (!t->verificaDescansa()) // se nao houver nenhum lenhador a descansar
                    funcionarios++;
            kgFerro = producaoDiaria * funcionarios;
            armazem += kgFerro;
        }
        // probabilidade de se despedirem aumenta em 5%
        for (auto t : trabalhadores)
            t->setProbDespedir(5);
    } else if (tipoZona == "pnt") { // pantano
        // passados 10 dias edificio desaparece, funcionarios despedem-se
        if (existeEdificio())
            contDias++;
        if (contDias == 10 && existeEdificio()) {
            int it = 0;
            eliminaEdificio();
            for (auto t : trabalhadores) {
                trabalhadores.erase(trabalhadores.begin()+it);
                it++;
            }
            contDias = 0;
        }
    }
    else if (tipoZona == "znx") {
        double materialZnX = 0; int funcionarios = 0;
        if (numTrabalhadores > 0) {
            for (auto t : trabalhadores)
                if (!t->verificaDescansa()) // se nao houver nenhum lenhador a descansar
                    funcionarios++;
            materialZnX = producaoDiaria * funcionarios;
            armazem += materialZnX;
        }
        // probabilidade de se despedirem aumenta em x%
        for (auto t : trabalhadores)
            t->setProbDespedir(probDespedir);
    }
}

void Zona::relatorioDiario(int dia) {
    cout << "Produzido na zona(" << linha << "," << coluna << "), no dia " << dia << ": ";
    if (tipoZona == "flr" || tipoZona == "mnt" || tipoZona == "znX")
        cout << materialProducao << " -> " << armazem;
    cout << endl;
}

void Zona::edificioProduz() { edificio->producaoDiaria(producao); }

void Zona::aumentaNivel() { edificio->aumentaNivel(); }

/*==============================  Trabalhadores  ==============================*/

void Zona::setTrabalhador(Trabalhador *t) { // insere o trabalhador no vetor e incrementa o contador
    /*Trabalhador *aux = new Trabalhador[numTrabalhadores+1];
    if (numTrabalhadores == 0) {
        aux[numTrabalhadores] = *t;
        trabalhadores = aux;
    }
    else {
        for (int i = 0; i < numTrabalhadores; i++)
            aux[i] = trabalhadores[i];
        aux[numTrabalhadores] = *t;
        delete[] trabalhadores;
        trabalhadores = aux;
    }*/
    numTrabalhadores++;
    trabalhadores.push_back(t);
}

bool Zona::getTrabalhador(char const& tipo) const {
    for (auto t : trabalhadores)
        if (t->getTipo() == tipo)
            return true;
    return false;
}

void Zona::getTrabalhadoresList() const {
    int contador = 0;
    for (auto t : trabalhadores) {
        contador++;
        if (contador <= 5)
            cout << t->getTipo();
        else
            return;
    }
}

int Zona::getNumTrabalhadores() const { return numTrabalhadores; }

bool Zona::existeTrabalhador(int id) {
    for (auto t : trabalhadores)
        if (t->getId() == id)
            return true;
    return false;
}

bool Zona::trabalhadorMovido(int id) {
    for (auto t: trabalhadores) {
        if (t->getId() == id && t->getMovido())
            return true;    // ja foi movido hoje
    }
    return false;
}

Trabalhador* Zona::eliminaTrabalhador(int id) {
    int it = 0;
    for (auto t : trabalhadores) { // percorre array de trabalhadores
        if (t->getId() == id) {  // não pode ter sido movido neste dia
            trabalhadores.erase(trabalhadores.begin() + it);
            numTrabalhadores--;
            return t;
        }
        it++;
    }
    return nullptr;
}

void Zona::moveTrabalhador(Trabalhador *t) {
    trabalhadores.push_back(t);
    t->setMovido();
    numTrabalhadores++;
    cout << "\nTrabalhador movido com sucesso para a zona(" << linha << "," << coluna << ")." << endl;
}

void Zona::setPrecoTrabalhador(const char& desig,int preco) {
    for (auto t : trabalhadores)
        if (t->getTipo() == desig)
            t->setPreco(preco);
}

void Zona::podeMoverTrabalhadores() {
    for (auto t : trabalhadores)
        if (t->getMovido()) // se estiver a true (foi movido no dia anterior)
            t->setMovido();
}
/*==============================  Listar  ==============================*/

string Zona::getAsString() const {
    ostringstream os;
    os << "Zona(" << linha << "," << coluna << ")" << endl;
    os << "Tipo: " << tipoZona << endl;
    if (tipoZona == "flr")
        os << "Num. de arvores: " << nArvores << endl;
    if (verificaProducao())
        os << "Zona produz diariamente (" << materialProducao << "): " << producaoDiaria << endl;
    os << "Armazenado na zona: " << armazem << endl;
    os << "Edificio: ";
    if (temEdificio) {    // so apresenta a designacao se existir um edifico
        os << edificio->getDesignacao() << ", preco: " << edificio->getPreco() << ", estado: ";
        if (edificioLigado)
            os << "ligado, ";
        else
            os << "desligado, ";
        if (edificio->getDesignacao() != "fun")
            os << "capacidade: " << edificio->getCapacidade() << ", nivel: " << edificio->getNivel() << ", armazenado: " << edificio->getArmazenado();
        if (edificio->getDesignacao() == "ele") {
            os << "kw" << endl;
        } else {
            os << "kg" << endl;
        }
        if (tipoZona=="pnt")
            os << "O edificio vai desabar dentro de " << 10 - contDias << " dias." << endl;
    }
    else
        os << "nao existe edificio" <<endl;
    os << "Trabalhadores: ";
    if (!trabalhadores.empty()) {
        for (auto t :trabalhadores)
            if (t->getMovido() && t->verificaDescansa())
                os << t->getId() << "." << t->getDia() << " " << t->getTipo() << " " << t->getPreco() << " (movido e a descnsar) | ";
            else if (t->verificaDescansa())
                os << t->getId() << "." << t->getDia() << " " << t->getTipo() << " " << t->getPreco() << " (a descansar) | ";
            else if (t->getMovido())
                os << t->getId() << "." << t->getDia() << " " << t->getTipo() << " " << t->getPreco() << " (movido) | ";
            else
                os << t->getId() << "." << t->getDia() << " " << t->getTipo() << " " << t->getPreco() << " | ";
    }
    else
        os << "não existem trabalhadores";
    os << "\nNumero trabalhadores: " << numTrabalhadores << "\n" << endl;
    return os.str();
}