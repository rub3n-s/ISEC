//
// Created by rsantos on 03/12/2021.
//

#ifndef POO_TP1_RUBENSANTOS_PEDROBRAS_JOGADOR_H
#define POO_TP1_RUBENSANTOS_PEDROBRAS_JOGADOR_H

#include <iostream>
#include <string>
#include <vector>
#include <sstream>

using namespace std;

class Jogador {
    double dinheiro;
public:
    Jogador();
    Jogador(const Jogador& ob);

    double getDinheiro() const;
    double getVigas() const;
    void tiraViga(int quantidade);
    void getListaRecursos();
    void recebeRecursos(string const& recurso, double quantidade);
    void vendeRecursos(string const& recurso, double quantidade);
    void transformaRecurso(string const& recurso);
    void depositaDinheiro(int quantia);
    bool tiraDinheiro(int quantia);
    string getAsString() const;
};

#endif //POO_TP1_RUBENSANTOS_PEDROBRAS_JOGADOR_H
