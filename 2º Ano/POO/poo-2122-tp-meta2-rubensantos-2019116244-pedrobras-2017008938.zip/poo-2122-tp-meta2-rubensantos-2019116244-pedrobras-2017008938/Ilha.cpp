//
// Created by rsantos on 04/11/2021.
//

#include "Ilha.h"

template<typename Iter, typename RandomGenerator>
Iter select_randomly(Iter start, Iter end, RandomGenerator& g) {
    uniform_int_distribution<> dis(0, distance(start, end) - 1);
    advance(start, dis(g));
    return start;
}

template<typename Iter>
Iter select_randomly(Iter start, Iter end) {
    static random_device rd;
    static mt19937 gen(rd());
    return select_randomly(start, end, gen);
}

vector<string> listaMateriaisI = {
        "ferro",
        "aco",
        "madeira",
        "carvao",
        "eletricidade",
        "viga"
};

bool Ilha::verificaMaterialI(string material) {
    for (auto l : listaMateriaisI)
        if (l == material)
            return true;
    return false;
}

vector<tuple<string,string,int>> infoEdificios = {
        {"minaferro","mnF",10}, // vigas
        {"minacarvao","mnC",10},    // vigas
        {"centraleletrica","ele",15},  // euros
        {"bateria","bat",10}, //10 euros e 10 vigas
        {"fundicao","fun",10},  // 10 euros
        {"serracao","ser",10}  // 10 euros
};

vector<pair<string,int>> precoNivel = {
        {"mnF",15},
        {"mnC",10},
        {"bat",5}
};

vector<tuple<string,char,int>> infoTrabalhadores = {
        {"operario",'O',15},
        {"mineiro",'M',10},
        {"lenhador",'L',20}
};

int Ilha::dia = 1; // inicializa o dia a 1

Ilha::Ilha() {}

Ilha::Ilha(const Ilha& ob) {
    *this = ob;
}

Ilha::~Ilha() {
    for (int i = 0; i < linhas; i++)
        delete[] zonas[i];
    delete[] zonas;
}

void Ilha::setLinhas(int lin) { linhas = lin; }
void Ilha::setColunas(int col) { colunas = col; }
int Ilha::getLinhas() const { return linhas; }
int Ilha::getColunas() const { return colunas; }

Ilha & Ilha::operator=(const Ilha & ob) {
    if (this == &ob) // prevencao de auto-atribuicao
    {
        return *this;
    }

    // se os dois membros da atribuição forem objetos diferentes
    linhas = ob.linhas;
    colunas = ob.colunas;
    dia = ob.dia;

    // reservar memoria dinamica para conter uma copia exclusiva dos versos do segundo membro
    zonas = new Zona*[linhas];
    for (int i = 0; i < linhas; i++)
        zonas[i] = new Zona[colunas];

    // fazer a cópia
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            zonas[i][j] = ob.zonas[i][j];
        }
    }

    return *this;
}

void Ilha::incrementaDia() { dia++; }

void Ilha::acoesAmanhecer() {
    //================= Amanhecer =================
    cout << "\n\n================= DIA " << dia << " =================\n" << endl;
    cout << "\n================= Amanhecer =================" << endl;
    cout << "\n A aplicar condições de cada zona... \n\n";
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            zonas[i][j].condicoesZona();
            zonas[i][j].podeMoverTrabalhadores();
        }
    }
}

void Ilha::acoesAnoitecer() {
    //================= Anoitecer =================
    cout << "\n================= Anoitecer =================" << endl;
    cout << "\n A aplicar condições de cada edificio... \n\n";
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            zonas[i][j].condicoesTrabalhador(dia);
            if (zonas[i][j].existeEdificio() && zonas[i][j].edificioEstaLigado()) { // se existe e ligado -> vai produzir
                // verifica se existe um operario (usado para os edificios 'ele' e 'fun' operarem)
                bool flgOperario = false;
                for (int t = 0; t < zonas[i][j].getNumTrabalhadores(); t++)
                    if (zonas[i][j].getTrabalhador('O'))
                        flgOperario = true;

                if (zonas[i][j].getEdificio() == "ele" && flgOperario) {  // verifica se ha bateria e floresta adjacente
                    int kgMadeira = 0, linhaFlr = 0, colunaFlr = 0;
                    int kwElec = kgMadeira, linhaBat = 0, colunaBat = 0;
                    if (verificaAdjacencia("flr",1,i,j,&linhaFlr,&colunaFlr)
                    && verificaAdjacencia("bat",0,i,j,&linhaBat,&colunaBat)
                    && zonas[linhaBat][colunaBat].edificioEstaLigado()) {
                        // se na zona "flr" adjacente existir madeira, retira 1 unidade, queima e transforma
                        // transforma-se em 1 kg de carvao e 1 kw de eletricidade (sao colocados no edificios adjacentes respetivos)
                        // apenas transforma se o edificio bateria estiver ligado
                        kgMadeira = zonas[linhaFlr][colunaFlr].getMaterial();
                        if (kgMadeira > 0) {
                            zonas[linhaFlr][colunaFlr].retiraMaterial(1); // queima 1kg de madeira

                            zonas[linhaBat][colunaBat].armazenaRecursoEdificio(1); // armazena 1kw de eletricidade

                            zonas[i][j].armazenaRecursoEdificio(1); // armazena 1kg de carvao na propria zona
                            zonas[i][j].setRecursoArmazenado("carvao");

                            cout << "Retirou 1 unidade de madeira da floresta" << endl;
                            cout << "Foi adicionado 1kg de carvao à central eletrica e 1kw à bateria adjacente" << endl;
                        }
                    }
                }
                else if (zonas[i][j].getEdificio() == "fun" && flgOperario) {
                    int linhaMnF = 0, colunaMnF = 0;
                    if (verificaAdjacencia("mnF",0,i,j,&linhaMnF,&colunaMnF)) {
                        int linhaMnC = 0, colunaMnC = 0;
                        int kgCarvao = 0, kgFerro = 0, kgAco = 0;
                        // 'fun' -> para produzir, para alem da 'mnF' tem de ser adjacente a uma 'mnC' ou 'ele'
                        if (verificaAdjacencia("mnC",0,i,j,&linhaMnC,&colunaMnC)) {
                            kgCarvao = zonas[linhaMnC][colunaMnC].getMaterialEdificio();
                            kgFerro = zonas[linhaMnF][colunaMnF].getMaterialEdificio();
                            if (kgCarvao > 0 && kgFerro > 0) {
                                kgAco++;
                                cout << "1kg de carvao + 1kg de ferro transformados em 1 barra de aço." << endl;
                                cout << "Foi retirado 1kg de carvao da mina de carvao e 1kg de ferro da mina ferro." << endl;
                                cout << "Mina de carvao (" << linhaMnC << "," << colunaMnC << ")" << endl;
                                cout << "Mina de ferro (" << linhaMnF << "," << colunaMnF << ")" << endl;
                            }
                            // retira o material da mina de ferro e da mina de carvao
                            zonas[linhaMnC][colunaMnC].retiraMaterialEdificio(kgCarvao);
                            zonas[linhaMnF][colunaMnF].retiraMaterialEdificio(kgFerro);
                            // fundicao recebe 1kg de aço
                            zonas[i][j].armazenaRecursoEdificio(kgAco);
                        } else {
                            int linhaElec = 0, colunaElec = 0;
                            if (verificaAdjacencia("ele",0,i,j,&linhaElec,&colunaElec)) {
                                kgCarvao = zonas[linhaElec][colunaElec].getMaterialEdificio();
                                kgFerro = zonas[linhaMnF][colunaMnF].getMaterialEdificio();
                                if (kgCarvao > 0 && kgFerro > 0) {
                                    kgAco++;
                                    cout << "1kg de carvao + 1kg de ferro transformados em 1 barra de aço." << endl;
                                    cout << "Foi retirado 1kg de carvao da central eletrica e 1kg de ferro da mina ferro." << endl;
                                    cout << "Central eletrica (" << linhaElec << "," << colunaElec << ")" << endl;
                                    cout << "Mina de ferro (" << linhaMnF << "," << colunaMnF << ")" << endl;
                                }
                                // retira o material da mina de ferro e da central eletrica
                                zonas[linhaMnF][colunaMnF].retiraMaterialEdificio(1);
                                zonas[linhaElec][colunaElec].retiraMaterialEdificio(1);
                                // fundicao recebe 1kg de aço
                                zonas[i][j].armazenaRecursoEdificio(kgAco);
                            }
                        }
                    }
                } else if (zonas[i][j].getEdificio() == "mnF") {
                    bool flgMineiro = false;
                    double prob = rand() / 100;
                    if(prob < 0.15) // probabilidade de 15% do edificio desabar
                        zonas[i][j].eliminaEdificio();
                    for (int t = 0; t < zonas[i][j].getNumTrabalhadores(); i++)
                        if (zonas[i][j].getTrabalhador('M'))
                            flgMineiro = true;
                    if (flgMineiro)
                        zonas[i][j].edificioProduz();
                } else if (zonas[i][j].getEdificio() == "mnC") {
                    bool flgMineiro = false;
                    double prob = rand() / 100;
                    if(prob < 0.1) // probabilidade de 10% do edificio desabar
                        zonas[i][j].eliminaEdificio();
                    for (int t = 0; t < zonas[i][j].getNumTrabalhadores(); i++)
                        if (zonas[i][j].getTrabalhador('M'))
                            flgMineiro = true;
                    if (flgMineiro)
                        zonas[i][j].edificioProduz();
                }
            }
        }
    }

    //================= Relatorio ao final do dia =================
    cout << "\n================= Relatorio ao final do dia " << dia << " =================\n" << endl;
    for (int i = 0; i < linhas; i++)
        for (int j = 0; j < colunas; j++)
            if (zonas[i][j].getTipoZona() != "pas" && zonas[i][j].getTipoZona() != "dsr" && zonas[i][j].getTipoZona() != "pnt")
                zonas[i][j].relatorioDiario(dia);
}

int Ilha::devolvePrecoEdificio(string desig, int lin, int col) const {
    int precoConstrucao = zonas[lin][col].getPrecoConstrucao();
    for (auto p : infoEdificios) {
        if (desig == get<0>(p))
            return get<2>(p) * precoConstrucao;
    }
    return 0;
}

int Ilha::devolvePrecoTrabalhador(char const& desig) const {
    for (auto p : infoTrabalhadores) {
        if (desig == get<1>(p))
            return get<2>(p);
    }
    return 0;
}

bool Ilha::verificaAdjacencia(const string& nome, int tipo, int lin, int col, int *l, int *c) {
    if (tipo == 0) {  // 0 -> verifica edificio adjacente
        if (col-1 >= 0 && zonas[lin][col-1].existeEdificio() && zonas[lin][col-1].getEdificio() == nome) {
            *l = lin; *c = col-1;
            return true;
        } else if (col+1 < colunas && zonas[lin][col+1].existeEdificio() && zonas[lin][col+1].getEdificio() == nome) {
            *l = lin; *c = col+1;
            return true;
        } else if (lin-1 >= 0 && zonas[lin-1][col].existeEdificio() &&  zonas[lin-1][col].getEdificio() == nome) {
            *l = lin-1; *c = col;
            return true;
        } else if (lin+1 < linhas && zonas[lin+1][col].existeEdificio() &&  zonas[lin+1][col].getEdificio() == nome) {
            *l = lin+1; *c = col;
            return true;
        }
    } else if (tipo == 1) { // 1 -> verifica zona adjacente
        if (col-1 >= 0 && zonas[lin][col-1].getTipoZona() == nome) {
            *l = lin; *c = col-1;
            return true;
        } else if (col+1 < colunas && zonas[lin][col+1].getTipoZona() == nome) {
            *l = lin; *c = col+1;
            return true;
        } else if (lin-1 >= 0 && zonas[lin-1][col].getTipoZona() == nome) {
            *l = lin-1; *c = col;
            return true;
        } else if (lin+1 < linhas && zonas[lin+1][col].getTipoZona() == nome) {
            *l = lin+1; *c = col;
            return true;
        }
    }
    return false;
}

void Ilha::listaPrecos() {
    cout << "Preços dos trabalhadores: " << endl;
    for (auto t : infoTrabalhadores)
        cout << get<0>(t) << ": " << get<2>(t) << endl;
    cout << endl;
    cout << "Preços dos edificios: " << endl;
    for (auto e : infoEdificios) {
        if (get<0>(e) == "minaferro" || get<0>(e) == "minacarvao")
            cout << get<0>(e) << ": " << get<2>(e) << " vigas" << endl;
        else if (get<0>(e) == "bateria")
            cout << get<0>(e) << ": " << get<2>(e) << " euros e 10 vigas" << endl;
        else
            cout << get<0>(e) << ": " << get<2>(e) << " euros" << endl;
    }
    cout << endl;
}

string Ilha::getTipoRecurso(int lin, int col) const {
    if (zonas[lin][col].verificaProducao())
        return zonas[lin][col].getMaterialProducao();
    return "zona nao produz\n";
}

double Ilha::getQuantidadeRecurso(int lin, int col) const {
    double quantidade = zonas[lin][col].getMaterial();
    zonas[lin][col].retiraMaterial(quantidade);
    return quantidade;
}

string Ilha::getTipoRecursoEdificio(int lin, int col) const {
    if (zonas[lin][col].existeEdificio())
        return zonas[lin][col].getRecursoEdificio();
    return "sem edificio!";
}

int Ilha::getQuantidadeRecursoEdificio(int lin, int col) const {
    int quantidade = 0;
    if (zonas[lin][col].getMaterialEdificio() > 0) {
        do {
            cout << "Armazenado no edifico da zona(" << lin << "," << col << "):" << zonas[lin][col].getMaterialEdificio() <<endl;
            cout << "Quantidade a retirar: ";
            cin >> quantidade;
        } while(quantidade > zonas[lin][col].getMaterialEdificio());
        zonas[lin][col].retiraMaterialEdificio(quantidade);
        return quantidade;
    }
    return 0;
}

string Ilha::getTipoEdificio(int lin, int col) const {
    if (zonas[lin][col].existeEdificio())
        return zonas[lin][col].getEdificio();
    return "Nao existe edificio!";
}

int Ilha::getUpgradeEuros(int lin, int col) const {
    if (zonas[lin][col].existeEdificio()) {
        string desig = zonas[lin][col].getEdificio();
        for (auto p : precoNivel)
            if (p.first == desig)
                return p.second;
    }
    return 0;
}

/*==============================  Listar Ilha  ==============================*/

void Ilha::escreveLinhaSup(int lin, int col,int cont) {
    cout << endl;
    for (int l = 0; l < col*11; ++l) {
        if (l == cont) { cout << "┬"; cont += 11; }
        else if (l == 0)
            cout << "┌";
        else
            cout << "─";
    }
    cout << "┐\n";
}
void Ilha::escreveLinhaInf(int lin, int col, int cont, int i) {
    for (int l = 0; l < col*11; ++l) {
        if (l == cont && i == lin-1) { cout << "┴"; cont += 11; }
        else if (l == cont) { cout << "┼"; cont += 11; }
        else if (l == 0 && i == lin-1)
            cout << "└";
        else if (l == 0)
            cout << "├";
        else
            cout << "─";
    }

    if (i < lin-1)
        cout << "┤";
    else
        cout << "┘\n\n";
}
void Ilha::listaIlha() {
    int cont = 11;
    escreveLinhaSup(linhas,colunas,cont);
    for (int i = 0; i < linhas; i++) {
        cont = 11;
        for (int j = 0; j < 4; j++) {
            cout << "| ";
            switch(j) {
                case 0:
                    for (int a = 0; a < linhas; a++) {
                        for (int b = 0; b < colunas; b++) {
                            if (zonas[a][b].getLinha() == i) {
                                if (zonas[a][b].getColuna() < 10)
                                    cout << "Z(" << zonas[a][b].getLinha() << "," << zonas[a][b].getColuna() << ")   | ";
                                else
                                    cout << "Z(" << zonas[a][b].getLinha() << "," << zonas[a][b].getColuna() << ")  | ";
                            }
                        }
                    }
                    break;
                case 1:
                    for (int c = 0; c < linhas; c++)
                        for (int d = 0; d < colunas; d++)
                            if (zonas[c][d].getLinha() == i)
                                cout << zonas[c][d].getTipoZona() << "      | ";
                    break;
                case 2:  // lista edificios
                    for (int e = 0; e < linhas; e++)
                        for (int f = 0; f < colunas; f++)
                            if (zonas[e][f].getLinha() == i && zonas[e][f].existeEdificio())
                                cout << zonas[e][f].getEdificio() << "      | ";
                            else if (zonas[e][f].getLinha() == i)
                                cout << "         | ";
                    break;
                case 3: // lista trabalhadores
                    int contador = 0;
                    for (int g = 0; g < linhas; g++) {
                        for (int h = 0; h < colunas; h++) {
                            if (zonas[g][h].getLinha() == i) {
                                if (zonas[g][h].getNumTrabalhadores() == 0) {
                                    for (int x = 0; x < 9; x++) {
                                        cout << " ";
                                    }
                                    cout << "| ";
                                } else {
                                    if (zonas[g][h].getNumTrabalhadores() <= 5)   // assim o numTrabalhadores aumenta
                                        contador = zonas[g][h].getNumTrabalhadores();    // mas a var contador limita a 5 chars
                                    else
                                        contador = 5;

                                    zonas[g][h].getTrabalhadoresList();

                                    for (int y = 0; y < 9 - contador; y++) {
                                        cout << " ";
                                    }
                                    cout << "| ";
                                }
                            }
                        }
                    }
                    break;
            }
            cout << endl;
        }
        escreveLinhaInf(linhas,colunas,cont,i);
        cout << endl;
    }
}

/*==============================  Zona  ==============================*/

void Ilha::criaZonas(vector<string> listaZon) {    // criar dinamicamente as zonas num vector<Zona*>
    //alocar a memoria para as linhas e colunas
    zonas = new Zona*[linhas];
    for (int i = 0; i < linhas; i++)
        zonas[i] = new Zona[colunas];

    //================= Amanhecer =================
    cout << "\n================= DIA " << dia << " =================\n" << endl;
    cout << "\n================= Amanhecer =================" << endl;
    cout << "\n A aplicar condições de cada zona... \n\n";

    bool existeZonaX = false;
    bool zonaRepetida = false;
    vector<string> zonasIniciais;
    int zonasObrigatorias = 6;
    string randomZonaObrigatoria;

    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            if (zonasObrigatorias > 0) { // garante que as primeiras zonas sao sempre diferentes
                do {
                    randomZonaObrigatoria = *select_randomly(listaZon.begin(), listaZon.end());
                    zonaRepetida = false;
                    for (auto zo : zonasIniciais) {
                        if (zo == randomZonaObrigatoria) {
                            zonaRepetida = true;
                        }
                    }
                } while(zonaRepetida);
                if (randomZonaObrigatoria == "znX")
                    existeZonaX = true;
                zonasIniciais.push_back(randomZonaObrigatoria);
                zonasObrigatorias--;
                Zona *z = new Zona(i,j,randomZonaObrigatoria);
                zonas[i][j] = *z;
            } else {
                string randomZona = *select_randomly(listaZon.begin(), listaZon.end());

                if (randomZona == "znX" && existeZonaX) {
                    do {    // previne a repeticao de zonasX
                        randomZona = *select_randomly(listaZon.begin(), listaZon.end());
                    } while(randomZona == "znX");
                }

                Zona *z = new Zona(i,j,randomZona);
                zonas[i][j] = *z;
            }
            zonas[i][j].condicoesZona(); // ao criar a zona impoe as condicoes
        }
    }
}

void Ilha::listaZona(int linha, int coluna) {
    cout << zonas[linha][coluna].getAsString();
}

void Ilha::listaTodasZonas() {
    for (int i = 0; i < linhas; i++)
        for (int j = 0; j < colunas; j++)
                cout << zonas[i][j].getAsString();
}

Zona* Ilha::getZonasPas() {
    int numZonasPas = 0; // contador para atribuir ao array pastagens
    for (int i = 0; i < linhas; i++)
        for (int j = 0; j < colunas; j++)
            if (zonas[i][j].getTipoZona() == "pas")
                numZonasPas++;

    Zona *pastagens[numZonasPas]; // array que guarda apenas as zonas de pastagem
    int contador = 0;
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            if (zonas[i][j].getTipoZona() == "pas") {
                pastagens[contador] = &zonas[i][j];
                contador++;
            }
        }
    }
    // escolhe aleatoriamente 1 objeto zona dentro do array pastagens
    Zona *r = *select_randomly(&pastagens[0], &pastagens[numZonasPas]);
    return r;
}

/*==============================  Trabalhador  ==============================*/

void Ilha::recebeTrabalhador(const string& tipo) {
    Zona *r = getZonasPas();
    for (int i = 0; i < linhas; i++) {   // trabalhadores vao para zona de pastagem aleatoria quando contratados
        for (int j = 0; j < colunas; j++) {
            if (zonas[i][j].getTipoZona() == "pas" && zonas[i][j].getLinha() == r->getLinha() &&
                zonas[i][j].getColuna() == r->getColuna()) {
                char tip;
                int preco = 0;
                for (auto t : infoTrabalhadores) {
                    if (get<0>(t) == tipo && tipo == "operario") {
                        tip = get<1>(t);
                        preco = get<2>(t);
                        Operario *trab = new Operario(tip,preco,dia);
                        zonas[i][j].setTrabalhador(trab);
                    }
                    else if (get<0>(t) == tipo && tipo == "mineiro") {
                        tip = get<1>(t);
                        preco = get<2>(t);
                        Mineiro *trab = new Mineiro(tip,preco,dia);
                        zonas[i][j].setTrabalhador(trab);
                    }
                    else if (get<0>(t) == tipo && tipo == "lenhador") {
                        tip = get<1>(t);
                        preco = get<2>(t);
                        Lenhador *trab = new Lenhador(tip,preco,dia);
                        zonas[i][j].setTrabalhador(trab);
                    }
                }

                cout << tipo << " adicionado/a com sucesso à zona(" << zonas[i][j].getLinha() << ","
                     << zonas[i][j].getColuna() << ")" << endl;
                return;
            }
        }
    }
}

void Ilha::moverTrabalhador(int id, int lin, int col) {
    Trabalhador *aux = nullptr;
    for (int i = 0; i < linhas; i++) // procura o trabalhador com id
        for (int j = 0; j < colunas; j++)
            if (zonas[i][j].existeTrabalhador(id)) {
                if (zonas[i][j].trabalhadorMovido(id))  // ja foi movido hoje
                    cout << "Trabalhador só pode ser movido no dia seguinte." << endl;
                else
                    aux = zonas[i][j].eliminaTrabalhador(id); // se id existe na zona
            }
    if (aux != nullptr)
        zonas[lin][col].moveTrabalhador(aux); // entao, elimina e move
}

void Ilha::removerTrabalhador(int id) {
    for (int i = 0; i < linhas; i++) // procura o trabalhador com id
        for (int j = 0; j < colunas; j++)
            if (zonas[i][j].existeTrabalhador(id))
                if (zonas[i][j].eliminaTrabalhador(id) != nullptr)
                    cout << "Trabalhador removido com sucesso." << endl;

}

/*==============================  Edificio  ==============================*/

void Ilha::recebeEdificio(const string& edificio,int linha, int coluna) {
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            if (zonas[i][j].getLinha() == linha && zonas[i][j].getColuna() == coluna) {
                if (!zonas[i][j].existeEdificio()) {  // caso nao exista edificio, adiciona
                    int preco = 0;
                    for (auto e : infoEdificios) {
                        if (get<0>(e) == edificio && edificio == "minaferro") {
                            preco = get<2>(e);
                            Minaferro *edf = new Minaferro("mnF",preco);
                            zonas[i][j].setEdificio(edf);
                            break;
                        } else if (get<0>(e) == edificio && edificio == "minacarvao") {
                            preco = get<2>(e);
                            Minacarvao *edf = new Minacarvao("mnC",preco);
                            zonas[i][j].setEdificio(edf);
                            break;
                        }
                        else if (get<0>(e) == edificio && edificio == "centraleletrica") {
                            preco = get<2>(e);
                            CentralEle *edf = new CentralEle("ele",preco);
                            zonas[i][j].setEdificio(edf);
                            break;
                        }
                        else if (get<0>(e) == edificio && edificio == "bateria") {
                            preco = get<2>(e);
                            Bateria *edf = new Bateria("bat",preco);
                            zonas[i][j].setEdificio(edf);
                            break;
                        }
                        else if (get<0>(e) == edificio && edificio == "fundicao") {
                            preco = get<2>(e);
                            Fundicao *edf = new Fundicao("fun",preco);
                            zonas[i][j].setEdificio(edf);
                            break;
                        }
                        else if (get<0>(e) == edificio && edificio == "serracao") {
                            preco = get<2>(e);
                            Serracao *edf = new Serracao("ser",preco);
                            zonas[i][j].setEdificio(edf);
                            break;
                        }
                    }
                    cout << edificio << " adicionado/a com sucesso à zona(" << linha << "," << coluna << ")" << endl;
                } else {
                    cout << "Já existe um edificio nessa zona!" << endl;
                }
            }
        }
    }
}

void Ilha::procuraEdificio(string const& edificio, int preco) {
    bool flg = false;
    for (int i = 0; i < linhas; i++) // tem de ir as zonas para percorrer todos os edificios
        for (int j = 0; j < colunas; j++)
            if (zonas[i][j].existeEdificio())
                zonas[i][j].setPrecoEdificio(preco);

    for (auto &p : infoEdificios)
        if (edificio == get<1>(p))
            get<2>(p) = preco;

    cout << "Preço do edificio '" << edificio << "' alterado com sucesso.\n" << endl;
}

void Ilha::procuraTrabalhador(char const& trabalhador, int preco) {
    for (int i = 0; i < linhas; i++) // tem de ir as zonas para percorrer todos os edificios
        for (int j = 0; j < colunas; j++)
            if (zonas[i][j].getNumTrabalhadores() > 0)
                zonas[i][j].setPrecoTrabalhador(trabalhador,preco);

    for (auto &p : infoTrabalhadores)
        if (trabalhador == get<1>(p))
            get<2>(p) = preco;

    cout << "Preço do trabalhador '" << trabalhador << "' alterado com sucesso.\n" << endl;
}

void Ilha::onOffEdificio(string const& arg1, int lin, int col) {
    if (arg1 == "liga")
        zonas[lin][col].ligaEdificio();
    else
        zonas[lin][col].desligaEdificio();
}

int Ilha::getPrecoEdificio(int lin,int col) const {
    int precoEdificio = 0;
    if(zonas[lin][col].existeEdificio()) {
        precoEdificio = zonas[lin][col].getPrecoEdificio();
        zonas[lin][col].eliminaEdificio();
        cout << "Edificio vendido com sucesso por " << precoEdificio << " euros." << endl;
        return precoEdificio;
    }
    else {
        cout << "Não existe edificio na zona(" << lin << "," << col << ")" << endl;
        return 0;
    }
}

bool Ilha::verificaEdificio(int lin, int col) {
    if (zonas[lin][col].existeEdificio())
        return true;
    return false;
}

bool Ilha::verificaTipoDeEdificio(string recurso) { /* chamada com o comando 'transformar' */
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            if (zonas[i][j].existeEdificio() && recurso == "viga" && zonas[i][j].getEdificio() == "ser")
                return true;
            else if (zonas[i][j].existeEdificio() && recurso == "aco" && zonas[i][j].getEdificio() == "fun")
                return true;
            else if (zonas[i][j].existeEdificio() && recurso == "carvao" && zonas[i][j].getEdificio() == "mnC")
                return true;
            else if (zonas[i][j].existeEdificio() && recurso == "eletricidade" && zonas[i][j].getEdificio() == "ele")
                return true;
        }
    }
    cout << "Não existe um edificio para transformar recurso pretendido." << endl;
    return false;
}

bool Ilha::verificaEdificioLigado(int lin, int col) {
    if (zonas[lin][col].edificioEstaLigado())
        return true;
    return false;
}

void Ilha::levelUp(int lin, int col) { /* chamada com o comando 'upgrade' */
    zonas[lin][col].aumentaNivel();
}