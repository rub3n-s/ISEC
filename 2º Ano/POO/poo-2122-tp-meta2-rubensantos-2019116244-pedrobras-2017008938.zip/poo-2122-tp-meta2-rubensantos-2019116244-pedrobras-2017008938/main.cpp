#include <iostream>
#include "Comando.h"

int main() {
    Ilha i;
    Jogador j;
    Comando cmd(i,j);
    cmd.apresentacao();
    cmd.configuracao();
    return 0;
}
