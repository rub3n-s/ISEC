//
// Created by rsantos on 24/12/2021.
//

#include "CentralEle.h"

CentralEle::CentralEle(string const& desig, int prec) : designacao(desig), preco(prec), Edificio(desig,prec) {
    recurso = "carvao";
    capacidade = 100;
    produz = 1; // 1 kg de carvao
    armazenado = 0;
    nivel = 1;
}

string CentralEle::getDesignacao() const { return designacao; }

string CentralEle::getRecurso() const { return recurso; }

int CentralEle::getPreco() const { return preco; }

void CentralEle::setPreco(int p) { preco = p; }

int CentralEle::getCapacidade() const { return capacidade; }

int CentralEle::getNivel() const { return nivel; }

void CentralEle::armazena(int quantidade) {
    if (armazenado+quantidade <= capacidade)
        armazenado += quantidade;
    else {
        armazenado = capacidade;
        cout << "Lotação máxima atingida na mina de ferro." << endl;
    }
}

void CentralEle::producaoDiaria(int multiplicador) {   // ha zonas que produz a duplicar
    if (armazenado + produz * multiplicador <= capacidade)
        armazenado += produz * multiplicador;
    else {
        armazenado = capacidade;
        cout << "Lotação máxima atingida na mina de ferro." << endl;
    }
}

int CentralEle::getArmazenado() const { return armazenado; }

void CentralEle::setArmazenado(int quantidade) { armazenado -= quantidade; }