﻿#include "screen.h"
#include "screenThreads.h"

DWORD WINAPI threadInterface(LPVOID param) {
	Interface* mainInterface = (Interface*)param;
	TCHAR command[MAX_SIZE], ** commandArr = NULL;
	const TCHAR delim[2] = TEXT(" ");
	unsigned int nrArguments = 0;

	EnterCriticalSection(mainInterface->criticalSectionBool);
	while (!*mainInterface->stop) {
		LeaveCriticalSection(mainInterface->criticalSectionBool);

		// mostra o mapa
		_tprintf(_T("\n\n"));
		for (int j = mainInterface->sharedMemory->limitY - 1; j >= 0; j--) {
			for (int i = 0; i < mainInterface->sharedMemory->limitX - 1; i++) {
				if (mainInterface->sharedMemory->startingPoint.x == i && mainInterface->sharedMemory->startingPoint.y == j)
					_tprintf(_T("P "));
				else if (mainInterface->sharedMemory->endingPoint.x == i && mainInterface->sharedMemory->endingPoint.y == j)
					_tprintf(_T("D "));
				else
					_tprintf(_T("· "));
			}
			_tprintf(_T("\n"));
		}
		_tprintf(_T("\n"));		

		LeaveCriticalSection(mainInterface->criticalSectionScreen);

		Sleep(500);

		_tprintf(_T("\nComando: "));
		_getts_s(command, _countof(command) - 1);

		// comando 'inserir blocos'
		if (_tcscmp(command, _T("inserir blocos")) == 0) {
			// atribuir o comando escrito ao monitor que vai ser passado por memoria partilhada
			_tcscpy_s(mainInterface->screen->command, _countof(mainInterface->screen->command), command);

			// fazemos set do evento para que o servidor ler ao buffer circular
			SetEvent(mainInterface->hWriteToCircularBufferEvent);

			_tprintf(_T("\nA enviar informação ao servidor!\n"));

			LeaveCriticalSection(mainInterface->criticalSectionScreen);

			EnterCriticalSection(mainInterface->criticalSectionBool);
			continue;
		}

		// comando 'ativa random'
		if (_tcscmp(command, _T("ativar random")) == 0) {
			// atribuir o comando escrito ao monitor que vai ser passado por memoria partilhada
			_tcscpy_s(mainInterface->screen->command, _countof(mainInterface->screen->command), command);

			// fazemos set do evento para que o servidor ler ao buffer circular
			SetEvent(mainInterface->hWriteToCircularBufferEvent);

			_tprintf(_T("\nA enviar informação ao servidor!\n"));

			LeaveCriticalSection(mainInterface->criticalSectionScreen);

			EnterCriticalSection(mainInterface->criticalSectionBool);
			continue;
		}

		// comando 'desativa random'
		if (_tcscmp(command, _T("desativar random")) == 0) {
			// atribuir o comando escrito ao monitor que vai ser passado por memoria partilhada
			_tcscpy_s(mainInterface->screen->command, _countof(mainInterface->screen->command), command);

			// fazemos set do evento para que o servidor ler ao buffer circular
			SetEvent(mainInterface->hWriteToCircularBufferEvent);

			_tprintf(_T("\nA enviar informação ao servidor!\n"));

			LeaveCriticalSection(mainInterface->criticalSectionScreen);

			EnterCriticalSection(mainInterface->criticalSectionBool);
			continue;
		}

		// comando 'serverdata'
		if (_tcscmp(command, _T("serverdata")) == 0) {
			// output dos dados recebidos pelo servidor
			_tprintf(_T("\nlimiteX[%d]\nlimiteY[%d]\ntimer[%d]\ncoordInicio(%d,%d)\ncoordDestino(%d,%d)\n\n"),
				mainInterface->sharedMemory->limitX, mainInterface->sharedMemory->limitY, mainInterface->sharedMemory->timer, mainInterface->sharedMemory->startingPoint.x,
				mainInterface->sharedMemory->startingPoint.y, mainInterface->sharedMemory->endingPoint.x, mainInterface->sharedMemory->endingPoint.y);

			LeaveCriticalSection(mainInterface->criticalSectionScreen);

			EnterCriticalSection(mainInterface->criticalSectionBool);
			continue;
		}

		if (_tcscmp(command, _T("desativar random")) == 0) {
			// atribuir o comando escrito ao monitor que vai ser passado por memoria partilhada
			_tcscpy_s(mainInterface->screen->command, _countof(mainInterface->screen->command), command);

			// fazemos set do evento para que o servidor ler ao buffer circular
			SetEvent(mainInterface->hWriteToCircularBufferEvent);

			_tprintf(_T("\nA enviar informação ao servidor!\n"));

			LeaveCriticalSection(mainInterface->criticalSectionScreen);

			EnterCriticalSection(mainInterface->criticalSectionBool);
			continue;
		}

		// comando 'terminar'
		if (_tcscmp(command, _T("terminar")) == 0) {
			// atribuir o comando escrito ao monitor que vai ser passado por memoria partilhada
			_tcscpy_s(mainInterface->screen->command, _countof(mainInterface->screen->command), command);

			// fazemos set do evento para informar o servidor que este monitor vai terminar
			SetEvent(mainInterface->hWriteToCircularBufferEvent);

			// define o stop a true para a thread do estado do jogo ser avisada que tem de terminar
			*mainInterface->stop = true;

			_tprintf(_T("\nA desligar o monitor ...\n\n"));

			EnterCriticalSection(mainInterface->criticalSectionBool);
			break;
		}

		// comando 'help'
		if (_tcscmp(command, _T("help")) == 0) {
			_tprintf(_T("\n'serverdata' > Mostra os dados recebidos pelo servidor (limites, timer, ponto incial e de destino).\n"));
			_tprintf(_T("'parar <segundos>' > Solicita ao servidor para fechar a torneira durante 'x' segundos.\n"));
			_tprintf(_T("'inserir blocos' > Inserir blocos que representam paredes intransponíveis no mapa.\n"));
			_tprintf(_T("'ativar random' > Ativa modo aleatório para a sequência de peças/tubos.\n"));
			_tprintf(_T("'desativar random' > Desativa modo aleatório para a sequência de peças/tubos.\n"));
			_tprintf(_T("'terminar' > Terminar o programa.\n"));

			EnterCriticalSection(mainInterface->criticalSectionBool);
			continue;
		}

		// dividir o comando
		free(commandArr);
		commandArr = splitString(command, delim, &nrArguments);

		if (commandArr == NULL) {
			EnterCriticalSection(mainInterface->criticalSectionBool);
			continue;
		}

		// comando 'fechar a torneira'
		if (_tcscmp(commandArr[0], _T("parar")) == 0) {
			if (nrArguments != 2) {
				_tprintf(_T("[ERRO] Numero de argumentos invalido. Uso: parar <segundos>"), GetLastError());

				EnterCriticalSection(mainInterface->criticalSectionBool);
				continue;
			}
			else if (!isStringANumber(commandArr[1])) {
				_tprintf(_T("[ERRO] Segundo argumento deve ser um numero. Uso: parar <segundos>"), GetLastError());

				EnterCriticalSection(mainInterface->criticalSectionBool);
				continue;
			}
			else if (commandArr[1] <= 0) {
				_tprintf(_T("[ERRO] Tempo de paragem deve ser maior que zero."), GetLastError());

				EnterCriticalSection(mainInterface->criticalSectionBool);
				continue;
			}

			// atribuir o comando escrito ao monitor que vai ser passado por memoria partilhada
			_tcscpy_s(mainInterface->screen->command, _countof(mainInterface->screen->command), command);

			// fazemos set do evento para que o servidor ler ao buffer circular
			SetEvent(mainInterface->hWriteToCircularBufferEvent);

			_tprintf(_T("\nA enviar informação ao servidor!\n"));

			LeaveCriticalSection(mainInterface->criticalSectionScreen);

			EnterCriticalSection(mainInterface->criticalSectionBool);
			continue;
		}

		// mensagem de erro se nao for um comando valido
		_tprintf(_T("\n[ERRO] Comando desconhecido: Usar 'help' para obter a lista de comandos.\n"));

		EnterCriticalSection(mainInterface->criticalSectionBool);
	}
	LeaveCriticalSection(mainInterface->criticalSectionBool);

	return 0;
}

DWORD WINAPI threadProducer(LPVOID param) {
	ProducerStruct* data = (ProducerStruct*)param;

	EnterCriticalSection(data->criticalSectionBool);
	while (!*data->stop) {
		LeaveCriticalSection(data->criticalSectionBool);

		if (WaitForSingleObject(data->hWriteToCircularBufferEvent, 2000) == WAIT_TIMEOUT) {
			EnterCriticalSection(data->criticalSectionBool);
			continue;
		}

		// thread unica, reset event
		ResetEvent(data->hWriteToCircularBufferEvent);

		// esperamos por uma posição de escrita
		WaitForSingleObject(data->hSemaphoreWrite, INFINITE);

		// esperamos que o mutex esteja livre
		WaitForSingleObject(data->hMutex, INFINITE);

		EnterCriticalSection(data->criticalSectionScreen);

		// copiamos uma struct do tipo Screen para a memória partilhada
		CopyMemory(
			&data->sharedMemory->buffer[data->sharedMemory->writeIndex],
			data->screen,
			sizeof(Screen)
		);

		LeaveCriticalSection(data->criticalSectionScreen);

		data->sharedMemory->writeIndex++;

		if (data->sharedMemory->writeIndex == CIRCULAR_BUFFER_SIZE) data->sharedMemory->writeIndex = 0;

		ReleaseMutex(data->hMutex);

		ReleaseSemaphore(data->hSemaphoreRead, 1, NULL);

		EnterCriticalSection(data->criticalSectionBool);
	}
	LeaveCriticalSection(data->criticalSectionBool);

	return 0;
}

DWORD WINAPI threadGameState(LPVOID param) {
	Interface* mainInterface = (Interface*)param;
	TCHAR command[MAX_SIZE];
	HANDLE hRefreshEvent, hSharedServerInfo;

	hRefreshEvent = OpenEvent(
		EVENT_ALL_ACCESS,
		FALSE,
		EVENT_SCREEN_REFRESH
	);

	if (hRefreshEvent == NULL) {
		_tprintf(_T("[OpenEvent] Não foi possível abrir o evento de atualizacao do estado do jogo: Erro[%d]\n"), GetLastError());

		EnterCriticalSection(mainInterface->criticalSectionBool);
		*mainInterface->stop = true;
		LeaveCriticalSection(mainInterface->criticalSectionBool);

		return -1;
	}

	EnterCriticalSection(mainInterface->criticalSectionBool);
	while (!*mainInterface->stop) {
		LeaveCriticalSection(mainInterface->criticalSectionBool);

		if (WaitForSingleObject(hRefreshEvent, 2000) == WAIT_TIMEOUT) {
			EnterCriticalSection(mainInterface->criticalSectionBool);
			continue;
		}

		// thread unica, reset event
		ResetEvent(hRefreshEvent);

		EnterCriticalSection(mainInterface->criticalSectionScreen);

		if (mainInterface->sharedMemory->lost)
			_tprintf(_T("%s"), mainInterface->sharedMemory->message);

		LeaveCriticalSection(mainInterface->criticalSectionScreen);
	
		// entramos na seccao critica do bool porque saimos no inicio do while
		EnterCriticalSection(mainInterface->criticalSectionBool);
	}
	LeaveCriticalSection(mainInterface->criticalSectionBool);

	return 0;
}

// vai ficar a espera de um evento caso o servidor feche
DWORD WINAPI stopEventThread(LPVOID param) {
	stopEventThreadStruct* thisEvent = (stopEventThreadStruct*)param;
	HANDLE hStopEvent;

	hStopEvent = OpenEvent(
		EVENT_ALL_ACCESS,
		FALSE,
		EVENT_SERVER_CLOSED
	);

	if (hStopEvent == NULL) {
		_tprintf(_T("[OpenEvent] Não foi possível abrir o evento de paragem do Servidor: Erro[%d]\n"), GetLastError());

		EnterCriticalSection(thisEvent->criticalSectionBool);
		*thisEvent->stop = true;
		LeaveCriticalSection(thisEvent->criticalSectionBool);

		return -1;
	}

	EnterCriticalSection(thisEvent->criticalSectionBool);
	while (!*thisEvent->stop) {
		LeaveCriticalSection(thisEvent->criticalSectionBool);
		// espera 2000 milisegundos , se der timeout volta a esperar
		if (WaitForSingleObject(hStopEvent, 2000) == WAIT_TIMEOUT) {
			EnterCriticalSection(thisEvent->criticalSectionBool);
			continue;
		}

		EnterCriticalSection(thisEvent->criticalSectionBool);
		*thisEvent->stop = true;
		_tprintf(_T("A encerrar monitor...\n"));
		break;
	}
	LeaveCriticalSection(thisEvent->criticalSectionBool);

	return 0;
}