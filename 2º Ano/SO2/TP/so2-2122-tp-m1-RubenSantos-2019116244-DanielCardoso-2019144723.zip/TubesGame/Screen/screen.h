#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#include <stdbool.h>
#include <tchar.h>
#include <fcntl.h>
#include <time.h>
#include <windows.h>

#define MAX_SIZE 128	// Tamanho maximo aceite num array de carateres
#define CIRCULAR_BUFFER_SIZE 20	// Tamanho do buffer circular

#define SHARED_MEM_SERVER _T("SHARED_MEM_SERVER")

#define SEMAPHORE_UNIQUE_SERVER_NAME _T("SERVER_SEMAPHORE")	    // Garante que apenas existe uma instancia
#define SEMAPHORE_CIRCULAR_READ _T("CIRCULAR_SEMAPHORE_READ")	// Nome do Semaforo de Leitura
#define SEMAPHORE_CIRCULAR_WRITE _T("CIRCULAR_SEMAPHORE_WRITE")	// Nome do Semaforo de Escrita

#define FILEMAPPING_CIRCULAR _T("CIRCULAR_FILE_MAPPING")	// Nome do FileMapping do Buffer Circular
#define FILEMAPPING_SCREENS_NAME _T("SCRRENS_FILE_MAPPING")		// Nome do FileMapping dos Monitores

#define MUTEX_CIRCULAR _T("MUTEX_CIRCULAR")     				// Nome do Mutex dos Monitores

#define EVENT_SERVER_CLOSED _T("CLOSED_SERVER_EVENT")
#define EVENT_SCREEN_REFRESH _T("EVENT_SCREEN_REFRESH")

typedef struct {
    int x;
    int y;
} Coordinate;

// representa a nossa memoria partilhada
typedef struct {
    Coordinate startingPoint;
    Coordinate endingPoint;
    int limitX;
    int limitY;
    int timer;
    BOOL lost;
    BOOL flow;
    BOOL firstTime;
    TCHAR message[MAX_SIZE];
} SharedMemoryServer;

typedef struct {
    SharedMemoryServer* sharedMemory;

    Coordinate startingPoint;
    Coordinate endingPoint;
    int limitX;
    int limitY;
    int timer;
    int nrScreens;
    BOOL lost;
    BOOL flow;
    BOOL firstTime;
    TCHAR message[MAX_SIZE];
    
    HANDLE hManageScreenEvent;
    HANDLE hRefreshEvent;

    LPCRITICAL_SECTION criticalSectionScreens, criticalSectionBool;

    BOOL* stop;
} Server;

typedef struct {
    DWORD id;
    TCHAR command[MAX_SIZE];
} Screen;

typedef struct {
    SharedMemoryServer* sharedMemory;

    Screen* screen;

    HANDLE hWriteToCircularBufferEvent;
    HANDLE hSharedScreensMutex;
    HANDLE hRefreshEvent;

    LPCRITICAL_SECTION criticalSectionScreen, criticalSectionBool;

    BOOL* stop;
} Interface;

// representa a nossa memoria partilhada
typedef struct {
    int nScreens;
    int writeIndex; // proxima posicao de escrita
    int readIndex; // proxima posicao de leitura

    Screen buffer[CIRCULAR_BUFFER_SIZE]; // buffer circular em si (array de estruturas)
} SharedMemory;

// estrutura de apoio
typedef struct {
    SharedMemory* sharedMemory; // ponteiro para a memoria partilhada

    Screen* screen;

    HANDLE hWriteToCircularBufferEvent;

    HANDLE hSemaphoreWrite; // handle para o semaforo que controla as escritas (controla quantas posicoes estao vazias)
    HANDLE hSemaphoreRead; // handle para o semaforo que controla as leituras (controla quantas posicoes estao preenchidas)
    HANDLE hMutex;

    LPCRITICAL_SECTION criticalSectionScreen, criticalSectionBool;

    BOOL* stop;
} ProducerStruct;

typedef struct {
    BOOL* stop;
    LPCRITICAL_SECTION criticalSectionBool;
} stopEventThreadStruct;

TCHAR** splitString(TCHAR* str, const TCHAR* delim, unsigned int* size);
BOOL isStringANumber(TCHAR* str);