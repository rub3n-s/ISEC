﻿#include "server.h"

void presentation() {
	_tprintf(_T("┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n"));
	_tprintf(_T("┃  Jogo dos Tubos                          ┃\n"));
	_tprintf(_T("┃                                          ┃\n"));
	_tprintf(_T("┃  Realizado por:                          ┃\n"));
	_tprintf(_T("┃      Daniel Cardoso - 2019144723         ┃\n"));
	_tprintf(_T("┃      Ruben Santos   - 2019116244         ┃\n"));
	_tprintf(_T("┃                                          ┃\n"));
	_tprintf(_T("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n"));
}

void initializeVariables(Server* server) {
	server->limitX = 0;
	server->limitY = 0;
	server->startingPoint.x = 0;
	server->startingPoint.y = 0;
	server->endingPoint.x = 0;
	server->endingPoint.y = 0;
	server->timer = 0;
	server->flow = true;
	server->lost = false;
}

Coordinate defineCoordinate(Server server, int limitX, int limitY) {
	Coordinate tmp;
	int x = 0, y = 0;

	tmp.x = 0;
	tmp.y = 0;

	// inicializacao do time
	srand(time(0));

	bool tf = false;

	// se as coordenadas de ponto de partida estiverem a zero, entao tem de ser definidas
	if (server.startingPoint.x == 0 && server.startingPoint.y == 0) {
		// true-false (0 ou 1)
		tf = (rand() % 2) != 0;

		// metodo utilizado para escolher qual o quadrante a utilizar
		if (tf)		// lado direito
			x = (rand() % (limitX - limitX / 2)) + limitX / 2;
		else        // lado esquerdo
			x = rand() % (limitX / 2);

		// condicao para o caso de x ficar numa extremidade
		if (x == 0 || x == limitX - 1)
			y = (rand() % (limitY - 1)) + 1;	// y vai gerar um numero entre 1 e limitY-1
		// caso x nao esteja numa extremidade, temos de garantir que y esta
		else {
			tf = (rand() % 2) != 0;	// aplica-se de novo para escolher aleatoriamente o lado

			// escolher aleatoriamente qual a extremidade de y 
			if (tf)		// lado direito
				y = 0;
			else        // lado esquerdo
				y = limitY - 1;
		}

		// definir ponto de partida
		tmp.x = x;
		tmp.y = y;

		// devolve a coordenada
		return tmp;
	}

	// se as coordenadas de ponto de destino estiverem a zero, entao tem de ser definidas

	// comecar por verificar de que lado esta o ponto de partida, para o de destino ficar do lado oposto

	if (server.startingPoint.x == 0 || server.startingPoint.x == limitX - 1) {
		if (server.startingPoint.y < limitY / 2)	// quadrante esquerdo, entao y tem de ficar do lado direito
			y = (rand() % (limitY - limitY / 2)) + limitY / 2;
		else
			y = (rand() % (limitY / 2 - 1)) + 1;

		// definir ponto de destino 'x' na extremidade oposta
		if (server.startingPoint.x == 0)
			tmp.x = limitX - 1;
		else
			tmp.x = 0;
		tmp.y = y;
	}
	// pode estar em qualquer x, entao y tera de ficar no ponto maximo ou minimo
	else {
		// obter um x aleatorio que nao esteja nas extremidades
		if (server.startingPoint.x < limitX / 2)
			x = (rand() % (limitX - limitX / 2)) + limitX / 2;
		else
			x = (rand() % (limitX / 2 - 1)) + 1;

		// definir ponto de destino 'y' na extremidade oposta
		if (server.startingPoint.y == 0)
			tmp.y = limitY - 1;
		else
			tmp.y = 0;
		tmp.x = x;
	}

	// devolve a coordenada (so chega aqui quando se esta a definir o ponto de destino)
	return tmp;
}

bool defineParameters(Server* server, int argc, TCHAR* argv[]) {
	switch (argc) {
		// se apenas tiver 1 argumento, verifica no registry se existem as chaves respetivas
	case 1:
		// se alguma das chaves nao existir, return false e encerra o programa no main
		if (!loadRegistry(server, REGISTRY_PATH, _T("limitX"))) {
			_tprintf(_T("\n[ERRO] Leitura do 'limite X' a partir do registry."));
			return false;
		}
		else if (!loadRegistry(server, REGISTRY_PATH, _T("limitY"))) {
			_tprintf(_T("\n[ERRO] Leitura do 'limite Y' a partir do registry."));
			return false;
		}
		else if (!loadRegistry(server, REGISTRY_PATH, _T("timer"))) {
			_tprintf(_T("\n[ERRO] Leitura do 'temporizador' a partir do registry."));
			return false;
		}

		// aleatoriamente escolher o ponto de partida e de destino
		server->startingPoint = defineCoordinate(*server, server->limitX, server->limitY);
		server->endingPoint = defineCoordinate(*server, server->limitX, server->limitY);

		_tprintf(_T("\n[SUCESSO] Carregou os valores dos limites e temporizador a partir do registry.\n"));

		return true;
	case 4:
		for (int i = 1; i < argc; i++) {
			if (atoi(argv[i]) < 0) {	// restricao para todos os argumentos, devem ser > 0
				_tprintf(_T("[ERRO] Os argumentos devem ser valores inteiros maiores que 0\n"));
				return false;
			}
			else if (atoi(argv[i]) > 20 && i != 3) {	// retricao para os dois primeiros argumentos: limiteX e limite Y
				_tprintf(_T("[ERRO] Os primeiros dois argumentos (limites) devem ser maiores que 0 e menos que 20\n"));
				return false;
			}
		}

		// atribuir os valores a estrutura servidor, converter: string > int			
		server->limitX = _tstoi(argv[1]);
		server->limitY = _tstoi(argv[2]);
		server->timer = _tstoi(argv[3]);

		// aleatoriamente escolher o ponto de partida e de destino
		server->startingPoint = defineCoordinate(*server, server->limitX, server->limitY);
		server->endingPoint = defineCoordinate(*server, server->limitX, server->limitY);

		// guardar os valores lidos no Registry
		createRegistry(REGISTRY_PATH, _T("limitX"), server->limitX);
		createRegistry(REGISTRY_PATH, _T("limitY"), server->limitY);
		createRegistry(REGISTRY_PATH, _T("timer"), server->timer);

		_tprintf(_T("\n[SUCESSO] Inseriu os valores dos limites e temporizador no registry.\n"));

		return true;
	default:
		// tem de receber pelo menos 4 argumentos .\Servidor <limiteX> <limiteY> <temporizador>
		if (argc < 4) {
			_tprintf(_T("[ERRO] Numero de argumentos insuficiente. Uso: .\\Servidor <limiteX> <limiteY> <temporizador>\n"));
			return false;
		}
	}
	return false;
}

bool loadRegistry(Server* server, TCHAR path[], TCHAR name[]) {
	HKEY key;
	int result;

	// verifica se a chave existe
	result = RegOpenKeyExA(
		HKEY_CURRENT_USER,
		path,
		0,
		KEY_ALL_ACCESS,
		&key);

	// nao encontrou a chave
	if (result == ERROR_FILE_NOT_FOUND) {
		_tprintf(_T("\nErro [RegOpenKeyExA]: %d"), GetLastError());
		return false;
	}
	else if (result == ERROR_SUCCESS) {	// encontrou a chave
		DWORD valor;
		DWORD tam = sizeof(DWORD);	// tam. do valor a ser atribuido

		result = RegQueryValueEx(
			key,
			name,
			NULL,
			NULL,
			&valor,
			&tam
		);

		if (result == ERROR_SUCCESS) {
			// fecha a chave
			RegCloseKey(key);

			// verifica qual o valor lido, e atribui ao parametro do servidor
			if (_tcscmp(name, _T("limitX")) == 0)
				server->limitX = valor;
			else if (_tcscmp(name, _T("limitY")) == 0)
				server->limitY = valor;
			else if (_tcscmp(name, _T("timer")) == 0)
				server->timer = valor;
			else
				return false;
			return true;
		}
		// fecha a chave
		RegCloseKey(key);

		return true;
	}
	return false;
}

bool createRegistry(TCHAR path[], TCHAR name[], int value) {
	HKEY key;
	int result;

	// verifica se a chave ja existe
	result = RegOpenKeyExA(
		HKEY_CURRENT_USER,
		path,
		0,
		KEY_ALL_ACCESS,
		&key);

	// se ainda nao existir, cria a chave
	if (result == ERROR_FILE_NOT_FOUND) {
		result = RegCreateKeyExA(
			HKEY_CURRENT_USER,
			path,
			0,
			NULL,
			REG_OPTION_NON_VOLATILE,
			KEY_ALL_ACCESS,
			NULL,
			&key,
			NULL
		);
		if (result != ERROR_SUCCESS) {
			_tprintf(_T("\nERRO [RegCreateKeyExA]: %d"), GetLastError());
			return false;
		}
		_tprintf(_T("\nChave criada com sucesso."));
	}

	// converter o valor para uma DWORD para ser atribuido a chave
	DWORD dwValue = value;

	// atribuir o valor a chave
	result = RegSetValueEx(
		key,
		name,
		0,
		REG_DWORD,
		&dwValue,
		sizeof(dwValue)
	);

	if (result != ERROR_SUCCESS) {
		_tprintf(_T("\nErro [RegSetValueEx]: %d"), GetLastError());
		return false;
	}

	// quando termina fecha a chave
	RegCloseKey(key);

	return true;
}

void displayParameters(Server server) {
	_tprintf(_T("\n\nParametros obtidos: "));
	_tprintf(_T("\nLimite X: %d"), server.limitX);
	_tprintf(_T("\nLimite Y: %d"), server.limitY);
	_tprintf(_T("\nTemporizador: %d"), server.timer);
	_tprintf(_T("\nPonto de Partida: (%d,%d)"), server.startingPoint.x, server.startingPoint.y);
	_tprintf(_T("\nPonto de Destino: (%d,%d)\n"), server.endingPoint.x, server.endingPoint.y);
}

void getPath(Server* server) {
	PathStruct arr[40];
	int nrPlays = 0, difference = 0, xCounter = server->startingPoint.x, yCounter = server->startingPoint.y;

	_tprintf(_T("\nCaminho Gerado: \n\n"));
	// da esquerda para a direita
	if (server->startingPoint.x == 0) {
		arr[nrPlays].x = xCounter;
		arr[nrPlays].y = yCounter;
		arr[nrPlays].piece = _T('━');
		nrPlays++;

		if (server->endingPoint.y > server->startingPoint.y) {		
			difference = server->endingPoint.y - server->startingPoint.y;
			
			xCounter++;

			arr[nrPlays].x = xCounter;
			arr[nrPlays].y = yCounter;
			arr[nrPlays].piece = _T('┛');
			nrPlays++;

			do {
				yCounter++;

				arr[nrPlays].x = xCounter;
				arr[nrPlays].y = yCounter;
				arr[nrPlays].piece = _T('┃');
				nrPlays++;

				difference--;
			} while (difference > 1);

			yCounter++;
			arr[nrPlays].x = xCounter;
			arr[nrPlays].y = yCounter;
			arr[nrPlays].piece = _T('┏');
			nrPlays++;
		}
		else if (server->endingPoint.y < server->startingPoint.y) {		
			xCounter++;

			arr[nrPlays].x = xCounter;
			arr[nrPlays].y = yCounter;
			arr[nrPlays].piece = _T('┓');
			nrPlays++;

			do {
				yCounter--;

				arr[nrPlays].x = xCounter;
				arr[nrPlays].y = yCounter;
				arr[nrPlays].piece = _T('┃');
				nrPlays++;
				difference--;
			} while (difference > 1);

			yCounter--;
			arr[nrPlays].x = xCounter;
			arr[nrPlays].y = yCounter;
			arr[nrPlays].piece = _T('┗');	
			nrPlays++;
		}

		difference = server->endingPoint.x - xCounter;
		do {
			xCounter++;

			arr[nrPlays].x = xCounter;
			arr[nrPlays].y = yCounter;
			arr[nrPlays].piece = _T('━');
			nrPlays++;
			difference--;
		} while (difference > 0);
	}

	// da direita para a esquerda
	if (server->startingPoint.x == server->limitX - 1) {	
		arr[nrPlays].x = xCounter;
		arr[nrPlays].y = yCounter;
		arr[nrPlays].piece = _T('━');
		nrPlays++;

		if (server->endingPoint.y > server->startingPoint.y) {
			difference = server->endingPoint.y - server->startingPoint.y;

			xCounter--;

			arr[nrPlays].x = xCounter;
			arr[nrPlays].y = yCounter;
			arr[nrPlays].piece = _T('┗');
			nrPlays++;

			do {
				yCounter++;

				arr[nrPlays].x = xCounter;
				arr[nrPlays].y = yCounter;
				arr[nrPlays].piece = _T('┃');
				nrPlays++;
				difference--;
			} while (difference > 1);

			yCounter++;
			arr[nrPlays].x = xCounter;
			arr[nrPlays].y = yCounter;
			arr[nrPlays].piece = _T('┓');
			nrPlays++;
		}
		else if (server->endingPoint.y < server->startingPoint.y) {	// ━ ┃ ┏ ┓ ┛ ┗
			xCounter--;

			arr[nrPlays].x = xCounter;
			arr[nrPlays].y = yCounter;
			arr[nrPlays].piece = _T('┏');
			nrPlays++;

			do {
				yCounter--;

				arr[nrPlays].x = xCounter;
				arr[nrPlays].y = yCounter;
				arr[nrPlays].piece = _T('┃');
				nrPlays++;
				difference--;
			} while (difference > 1);

			yCounter--;
			arr[nrPlays].x = xCounter;
			arr[nrPlays].y = yCounter;
			arr[nrPlays].piece = _T('┛');
			nrPlays++;
		}

		difference = xCounter - server->endingPoint.x;
		do {
			xCounter--;

			arr[nrPlays].x = xCounter;
			arr[nrPlays].y = yCounter;
			arr[nrPlays].piece = _T('━');
			nrPlays++;
			difference--;
		} while (difference > 0);
	}
	
	//==================== CIMA PARA BAIXO ====================
	if (server->startingPoint.y == server->limitY - 1) {
		arr[nrPlays].x = xCounter;
		arr[nrPlays].y = yCounter;
		arr[nrPlays].piece = _T('┃');
		nrPlays++;

		if (server->endingPoint.x > server->startingPoint.x) {
			difference = server->endingPoint.x - server->startingPoint.x;

			yCounter--;

			arr[nrPlays].x = xCounter;
			arr[nrPlays].y = yCounter;
			arr[nrPlays].piece = _T('┗');
			nrPlays++;

			do {
				xCounter++;

				arr[nrPlays].x = xCounter;
				arr[nrPlays].y = yCounter;
				arr[nrPlays].piece = _T('━');
				nrPlays++;
				difference--;
			} while (difference > 1);

			xCounter++;
			arr[nrPlays].x = xCounter;
			arr[nrPlays].y = yCounter;
			arr[nrPlays].piece = _T('┓');
			nrPlays++;
		}
		else if (server->endingPoint.x < server->startingPoint.x) {	// ━ ┃ ┏ ┓ ┛ ┗
			difference = server->startingPoint.x - server->endingPoint.x;

			yCounter--;

			arr[nrPlays].x = xCounter;
			arr[nrPlays].y = yCounter;
			arr[nrPlays].piece = _T('┛');
			nrPlays++;

			do {
				xCounter--;

				arr[nrPlays].x = xCounter;
				arr[nrPlays].y = yCounter;
				arr[nrPlays].piece = _T('━');
				nrPlays++;
				difference--;
			} while (difference > 1);

			xCounter--;
			arr[nrPlays].x = xCounter;
			arr[nrPlays].y = yCounter;
			arr[nrPlays].piece = _T('┏');
			nrPlays++;
		}

		difference = yCounter - server->endingPoint.y;
		do {
			yCounter--;

			arr[nrPlays].x = xCounter;
			arr[nrPlays].y = yCounter;
			arr[nrPlays].piece = _T('┃');
			nrPlays++;
			difference--;
		} while (difference > 0);
	}

	//==================== BAIXO PARA CIMA ====================
	if (server->startingPoint.y == 0) {
		arr[nrPlays].x = xCounter;
		arr[nrPlays].y = yCounter;
		arr[nrPlays].piece = _T('┃');
		nrPlays++;

		if (server->endingPoint.x > server->startingPoint.x) {
			difference = server->endingPoint.x - server->startingPoint.x;

			yCounter++;

			arr[nrPlays].x = xCounter;
			arr[nrPlays].y = yCounter;
			arr[nrPlays].piece = _T('┏');
			nrPlays++;

			do {
				xCounter++;

				arr[nrPlays].x = xCounter;
				arr[nrPlays].y = yCounter;
				arr[nrPlays].piece = _T('━');
				nrPlays++;
				difference--;
			} while (difference > 1);

			xCounter++;
			arr[nrPlays].x = xCounter;
			arr[nrPlays].y = yCounter;
			arr[nrPlays].piece = _T('┛');
			nrPlays++;
		}
		else if (server->endingPoint.x < server->startingPoint.x) {
			difference = server->startingPoint.x - server->endingPoint.x;

			yCounter++;

			arr[nrPlays].x = xCounter;
			arr[nrPlays].y = yCounter;
			arr[nrPlays].piece = _T('┓');
			nrPlays++;

			do {
				xCounter--;

				arr[nrPlays].x = xCounter;
				arr[nrPlays].y = yCounter;
				arr[nrPlays].piece = _T('━');
				nrPlays++;
				difference--;
			} while (difference > 1);

			xCounter--;
			arr[nrPlays].x = xCounter;
			arr[nrPlays].y = yCounter;
			arr[nrPlays].piece = _T('┗');
			nrPlays++;
		}

		difference = server->endingPoint.y - yCounter;
		do {
			yCounter++;

			arr[nrPlays].x = xCounter;
			arr[nrPlays].y = yCounter;
			arr[nrPlays].piece = _T('┃');
			nrPlays++;
			difference--;
		} while (difference > 0);
	}


	BOOL encontrou = false;
	// output do caminho
	for (int i = server->limitY - 1; i >= 0; i--) {
		for (int j = 0; j <= server->limitX - 1; j++) {
			for (int k = 0; k < nrPlays; k++) {
				if (arr[k].x == j && arr[k].y == i) {
					_tprintf(_T("%c"), arr[k].piece);
					encontrou = true;
				}					
			}	
			if (!encontrou)
				_tprintf(_T("·"));
			encontrou = false;
		}		
		_tprintf(_T("\n"));
	}
	_tprintf(_T("\n"));
}

bool startFlow(Server* server) {
	if (server->flow) {
		_tprintf(_T("\nA agua ja se encontra a fluir.\n"));
		return false;
	}
	server->flow = true;
	_tprintf(_T("\nA agua comecou a fluir.\n"));
	return true;
}

bool stopFlow(Server* server) {
	if (!server->flow) {
		_tprintf(_T("\nA torneira ja foi fechada."));
		return false;
	}
	server->flow = false;
	_tprintf(_T("\nA torneira foi fechada."));
	return true;
}