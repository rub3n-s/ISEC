#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#include <stdbool.h>
#include <tchar.h>
#include <fcntl.h>
#include <windows.h>
#include <time.h>

#define MAX_SIZE 128	// tamanho maximo aceite num array de carateres
#define CIRCULAR_BUFFER_SIZE 20	// tamanho do buffer circular

#define SHARED_MEM_SERVER _T("SHARED_MEM_SERVER")

#define SEMAPHORE_UNIQUE_SERVER _T("SERVER_SEMAPHORE")	    // garante que apenas existe uma instancia
#define SEMAPHORE_CIRCULAR_READ _T("CIRCULAR_SEMAPHORE_READ")	// nome do Semaforo de Leitura
#define SEMAPHORE_CIRCULAR_WRITE _T("CIRCULAR_SEMAPHORE_WRITE")	// nome do Semaforo de Escrita

#define FILEMAPPING_CIRCULAR _T("CIRCULAR_FILE_MAPPING")	// nome do FileMapping do Buffer Circular

#define FILEMAPPING_SCREENS _T("SCRRENS_FILE_MAPPING")		// nome do FileMapping dos Monitores

#define MUTEX_CIRCULAR _T("MUTEX_CIRCULAR")     				// nome do Mutex dos Monitores

#define EVENT_SERVER_CLOSED _T("CLOSED_SERVER_EVENT")      // nome do evento de fecho do servidor
#define EVENT_SCREEN_REFRESH _T("EVENT_SCREEN_REFRESH")    // nome do evento para atualizar o estado do jogo no monitor

#define REGISTRY_PATH "Software\\TubesGame"     // caminho para as chaves do registry

typedef struct {
    int x;
    int y;
} Coordinate;

typedef struct {
    int x;
    int y;
    TCHAR piece;
} PathStruct;

// representa a nossa memoria partilhada
typedef struct {
    Coordinate startingPoint;
    Coordinate endingPoint;
    int limitX;
    int limitY;
    int timer;
    BOOL lost;
    BOOL flow;
    TCHAR message[MAX_SIZE];
} SharedMemoryServer;

typedef struct {
    SharedMemoryServer* sharedMemory;

    Coordinate startingPoint;
    Coordinate endingPoint;
    int limitX;
    int limitY;
    int timer;
    int nrScreens;
    BOOL lost;
    BOOL flow;
    TCHAR message[MAX_SIZE];

    HANDLE hManageScreenEvent;
    HANDLE hRefreshEvent;
    HANDLE hStopEvent;

    LPCRITICAL_SECTION criticalSectionScreens, criticalSectionBool;

    BOOL* stop;
} Server;

typedef struct {
    DWORD id;
    TCHAR comando[MAX_SIZE];
} Screen;

// estrutura da interface
typedef struct {
    Screen* screensArray;

    HANDLE hSharedScreensMutex;

    LPCRITICAL_SECTION criticalSectionScreens, criticalSectionBool;

    BOOL* stop;
} Interface;

// representa a nossa memoria partilhada
typedef struct {
    int nScreens;
    int writeIndex; // proxima posicao de escrita
    int readIndex; // proxima posicao de leitura

    Screen buffer[CIRCULAR_BUFFER_SIZE]; // buffer circular em si (array de estruturas)
} SharedMemory;

// estrutura de apoio ao buffer circular
typedef struct {
    SharedMemory* sharedMemory; // ponteiro para a memoria partilhada
    SharedMemoryServer* sharedServer;

    Screen* screenArray;
    Server* server;
    int nrScreens;

    HANDLE hSemaphoreWrite; // handle para o semaforo que controla as escritas (controla quantas posicoes estao vazias)
    HANDLE hSemaphoreRead; // handle para o semaforo que controla as leituras (controla quantas posicoes estao preenchidas)
    HANDLE hRefreshEvent;   // handle para atualizar o estado do jogo no monitor
    HANDLE hManageScreenEvent;  // handle parar iniciar o temporizador

    LPCRITICAL_SECTION criticalSectionScreens, criticalSectionBool;

    BOOL* stop;
} ConsumerStruct;

void presentation();
void initializeVariables(Server* server);
bool defineParameters(Server* server, int argc, TCHAR* argv[]);

Coordinate defineCoordinate(Server server, int limiteX, int limiteY);
bool createRegistry(TCHAR path[], TCHAR name[], int value);
bool loadRegistry(Server* server, TCHAR path[], TCHAR name[]);

void displayParameters(Server server);

bool startFlow();
bool stopFlow();