#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

// thread consumidor (le do buffer a estrutura monitor)
DWORD WINAPI threadConsumer(LPVOID param);

// thread da interface do servidor
DWORD WINAPI threadInterface(LPVOID param);

// thread para gerir o tempo que falta ate a agua fluir
DWORD WINAPI threadManageScreen(LPVOID param);

static BOOL WINAPI consoleCtrlControler(DWORD dwCtrlType);