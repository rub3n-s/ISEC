#include "server.h"
#include "serverThreads.h"

// Thread da Interface
DWORD WINAPI threadInterface(LPVOID param) {
	Interface* mainInterface = (Interface*)param;
	TCHAR command[MAX_SIZE];

	EnterCriticalSection(mainInterface->criticalSectionBool);
	while (!*mainInterface->stop) {
		LeaveCriticalSection(mainInterface->criticalSectionBool);

		// recebemos o comando
		_tprintf(TEXT("\nComando: "));
		_getts_s(command, _countof(command) - 1);

		// comando 'infojogadores'
		if (_tcscmp(command, _T("infojogadores")) == 0) {
			//	do something ...

			EnterCriticalSection(mainInterface->criticalSectionBool);
			continue;
		}

		// comando 'suspender'
		if (_tcscmp(command, _T("suspender")) == 0) {
			//	do something ...

			EnterCriticalSection(mainInterface->criticalSectionBool);
			continue;
		}

		// comando 'retomar'
		if (_tcscmp(command, _T("retomar")) == 0) {
			//	do something ...

			EnterCriticalSection(mainInterface->criticalSectionBool);
			continue;
		}

		// comando 'terminar'
		if (_tcscmp(command, _T("terminar")) == 0) {
			_tprintf(_T("\nA encerrar o servidor ...\n\n"));

			EnterCriticalSection(mainInterface->criticalSectionBool);
			break;
		}

		// comando 'help'
		if (_tcscmp(command, _T("help")) == 0) {
			_tprintf(_T("\n'infojogadores' > Obter informacao sobre os jogadores e as suas pontuacoes.\n"));
			_tprintf(_T("'suspender' > Suspender o jogo.\n"));
			_tprintf(_T("'retomar' > Retomar o jogo.\n"));
			_tprintf(_T("'terminar' > Terminar o programa.\n"));

			EnterCriticalSection(mainInterface->criticalSectionBool);
			continue;
		}

		// mensagem de erro se nao for um comando valido
		_tprintf(_T("\n[ERRO] Comando desconhecido: Usar 'help' para obter a lista de comandos.\n"));

		EnterCriticalSection(mainInterface->criticalSectionBool);
	}
	LeaveCriticalSection(mainInterface->criticalSectionBool);

	return 0;
}

DWORD WINAPI threadConsumer(LPVOID param) {
	ConsumerStruct* data = (ConsumerStruct*)param;
	Screen aux;
	BOOL screenExists = false;
	Screen* auxArr;

	// entramos na sec��o critica do bool
	EnterCriticalSection(data->criticalSectionBool);
	while (!*data->stop) {
		LeaveCriticalSection(data->criticalSectionBool);

		// esperamos por uma posicao para lermos
		if (WaitForSingleObject(data->hSemaphoreRead, 1000) == WAIT_TIMEOUT) {
			EnterCriticalSection(data->criticalSectionBool);
			continue;
		}

		// copiamos a proxima posicao de leitura do buffer circular para a nossa struct auxiliar
		CopyMemory(
			&aux,
			&data->sharedMemory->buffer[data->sharedMemory->readIndex],
			sizeof(Screen)
		);

		// incrementa a posicao de leitura
		data->sharedMemory->readIndex++;

		// caso cheguemos ao fim do buffer circular, voltamos � primeira posi��o do mesmo
		if (data->sharedMemory->readIndex == CIRCULAR_BUFFER_SIZE) data->sharedMemory->readIndex = 0;

		// libertamos o sem�foro de escrita
		ReleaseSemaphore(data->hSemaphoreWrite, 1, NULL);

		/*
			// iniciar as verificacoes para o comando recebido do Monitor
			if (_tcscmp(aux.command,"xpto")	 ...
		*/

		screenExists = false;
		if (data->nrScreens > 0) {
			for (int i = 0; i < data->nrScreens; i++) {
				if (aux.id == data->screenArray[i].id) {
					screenExists = true;
				}
			}
		}
		else if (data->nrScreens == 0)
			data->screenArray = malloc(sizeof(Screen));

		// se o monitor se estiver a ligar pela primeira vez, faz set do evento
		if (!screenExists) {
			if (data->nrScreens == 0) {
				data->screenArray[data->nrScreens] = aux;

				// se for o primeiro monitor a ser inserido, vai ser o unico a chamar o evento de timer
				SetEvent(data->hManageScreenEvent);
			}
			else {
				data->screenArray = realloc(data->screenArray, sizeof(Screen) * (data->nrScreens + 1));
				data->screenArray[data->nrScreens] = aux;
			}
			data->nrScreens++;

			_tprintf(_T("\n\nMonitor[%ld] inserido no sistema\n"), aux.id);

			_tprintf(_T("\n\nLista de monitores:\n"));
			for (int i = 0; i < data->nrScreens; i++)
				_tprintf(_T("Monitor[%ld]\n"), data->screenArray[i].id);
			_tprintf(_T("\n"));
		}
		// se o monitor ja existir significa que esta a enviar informacao
		else {
			_tprintf(_T("\n\nMonitor[%ld] solicitou [%s]\n"), aux.id, aux.comando);

			if (_tcscmp(aux.comando, _T("terminar")) == 0) {
				if (data->nrScreens == 1)
					free(data->screenArray);
				else {
					// verifica qual a posicao do elemento a ser eliminado
					int pos = 0;
					for (int i = 0; i < data->nrScreens; i++)
						if (aux.id == data->screenArray[i].id)
							pos = i;
					for (int i = pos; i < data->nrScreens - 1; i++)
						data->screenArray[i] = data->screenArray[i + 1];

					data->screenArray = realloc(data->screenArray, sizeof(Screen) * (data->nrScreens - 1));
					
				}
				data->nrScreens--;

				_tprintf(_T("\n\nMonitor[%ld] removido do sistema\n"), aux.id);

				_tprintf(_T("\n\nLista de monitores:\n"));
				if (data->nrScreens == 0)
					_tprintf(_T("Vazia\n\n"));
					
				for (int i = 0; i < data->nrScreens; i++)
					_tprintf(_T("Monitor[%ld]\n"), data->screenArray[i].id);
			}
		}

		// entramos na sec��o critica do bool porque saimos no inicio do while
		EnterCriticalSection(data->criticalSectionBool);
	}
	LeaveCriticalSection(data->criticalSectionBool);

	return 0;
}

DWORD WINAPI threadManageScreen(LPVOID param) {
	Server* data = (Server*)param;
	int seconds = data->timer;

	EnterCriticalSection(data->criticalSectionBool);
	while (!*data->stop) {
		LeaveCriticalSection(data->criticalSectionBool);

		// fica a espera que a thread consumidor receba um monitor
		if (WaitForSingleObject(data->hManageScreenEvent, 1000) == WAIT_TIMEOUT) {
			EnterCriticalSection(data->criticalSectionBool);
			continue;
		}

		ResetEvent(data->hManageScreenEvent);

		// se houverem monitores e a torneira estiver ligada, inicia a contagem
		if (data->nrScreens > 0 && data->flow) {
			Sleep(500);
			while (seconds >= 0) {
				_tprintf(_T("Faltam [%d] segundos...\n"), seconds);
				Sleep(1000);
				seconds--;				
			}

			// avisa o monitor de que perdeu
			data->sharedMemory->lost = true;
			_tcscpy_s(data->sharedMemory->message, _countof(data->sharedMemory->message), _T("\n\n[PERDEU] A agua comecou a fluir e nao existem pecas no mapa.\n\n"));

			// quando o tempo terminar comunica com o monitor
			SetEvent(data->hRefreshEvent);
		}

		EnterCriticalSection(data->criticalSectionBool);
	}
	LeaveCriticalSection(data->criticalSectionBool);

	return 0;
}