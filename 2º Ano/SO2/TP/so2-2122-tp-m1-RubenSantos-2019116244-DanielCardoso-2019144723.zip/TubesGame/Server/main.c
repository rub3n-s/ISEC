#include "serverThreads.h"
#include "server.h"

int _tmain(int argc, TCHAR* argv[]) {   
    BOOL stop = false;
    CRITICAL_SECTION criticalSectionBool, criticalSectionScreens;

    Server server;
    Interface mainInterface;
    ConsumerStruct consumerData;

    HANDLE hSemaphoreUnique, hFileMapScreens, hFileMapConsumer, hSharedServerInfo; // handles semaforo unico/filemappings

    HANDLE hStopEvent, hRefreshEvent, hManageScreenEvent, hWriteToCircularBufferEvent;   // handles eventos

    HANDLE hThreadInterface, hThreadConsumer, hThreadManageScreen;  // handles threads

#ifdef UNICODE
    _setmode(_fileno(stdin), _O_WTEXT);
    _setmode(_fileno(stdout), _O_WTEXT);
    _setmode(_fileno(stderr), _O_WTEXT);
#endif

    // cria um semaforo para garantir uma execucao de um unico processo servidor
    hSemaphoreUnique = CreateSemaphore(
        NULL,
        1,
        2,
        SEMAPHORE_UNIQUE_SERVER
    );

    // Se ERROR_ALREADY_EXISTS , entao nao deixa iniciar outro servidor
    if (GetLastError() == ERROR_ALREADY_EXISTS) {
        _tprintf(_T("[ERRO] Ja existe um servidor aberto: Erro[%d]\n"), GetLastError());
        return -1;
    }

    //--------------------------------- CRIAR EVENTO PARAGEM DO SERVIDOR ---------------------------------
    hStopEvent = CreateEvent(
        NULL,
        TRUE,
        FALSE,
        EVENT_SERVER_CLOSED
    );

    if (hStopEvent == NULL) {
        _tprintf(_T("[CreateEvent] Nao foi possivel criar o evento de notificacao de saida: Erro[%d]\n"), GetLastError());
        return -1;
    }

    //--------------------------------- CRIAR EVENTO ATUALIZACAO VISUAL DO JOGO ---------------------------------
    hRefreshEvent = CreateEvent(
        NULL,
        TRUE,
        FALSE,
        EVENT_SCREEN_REFRESH
    );

    if (hRefreshEvent == NULL) {
        _tprintf(_T("[CreateEvent] Nao foi possivel criar o evento de atualizacao do estado do jogo: Erro[%d]\n"), GetLastError());
        return -1;
    }

    //--------------------------------- CRIAR EVENTO DE ESCRITA NO BUFFER ---------------------------------
    // criar o evento que sinaliza quando ira escrever no buffer
    hManageScreenEvent = CreateEvent(
        NULL,
        TRUE,
        FALSE,
        NULL
    );

    if (hManageScreenEvent == NULL) {
        _tprintf(_T("[CreateEvent] Nao foi possivel criar o evento de gestao de ecras: Erro[%d]\n"), GetLastError());

        EnterCriticalSection(&criticalSectionBool);
        stop = true;
        LeaveCriticalSection(&criticalSectionBool);

        return -1;
    }

    // mensagem de apresentacao
    presentation();

    // inicializar as variaveis da estrutura Servidor
    initializeVariables(&server);

    // definir parametros para limites e temporizador
    if (!defineParameters(&server, argc, argv)) {
        _tprintf(_T("\nA encerrar o servidor.\n"));
        return -1;
    }

    // mostra os valores em servidor
    displayParameters(server);

    InitializeCriticalSectionAndSpinCount(
        &criticalSectionBool,
        500
    );

    InitializeCriticalSectionAndSpinCount(
        &criticalSectionScreens,
        500
    );

    //------------------------------------- CRIAR MEMORIA PARTILHADA INFO SERVIDOR -------------------------------------    
    hSharedServerInfo = CreateFileMapping(
        INVALID_HANDLE_VALUE,
        NULL,
        PAGE_READWRITE,
        0,
        sizeof(SharedMemoryServer),
        SHARED_MEM_SERVER
    );

    if (hSharedServerInfo == NULL) {
        _tprintf(_T("[CreateFileMapping] Nao foi possivel criar o FileMapping da informacao do servidor: Erro[%d]\n"), GetLastError());

        EnterCriticalSection(&criticalSectionBool);
        stop = true;
        LeaveCriticalSection(&criticalSectionBool);

        return -1;
    }

    // mapeamos o bloco de memoria para o espaco de enderecamento do processo
    server.sharedMemory = (SharedMemoryServer*)MapViewOfFile(
        hSharedServerInfo,
        FILE_MAP_ALL_ACCESS,
        0,
        0,
        0
    );

    if (server.sharedMemory == NULL) {
        _tprintf(_T("[MapViewOfFile] Nao foi possivel criar a vista para a memoria partilhada: Erro[%d]\n"), GetLastError());

        EnterCriticalSection(&criticalSectionBool);
        stop = true;
        LeaveCriticalSection(&criticalSectionBool);

        return -1;
    }

    // preenchemos a estrutura da memoria partilhada
    server.sharedMemory->limitX = server.limitX;
    server.sharedMemory->limitY = server.limitY;
    server.sharedMemory->timer = server.timer;
    server.sharedMemory->startingPoint = server.startingPoint;
    server.sharedMemory->endingPoint = server.endingPoint;
    server.sharedMemory->lost = false;
    server.sharedMemory->flow = true;
    server.nrScreens = &consumerData.nrScreens;
    server.stop = &stop;
    server.hManageScreenEvent = hManageScreenEvent;
    server.criticalSectionBool = &criticalSectionBool;
    server.criticalSectionScreens = &criticalSectionScreens;
    server.hRefreshEvent = hRefreshEvent;
    server.hStopEvent = hStopEvent;

    // mostra o caminho
    getPath(&server);

    //------------------------------------- INICIAR INTERFACE -------------------------------------	
    // inicializar as variaveis da estrutura Interface
    mainInterface.criticalSectionScreens = &criticalSectionScreens;
    mainInterface.criticalSectionBool = &criticalSectionBool;
    mainInterface.stop = &stop;

    // cria a thread da interface
    hThreadInterface = CreateThread(
        NULL,
        0,
        threadInterface,
        &mainInterface,
        0,
        NULL
    );

    if (hThreadInterface == NULL) {
        _tprintf(_T("[CreateThread] Imposs�vel criar thread interface: Erro[%d]\n"), GetLastError());

        EnterCriticalSection(&criticalSectionBool);
        stop = true;
        LeaveCriticalSection(&criticalSectionBool);

        return -1;
    }

    //------------------------------------- RECEBER INFO DO MONITOR -------------------------------------
    // cria sem�foro de escrita para o buffer circular
    consumerData.hSemaphoreWrite = CreateSemaphore(
        NULL,
        CIRCULAR_BUFFER_SIZE,
        CIRCULAR_BUFFER_SIZE,
        SEMAPHORE_CIRCULAR_WRITE
    );

    // cria sem�foro de leitura para o buffer circular
    consumerData.hSemaphoreRead = CreateSemaphore(
        NULL,
        0,
        CIRCULAR_BUFFER_SIZE,
        SEMAPHORE_CIRCULAR_READ
    );

    // caso de erro na criacao dos semaforos, alteramos o stop para true e aguardamos que a ThreadInterface termine
    if (consumerData.hSemaphoreWrite == NULL || consumerData.hSemaphoreRead == NULL) {
        _tprintf(_T("[CreateSemaphore] Nao foi poss�vel criar semaforos para o buffer circular: Erro[%d]\n"), GetLastError());

        EnterCriticalSection(&criticalSectionBool);
        stop = true;
        LeaveCriticalSection(&criticalSectionBool);

        WaitForSingleObject(hThreadInterface, INFINITE);

        return -1;
    }

    // cria o FileMapping do buffer circular
    hFileMapConsumer = CreateFileMapping(
        INVALID_HANDLE_VALUE,
        NULL,
        PAGE_READWRITE,
        0,
        sizeof(SharedMemory),
        FILEMAPPING_CIRCULAR
    );

    if (hFileMapConsumer == NULL) {
        _tprintf(_T("[CreateFileMapping] Nao foi possivel criar o FileMapping do buffer circular: Erro[%d]\n"), GetLastError());

        EnterCriticalSection(&criticalSectionBool);
        stop = true;
        LeaveCriticalSection(&criticalSectionBool);

        return -1;
    }

    // mapeamos o bloco de memoria para o espaco de enderecamento do processo
    consumerData.sharedMemory = (SharedMemory*)MapViewOfFile(
        hFileMapConsumer,
        FILE_MAP_ALL_ACCESS,
        0,
        0,
        0
    );

    if (consumerData.sharedMemory == NULL) {
        _tprintf(_T("[MapViewOfFile] Nao foi possivel criar a vista para a memoria partilhada: Erro[%d]\n"), GetLastError());

        EnterCriticalSection(&criticalSectionBool);
        stop = true;
        LeaveCriticalSection(&criticalSectionBool);

        WaitForSingleObject(hThreadInterface, INFINITE);

        return -1;
    }

    // preenchemos a estrutura de apoio ao buffer circular
    consumerData.hManageScreenEvent = hManageScreenEvent;
    consumerData.criticalSectionBool = &criticalSectionBool;
    consumerData.criticalSectionScreens = &criticalSectionScreens;
    consumerData.stop = &stop;
    consumerData.nrScreens = 0;
    consumerData.hRefreshEvent = hRefreshEvent;

    // preenchemos a estrutura da memoria partilhada
    consumerData.sharedMemory->nScreens = 0;
    consumerData.sharedMemory->writeIndex = 0;
    consumerData.sharedMemory->readIndex = 0;

    hThreadConsumer = CreateThread(
        NULL,
        0,
        threadConsumer,
        &consumerData,
        0,
        NULL
    );

    if (hThreadConsumer == NULL) {
        _tprintf(_T("[MapViewOfFile] Nao foi possivel criar a thread consumidor: Erro[%d]\n"), GetLastError());

        EnterCriticalSection(&criticalSectionBool);
        stop = true;
        LeaveCriticalSection(&criticalSectionBool);

        WaitForSingleObject(hThreadInterface, INFINITE);

        return -1;
    }
    //------------------------------------- GESTAO DO TEMPORIZADOR DO MONITOR -------------------------------------
    hThreadManageScreen = CreateThread(
        NULL,
        0,
        threadManageScreen,
        &server,
        0,
        NULL
    );

    if (hThreadManageScreen == NULL) {
        _tprintf(_T("[CreateThread] Imposs�vel criar thread de gestao de temporizadores: Erro[%d]\n"), GetLastError());

        EnterCriticalSection(&criticalSectionBool);
        stop = true;
        LeaveCriticalSection(&criticalSectionBool);

        return -1;
    }

    WaitForSingleObject(hThreadInterface, INFINITE);    // espera pela thread da interface

    // entra na seccao critica assim que o WaitForSingleObject da thread interface terminar (stop=true, vai parar os restantes)
    EnterCriticalSection(&criticalSectionBool);
    stop = true;
    LeaveCriticalSection(&criticalSectionBool);

    WaitForSingleObject(hThreadConsumer, INFINITE);
    WaitForSingleObject(hThreadManageScreen, INFINITE);

    UnmapViewOfFile(consumerData.sharedMemory);   // liberta a memoria partilhada

    SetEvent(hStopEvent);   // avisa que o servidor esta a encerrar

    return 0;
}