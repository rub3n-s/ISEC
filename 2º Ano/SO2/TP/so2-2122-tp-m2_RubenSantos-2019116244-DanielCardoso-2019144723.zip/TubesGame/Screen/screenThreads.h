#include <windows.h>

// thread da interface
DWORD WINAPI threadInterface(LPVOID param);

// thread produtor (escreve no buffer para o servidor)
DWORD WINAPI threadProducer(LPVOID param);

// thread do estado atual do jogo
DWORD WINAPI threadGameState(LPVOID param);

// thread com evento de paragem
DWORD WINAPI stopEventThread(LPVOID param);