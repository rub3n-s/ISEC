#include <Windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#include <tchar.h>
#include <fcntl.h>
#include <time.h>

#include "screenThreads.h"
#include "screen.h"

int _tmain(int argc, TCHAR* argv[]) {
	DWORD id = GetCurrentProcessId();
	BOOL stop = FALSE;
	CRITICAL_SECTION criticalSectionBool, criticalSectionScreen;

	ProducerStruct producerData;
	Screen screen;
	Interface mainInterface;

	HANDLE hWriteToCircularBufferEvent, hFileMapProducer, hThreadProducer, hThreadInterface, hThreadGameState;

	HANDLE hStopEventThread;
	stopEventThreadStruct mainStopEvent;

	HANDLE hSharedServerInfo, hSharedMemoryScreens, hRefreshGameState;

#ifdef UNICODE
	_setmode(_fileno(stdin), _O_WTEXT);
	_setmode(_fileno(stdout), _O_WTEXT);
	_setmode(_fileno(stderr), _O_WTEXT);
#endif

	_tprintf(_T("ID do Processo: %ld\n\n"), id);	// mostra o ID do processo

	InitializeCriticalSectionAndSpinCount(
		&criticalSectionScreen,
		500
	);

	InitializeCriticalSectionAndSpinCount(
		&criticalSectionBool,
		500
	);

	//------------------------------------- EVENTO PARAGEM DO SERVIDOR -------------------------------------
	mainStopEvent.stop = &stop;
	mainStopEvent.criticalSectionBool = &criticalSectionBool;

	hStopEventThread = CreateThread(
		NULL,
		0,
		stopEventThread,
		&mainStopEvent,
		0,
		NULL
	);

	if (hStopEventThread == NULL) {
		_tprintf(_T("[CreateThread] Nao foi possivel criar o evento de stop do Servidor: Erro[%d]\n"), GetLastError());

		return -1;
	}

	//------------------------------------- EVENTO ESCRITA PARA O SERVIDOR -------------------------------------
	hWriteToCircularBufferEvent = CreateEvent(
		NULL,
		TRUE,
		FALSE,
		NULL
	);

	if (hWriteToCircularBufferEvent == NULL) {
		_tprintf(_T("[CreateEvent] Nao foi possivel criar o evento de escrita: Erro[%d]\n"), GetLastError());

		EnterCriticalSection(&criticalSectionBool);
		stop = TRUE;
		LeaveCriticalSection(&criticalSectionBool);

		WaitForSingleObject(hStopEventThread, INFINITE);

		return -1;
	}
	
	//--------------------------------- EVENTO ATUALIZACAO VISUAL DO JOGO ---------------------------------
	hRefreshGameState = CreateThread(
		NULL,
		0,
		threadGameState,
		&mainInterface,
		0,
		NULL
	);

	if (hRefreshGameState == NULL) {
		_tprintf(_T("[CreateThread] Nao foi possivel criar o evento de atualizacao do estado do jogo: Erro[%d]\n"), GetLastError());

		EnterCriticalSection(&criticalSectionBool);
		stop = TRUE;
		LeaveCriticalSection(&criticalSectionBool);

		WaitForSingleObject(hStopEventThread, INFINITE);

		return -1;
	}

	//------------------------------------- ABRIR MEMORIA PARTILHADA INFO SERVIDOR -------------------------------------
	// abre o FileMapping
	hSharedServerInfo = OpenFileMapping(
		FILE_MAP_ALL_ACCESS,
		FALSE,
		SHARED_MEM_SERVER
	);

	if (hSharedServerInfo == NULL) {
		_tprintf(_T("[OpenFileMapping] Nao foi possivel abrir o FileMapping da informacao do servidor: Erro[%d]\n"), GetLastError());

		EnterCriticalSection(&criticalSectionBool);
		stop = TRUE;
		LeaveCriticalSection(&criticalSectionBool);

		WaitForSingleObject(hStopEventThread, INFINITE);
		WaitForSingleObject(hRefreshGameState, INFINITE);

		return -1;
	}

	// mapeamos o bloco de mem�ria para o espa�o de enderecamento do processo
	mainInterface.sharedMemory = (SharedMemoryServer*)MapViewOfFile(
		hSharedServerInfo,
		FILE_MAP_ALL_ACCESS,
		0,
		0,
		0
	);

	if (mainInterface.sharedMemory == NULL) {
		_tprintf(_T("[MapViewOfFile - ServerData] Nao foi possivel mapear a memoria a partilhada: Erro[%d]\n"), GetLastError());

		EnterCriticalSection(&criticalSectionBool);
		stop = TRUE;
		LeaveCriticalSection(&criticalSectionBool);

		WaitForSingleObject(hStopEventThread, INFINITE);
		WaitForSingleObject(hRefreshGameState, INFINITE);

		return -1;
	}

	// inicializacao dos valores
	screen.id = id;
	_tcscpy_s(screen.command, sizeof(_T("Entrei")), _T("Entrei"));

	mainInterface.screen = &screen;
	mainInterface.hWriteToCircularBufferEvent = hWriteToCircularBufferEvent;
	mainInterface.criticalSectionScreen = &criticalSectionScreen;
	mainInterface.criticalSectionBool = &criticalSectionBool;
	mainInterface.stop = &stop;

	//------------------------------------- INICIAR INTERFACE -------------------------------------	
	hThreadInterface = CreateThread(
		NULL,
		0,
		threadInterface,
		&mainInterface,
		0,
		NULL
	);

	if (hThreadInterface == NULL) {
		_tprintf(_T("[CreateThread] Nao foi possivel criar a thread da interface: Erro[%d]\n"), GetLastError());

		EnterCriticalSection(&criticalSectionBool);
		stop = TRUE;
		LeaveCriticalSection(&criticalSectionBool);

		WaitForSingleObject(hStopEventThread, INFINITE);
		WaitForSingleObject(hRefreshGameState, INFINITE);

		UnmapViewOfFile(mainInterface.sharedMemory);

		return -1;
	}

	//------------------------------------- ENVIAR INFO AO SERVIDOR -------------------------------------
	// cria sem�foro de escrita
	producerData.hSemaphoreWrite = OpenSemaphore(
		SEMAPHORE_ALL_ACCESS,
		FALSE,
		SEMAPHORE_CIRCULAR_WRITE
	);

	// cria sem�foro de leitura
	producerData.hSemaphoreRead = OpenSemaphore(
		SEMAPHORE_ALL_ACCESS,
		FALSE,
		SEMAPHORE_CIRCULAR_READ
	);

	if (producerData.hSemaphoreWrite == NULL || producerData.hSemaphoreRead == NULL) {
		_tprintf(_T("[Semaphore] Nao foi poss�vel abrir semaforos para o buffer circular: Erro[%d]\n"), GetLastError());

		EnterCriticalSection(&criticalSectionBool);
		stop = TRUE;
		LeaveCriticalSection(&criticalSectionBool);

		WaitForSingleObject(hStopEventThread, INFINITE);
		WaitForSingleObject(hThreadInterface, INFINITE);
		WaitForSingleObject(hRefreshGameState, INFINITE);

		return -1;
	}

	producerData.hMutex = CreateMutex(
		NULL,
		FALSE,
		MUTEX_CIRCULAR
	);

	if (producerData.hMutex == NULL) {
		_tprintf(_T("[Mutex] Nao foi poss�vel criar mutex: Erro[%d]\n"), GetLastError());

		EnterCriticalSection(&criticalSectionBool);
		stop = TRUE;
		LeaveCriticalSection(&criticalSectionBool);

		WaitForSingleObject(hStopEventThread, INFINITE);
		WaitForSingleObject(hThreadInterface, INFINITE);
		WaitForSingleObject(hRefreshGameState, INFINITE);

		UnmapViewOfFile(mainInterface.sharedMemory);

		return -1;
	}

	// cria o FileMapping
	hFileMapProducer = OpenFileMapping(
		FILE_MAP_ALL_ACCESS,
		FALSE,
		FILEMAPPING_CIRCULAR
	);

	if (hFileMapProducer == NULL) {
		_tprintf(_T("[OpenFileMapping] Nao foi possivel abrir o FileMapping do buffer circular: Erro[%d]\n"), GetLastError());

		EnterCriticalSection(&criticalSectionBool);
		stop = TRUE;
		LeaveCriticalSection(&criticalSectionBool);

		WaitForSingleObject(hStopEventThread, INFINITE);
		WaitForSingleObject(hThreadInterface, INFINITE);
		WaitForSingleObject(hRefreshGameState, INFINITE);

		UnmapViewOfFile(mainInterface.sharedMemory);

		return -1;
	}

	// mapeamos o bloco de mem�ria para o espa�o de enderecamento do processo
	producerData.sharedMemory = (SharedMemory*)MapViewOfFile(
		hFileMapProducer,
		FILE_MAP_ALL_ACCESS,
		0,
		0,
		0
	);

	if (producerData.sharedMemory == NULL) {
		_tprintf(_T("[MapViewOfFile] Nao foi possivel mapear a memoria a partilhada: Erro[%d]\n"), GetLastError());

		EnterCriticalSection(&criticalSectionBool);
		stop = TRUE;
		LeaveCriticalSection(&criticalSectionBool);

		WaitForSingleObject(hStopEventThread, INFINITE);
		WaitForSingleObject(hThreadInterface, INFINITE);
		WaitForSingleObject(hRefreshGameState, INFINITE);

		UnmapViewOfFile(mainInterface.sharedMemory);

		return -1;
	}

	// inicializar os valores que vao para a thread produtor
	producerData.screen = &screen;
	producerData.hWriteToCircularBufferEvent = hWriteToCircularBufferEvent;
	producerData.criticalSectionScreen = &criticalSectionScreen;
	producerData.criticalSectionBool = &criticalSectionBool;
	producerData.stop = &stop;

	hThreadProducer = CreateThread(
		NULL,
		0,
		threadProducer,
		&producerData,
		0,
		NULL
	);

	if (hThreadProducer == NULL) {
		_tprintf(_T("[CreateThread] Nao foi possivel criar a thread do monitor: Erro[%d]\n"), GetLastError());

		EnterCriticalSection(&criticalSectionBool);
		stop = TRUE;
		LeaveCriticalSection(&criticalSectionBool);

		WaitForSingleObject(hStopEventThread, INFINITE);
		WaitForSingleObject(hThreadInterface, INFINITE);
		WaitForSingleObject(hRefreshGameState, INFINITE);

		UnmapViewOfFile(mainInterface.sharedMemory);
		UnmapViewOfFile(producerData.sharedMemory);

		return -1;
	}

	// no fim de validar todos os handles para threads, semaforos, ...
	// informar o servidor de que pretende receber os dados dos limites, timer e coordenadas
	SetEvent(producerData.hWriteToCircularBufferEvent);

	WaitForSingleObject(hThreadInterface, INFINITE);	// espera pela thread da interface

	// entra na seccao critica assim que o WaitForSingleObject da thread interface terminar (stop=TRUE, vai parar os restantes)
	EnterCriticalSection(&criticalSectionBool);
	stop = TRUE;
	LeaveCriticalSection(&criticalSectionBool);
	
	WaitForSingleObject(hStopEventThread, INFINITE);	// espera pelo evento de paragem do servidor
	WaitForSingleObject(hRefreshGameState, INFINITE);	// espera pela thread do estado do jogo
	WaitForSingleObject(hThreadProducer, INFINITE);		// espera pela thread do monitor (produtor)

	// liberta a memoria partilhada
	UnmapViewOfFile(mainInterface.sharedMemory);
	UnmapViewOfFile(producerData.sharedMemory);

	return 0;
}