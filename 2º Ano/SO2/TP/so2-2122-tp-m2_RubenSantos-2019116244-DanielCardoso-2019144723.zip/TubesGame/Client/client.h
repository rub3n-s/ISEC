#ifndef CLIENT_H
#define CLIENT_H

#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#include <tchar.h>
#include <fcntl.h>
#include <Windows.h>

#define MAX_PLAYS 1000
#define MAX_CLIENTS 2
#define MATRIX_MAX 20   // tamanho maximo da matriz
#define CIRCULAR_BUFFER_SIZE 20	// tamanho do buffer circular
#define MAX_SIZE 128	// tamanho maximo aceite num array de carateres
#define EVENT_SERVER_CLOSED _T("CLOSED_SERVER_EVENT")	// nome do evento de fecho do servidor

#define CLIENTS_PIPE TEXT("\\\\.\\pipe\\CLIENTS")	// pipe dos clientes
#define SERVER_TO_CLIENT_PIPE   _T("\\\\.\\pipe\\SERVER_TO_CLIENT")   // pipe do servidor

// conjunto 1 de bitmaps
#define HORIZONTAL_S1 _T("bmp\\set1\\horizontal.bmp")
#define VERTICAL_S1 _T("bmp\\set1\\vertical.bmp")
#define UP_RIGHT_90_S1 _T("bmp\\set1\\90_C_R.bmp")
#define UP_LEFT_90_S1 _T("bmp\\set1\\90_C_L.bmp")
#define DOWN_RIGHT_90_S1 _T("bmp\\set1\\90_B_R.bmp")
#define DOWN_LEFT_90_S1 _T("bmp\\set1\\90_B_L.bmp")

// conjunto 2 de bitmaps
#define HORIZONTAL_S2 _T("bmp\\set2\\horizontal.bmp")
#define VERTICAL_S2 _T("bmp\\set2\\vertical.bmp")
#define UP_RIGHT_90_S2 _T("bmp\\set2\\90_C_R.bmp")
#define UP_LEFT_90_S2 _T("bmp\\set2\\90_C_L.bmp")
#define DOWN_RIGHT_90_S2 _T("bmp\\set2\\90_B_R.bmp")
#define DOWN_LEFT_90_S2 _T("bmp\\set2\\90_B_L.bmp")

#define WIN _T("bmp\\win.bmp")
#define LOOSE _T("bmp\\loose.bmp")

typedef struct {
    HANDLE hPipe;
    HANDLE hPipeServerToClient;
    OVERLAPPED overlap;
} PipeData;

typedef struct {
    int x;
    int y;
} Coordinate;

typedef struct {
    int x;
    int y;
    TCHAR piece;
} Play;

typedef struct {
    HANDLE hPipeS2C;
    int limitX;
    int limitY;
    BOOL clearMap;
    BOOL competitiveON;
    int level;
    int points;
    TCHAR matrix[MATRIX_MAX][MATRIX_MAX];
    TCHAR matrixCells[MATRIX_MAX * MATRIX_MAX];
    Play play;
    Play playArray[MAX_PLAYS];
    int nrPlays;
    TCHAR receivedPiece;
    BOOL removePiece;
    BOOL lost;
    BOOL win;
    BOOL quit;
    BOOL holdWater;
    int holdWaterX;
    int holdWaterY;
} ClientGameStruct;

typedef struct {
    ClientGameStruct game;
    DWORD id;
    TCHAR name[MAX_SIZE];
    TCHAR gameMode[MAX_SIZE];
    TCHAR bitmapSet[MAX_SIZE];
} Client;

// representa a nossa memoria partilhada
typedef struct {
    TCHAR matrix[MATRIX_MAX][MATRIX_MAX];

    Client clientArray[MAX_CLIENTS];
    int nrClients;

    Coordinate startingPoint;
    Coordinate endingPoint;
    int limitX;
    int limitY;
    int timer;
} SharedMemoryServer;

typedef struct {
    DWORD id;
    TCHAR comando[MAX_SIZE];
} Screen;

// representa a nossa memoria partilhada
typedef struct {
    int nScreens;   // numero de monitores
    int writeIndex; // proxima posicao de escrita
    int readIndex; // proxima posicao de leitura

    Screen buffer[CIRCULAR_BUFFER_SIZE]; // buffer circular em si (array de estruturas)
} SharedBufferMemory;

typedef struct {
    SharedBufferMemory* sharedBuffer; // ponteiro para a memoria partilhada
    SharedMemoryServer* sharedServer;

    TCHAR matrix[MATRIX_MAX][MATRIX_MAX];

    Client* clientArray;
    int nrClients;

    Coordinate startingPoint;
    Coordinate endingPoint;
    int limitX;
    int limitY;
    int timer;
    BOOL suspended;
    BOOL wait;
    BOOL random;
    int waitSeconds;
    TCHAR sendPiece;

    HANDLE hSemaphoreWrite; // handle para o semaforo que controla as escritas (controla quantas posicoes estao vazias)
    HANDLE hSemaphoreRead; // handle para o semaforo que controla as leituras (controla quantas posicoes estao preenchidas)

    HANDLE hManageScreenEvent, hRefreshEvent, hStopEvent;

    HANDLE clientPipesS2C[MAX_CLIENTS];

    LPCRITICAL_SECTION criticalSectionScreens, criticalSectionBool;

    BOOL* stop;
} ConsumerStruct;

typedef struct {
    BOOL* stop;
    LPCRITICAL_SECTION criticalSectionBool;
} stopEventThreadStruct;

typedef struct {
    HANDLE hPipe;
    HANDLE hPipeServerToClient;
    Client* client;
    BOOL* stop;
    LPCRITICAL_SECTION criticalSectionBool;
    HANDLE hMutex;
    int cells[MATRIX_MAX * MATRIX_MAX];
    RECT matrixRect[MATRIX_MAX][MATRIX_MAX];
} ClientGUIStruct;

typedef struct {
    Client client;
    HANDLE hPipeServerToClient;
    HANDLE hMutex;
    BOOL* stop;
    LPCRITICAL_SECTION criticalSectionBool;
} ClientThreadGame;

DWORD WINAPI stopEventThread(LPVOID param);

#endif // !CLIENT_H