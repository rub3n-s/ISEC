#include "client.h"

// vai ficar a espera de um evento caso o servidor feche
DWORD WINAPI stopEventThread(LPVOID param) {
	stopEventThreadStruct* thisEvent = (stopEventThreadStruct*)param;
	HANDLE hStopEvent;

	hStopEvent = OpenEvent(
		EVENT_ALL_ACCESS,
		FALSE,
		EVENT_SERVER_CLOSED
	);

	if (hStopEvent == NULL) {
		_tprintf(_T("[OpenEvent] N�o foi poss�vel abrir o evento de paragem do Servidor: Erro[%d]\n"), GetLastError());

		EnterCriticalSection(thisEvent->criticalSectionBool);
		*thisEvent->stop = TRUE;
		LeaveCriticalSection(thisEvent->criticalSectionBool);

		return -1;
	}

	EnterCriticalSection(thisEvent->criticalSectionBool);
	while (!*thisEvent->stop) {
		LeaveCriticalSection(thisEvent->criticalSectionBool);
		// espera 2000 milisegundos , se der timeout volta a esperar
		if (WaitForSingleObject(hStopEvent, 2000) == WAIT_TIMEOUT) {
			EnterCriticalSection(thisEvent->criticalSectionBool);
			continue;
		}

		EnterCriticalSection(thisEvent->criticalSectionBool);
		*thisEvent->stop = TRUE;
		_tprintf(_T("A encerrar cliente...\n"));
		break;
	}
	LeaveCriticalSection(thisEvent->criticalSectionBool);

	return 0;
}

DWORD WINAPI threadReadPipe(LPVOID param) {
	ClientThreadGame* data = (ClientThreadGame*)param;
	BOOL ret;
	DWORD nBytes;

	EnterCriticalSection(data->criticalSectionBool);
	while (!*data->stop) {
		LeaveCriticalSection(data->criticalSectionBool);

		WaitForSingleObject(data->hMutex, INFINITE);

		ret = ReadFile(data->hPipeServerToClient, &data->client.game, sizeof(ClientGameStruct), &nBytes, NULL);
		if (!ret || !nBytes) {
			_tprintf(_T("\n[ERRO] Nao foi possivel ler do pipe. Erro[%d]\n"), GetLastError());

			EnterCriticalSection(data->criticalSectionBool);
			*data->stop = TRUE;
			break;
		}

		ReleaseMutex(data->hMutex);
	}
	LeaveCriticalSection(data->criticalSectionBool);

	return(0);
}