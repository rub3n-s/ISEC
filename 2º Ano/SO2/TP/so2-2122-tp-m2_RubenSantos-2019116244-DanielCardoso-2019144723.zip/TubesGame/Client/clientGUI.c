﻿#include <windows.h>
#include <windowsx.h>	// obter posicao do rato (MACROS)
#include <tchar.h>
#include <time.h>

#include "client.h"

LRESULT CALLBACK clientDataEvents(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK gameEvents(HWND, UINT, WPARAM, LPARAM);
DWORD WINAPI threadReadPipe(LPVOID param);

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR lpCmdLine, int nCmdShow) {
	TCHAR clientDataWindow[] = TEXT("DadosCliente");
	TCHAR gameWindow[] = TEXT("Jogo");

	DWORD id = GetCurrentProcessId(), nBytes;
	BOOL ret, stop = FALSE;
	int x = 0, y = 0, op = 0;
	Play auxTmp;
	TCHAR piece;
	
	Client client;
	ClientGUIStruct clientGUIStruct;
	ClientThreadGame clientThreadGame;

	HANDLE hMutex;
	CRITICAL_SECTION criticalSectionBool;

	HANDLE hStopEventThread;
	stopEventThreadStruct mainStopEvent;

	PipeData pipe;

	int cellSize = 32;		// tamanho das celulas (retangulos)

	client.id = id;
	_tcscpy_s(client.name, _countof(_T("empty")), _T("empty"));
	_tcscpy_s(client.gameMode, _countof(_T("empty")), _T("empty"));

	client.game.clearMap = FALSE;
	client.game.nrPlays = 0;
	client.game.points = 0;
	client.game.level = 1;
	client.game.lost = FALSE;
	client.game.win = FALSE;
	client.game.quit = FALSE;
	client.game.removePiece = FALSE;	
	client.game.holdWater = FALSE;
	client.game.holdWaterX = -1;
	client.game.holdWaterY = -1;
	client.game.competitiveON = FALSE;

	Play playTmp;
	playTmp.x = -1;
	playTmp.y = -1;
	playTmp.piece = _T('·');
	for (int i = 0; i < MAX_PLAYS; i++)
		client.game.playArray[i] = playTmp;

#ifdef UNICODE
	_setmode(_fileno(stdin), _O_WTEXT);
	_setmode(_fileno(stdout), _O_WTEXT);
	_setmode(_fileno(stderr), _O_WTEXT);
#endif

	HWND hWndClientData, hWndGame;
	MSG lpMsgClientData, lsMsgGame;
	WNDCLASSEX wcAppClientData, wcAppGame;

	wcAppClientData.cbSize = sizeof(WNDCLASSEX);
	wcAppClientData.hInstance = hInst;

	wcAppClientData.lpszClassName = clientDataWindow;
	wcAppClientData.lpfnWndProc = clientDataEvents;

	wcAppClientData.style = CS_HREDRAW | CS_VREDRAW;
	wcAppClientData.hIcon = LoadIcon(NULL, IDI_WARNING);
	wcAppClientData.hIconSm = LoadIcon(NULL, IDI_SHIELD);
	wcAppClientData.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcAppClientData.lpszMenuName = NULL;
	wcAppClientData.cbClsExtra = 0;
	wcAppClientData.cbWndExtra = 0;		// passar a estrutura cliente para a janela atraves dos bytes extra
	wcAppClientData.hbrBackground = CreateSolidBrush(RGB(70, 70, 70));

	// ============================================================================
	// 2. Registar a classe "wcApp" no Windows
	// ============================================================================
	if (!RegisterClassEx(&wcAppClientData))
		return(0);

	// ============================================================================
	// 3. Criar a janela
	// ============================================================================
	int widthClientData = (GetSystemMetrics(SM_CXSCREEN) - 300) / 2, heightClientData = (GetSystemMetrics(SM_CYSCREEN) - 400) / 2;

	hWndClientData = CreateWindow(
		clientDataWindow,			// Nome da janela (programa) definido acima
		_T("Inserir Dados do Cliente"),// Texto que figura na barra do título
		WS_OVERLAPPEDWINDOW,	// Estilo da janela (WS_OVERLAPPED= normal)
		widthClientData,		// Posição x pixels (default=à direita da última)
		heightClientData,		// Posição y pixels (default=abaixo da última)
		500,		// Largura da janela (em pixels)
		300,		// Altura da janela (em pixels)
		(HWND)HWND_DESKTOP,	// handle da janela pai (se se criar uma a partir de
						// outra) ou HWND_DESKTOP se a janela for a primeira, 
						// criada a partir do "desktop"
		(HMENU)NULL,			// handle do menu da janela (se tiver menu)
		(HINSTANCE)hInst,		// handle da instância do programa actual ("hInst" é  passado num dos parâmetros de WinMain())
		(LPVOID) &client);				// Não há parâmetros adicionais para a janela

	// ============================================================================
	// 4. Mostrar a janela
	// ============================================================================
	ShowWindow(hWndClientData, nCmdShow);

	UpdateWindow(hWndClientData);

	while (GetMessage(&lpMsgClientData, NULL, 0, 0)) {
		TranslateMessage(&lpMsgClientData);
		DispatchMessage(&lpMsgClientData);
	}

	// no fim de obter o nome e modo de jogo fecha a janela da insercao de dados
	CloseWindow(hWndClientData);

	// se o user fechar a janela e nao preencher os dados corretamente, termina o programa
	if (_tcscmp(client.name, _T("empty")) == 0
		|| (_tcscmp(client.gameMode, _T("individual")) != 0 && _tcscmp(client.gameMode, _T("competicao")) != 0)
		|| (_tcscmp(client.bitmapSet, _T("set1")) != 0 && _tcscmp(client.bitmapSet, _T("set2")) != 0)) {
		return -1;
	}

	/*--------------------------------------------- CONDICOES PARA A JANELA DO JOGO -----------------------------------------------*/
	InitializeCriticalSectionAndSpinCount(
		&criticalSectionBool,
		500
	);

	//--------------------------------- LIGAR O PIPE SERVIDOR > CLIENTE ---------------------------------
	if (!WaitNamedPipe(SERVER_TO_CLIENT_PIPE, NMPWAIT_WAIT_FOREVER)) {
		_tprintf(_T("[ERRO] Nao foi possivel ligar ao pipe Servidor. Erro[%d]\n"), GetLastError());
		return -1;
	}

	pipe.hPipeServerToClient = CreateFile(
		SERVER_TO_CLIENT_PIPE,
		GENERIC_READ | GENERIC_WRITE,
		0,
		NULL,
		OPEN_EXISTING,
		FILE_FLAG_OVERLAPPED,
		NULL
	);

	if (pipe.hPipeServerToClient == NULL) {
		_tprintf(_T("[ERRO] Nao foi possivel ligar ao pipe Cliente. Erro[%d]\n"), GetLastError());
		return -1;
	}

	//--------------------------------- LIGAR O PIPE AO SERVIDOR ---------------------------------
	// tenta ligar-se a uma das instancias do named pipe
	if (!WaitNamedPipe(CLIENTS_PIPE, NMPWAIT_WAIT_FOREVER)) {
		_tprintf(_T("[ERRO] Nao foi possivel ligar ao pipe Cliente. Erro[%d]\n"), GetLastError());
		return -1;
	}

	pipe.hPipe = CreateFile(
		CLIENTS_PIPE,
		GENERIC_READ | GENERIC_WRITE,
		0,
		NULL,
		OPEN_EXISTING,
		FILE_FLAG_OVERLAPPED,
		NULL
	);

	if (pipe.hPipe == NULL) {
		_tprintf(_T("[ERRO] Nao foi possivel ligar ao pipe Cliente. Erro[%d]\n"), GetLastError());
		return -1;
	}

	//--------------------------------- OVERLAPPED ---------------------------------
	// limpamos a struct overlap
	ZeroMemory(&pipe.overlap, sizeof(pipe.overlap));

	// criar evento para o overlapped
	pipe.overlap.hEvent = CreateEvent(
		NULL,
		TRUE,
		FALSE,
		NULL
	);

	if (pipe.overlap.hEvent == NULL) {
		_tprintf(_T("[ERRO] Nao foi possivel criar o evento Overlap. Erro[%d]\n"), GetLastError());
		CloseHandle(pipe.hPipe);
		return -1;
	}

	//--------------------------------- CRIAR EVENTO PARAGEM DO SERVIDOR ---------------------------------
	mainStopEvent.stop = &stop;
	mainStopEvent.criticalSectionBool = &criticalSectionBool;

	// a thread fica a escuta de um evento caso o servidor feche
	hStopEventThread = CreateThread(
		NULL,
		0,
		stopEventThread,
		&mainStopEvent,
		0,
		NULL
	);

	if (hStopEventThread == NULL) {
		_tprintf(_T("[ERRO] Nao foi possivel criar a thread para o evento de stop do Servidor. Erro[%d]\n"), GetLastError());
		CloseHandle(pipe.hPipe);
		return -1;
	}

	//--------------------------------- ESCREVE PELA PRIMEIRA VEZ NO PIPE ---------------------------------
	// escreve inicialmente a sua struct no named pipe
	if (!WriteFile(pipe.hPipe, &client, sizeof(client), NULL, &pipe.overlap))
		_tprintf(_T("\n[WriteFile] Erro a escrever no pipe! Erro[%d]\n"), GetLastError());
	else
		_tprintf(_T("\n[WriteFile] Informei o servidor de que entrei.\n"));

	// ve o resultado dessa escrita
	ret = GetOverlappedResultEx(
		pipe.hPipe,
		&pipe.overlap,
		&nBytes,
		INFINITE,
		TRUE
	);

	// o ret1 e dificil de usar com sucesso pois devido ao uso de overlapped o resultado e inconsistente
	if (!ret || !nBytes) {
		_tprintf(_T("\n[ERRO] Nao foi possivel escrever no pipe. Erro[%d]\n"), GetLastError());

		EnterCriticalSection(&criticalSectionBool);
		stop = TRUE;
		LeaveCriticalSection(&criticalSectionBool);

		WaitForSingleObject(hStopEventThread, INFINITE);

		CloseHandle(pipe.hPipe);

		return -1;
	}

	//--------------------------------- * CRIAR A JANELA COM A MATRIZ DO JOGO * ---------------------------------
	wcAppGame.cbSize = sizeof(WNDCLASSEX);
	wcAppGame.hInstance = hInst;

	wcAppGame.lpszClassName = gameWindow;
	wcAppGame.lpfnWndProc = gameEvents;

	wcAppGame.style = CS_HREDRAW | CS_VREDRAW;
	wcAppGame.hIcon = LoadIcon(NULL, IDI_WARNING);
	wcAppGame.hIconSm = LoadIcon(NULL, IDI_SHIELD);
	wcAppGame.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcAppGame.lpszMenuName = NULL;
	wcAppGame.cbClsExtra = 0;
	wcAppGame.cbWndExtra = 0;
	wcAppGame.hbrBackground = CreateSolidBrush(RGB(70, 70, 70));

	// ============================================================================
	// 2. Registar a classe "wcApp" no Windows
	// ============================================================================
	if (!RegisterClassEx(&wcAppGame))
		return(0);

	// ============================================================================
	// 3. Criar a janela
	// ============================================================================

	//--------------------------------- LER PELA PRIMEIRA VEZ DO PIPE ---------------------------------
	hMutex = CreateMutex(NULL, FALSE, NULL);

	clientGUIStruct.client = &clientThreadGame.client;
	clientGUIStruct.hPipe = pipe.hPipe;
	clientGUIStruct.hPipeServerToClient = pipe.hPipeServerToClient;
	clientGUIStruct.stop = &stop;
	clientGUIStruct.criticalSectionBool = &criticalSectionBool;
	clientGUIStruct.hMutex = hMutex;

	// receber a informacao dos limites vinda do servidor
	ret = ReadFile(pipe.hPipeServerToClient, &client.game, sizeof(ClientGameStruct), &nBytes, NULL);
	if (!ret || !nBytes) {
		_tprintf(_T("\n[ERRO] Nao foi possivel ler do pipe. Erro[%d]\n"), GetLastError());
		return -1;
	}

	clientThreadGame.client = client;
	clientThreadGame.hPipeServerToClient = pipe.hPipeServerToClient;
	clientThreadGame.criticalSectionBool = &criticalSectionBool;
	clientThreadGame.stop = &stop;
	clientThreadGame.hMutex = hMutex;

	// calcular o posicionamento da janela e a largura consoante as dimensoes recebidas do servidor
	int nWidth = client.game.limitX * cellSize + 16;
	int nHeight = client.game.limitY * cellSize + 40;
	int nX = (GetSystemMetrics(SM_CXSCREEN) - nWidth) / 2, nY = (GetSystemMetrics(SM_CYSCREEN) - nHeight) / 2;

	hWndGame = CreateWindow(
		gameWindow,			// Nome da janela (programa) definido acima
		(_T("%s"),client.name),// Texto que figura na barra do título
		WS_OVERLAPPEDWINDOW,	// Estilo da janela (WS_OVERLAPPED= normal)
		nX,		// Posição x pixels (default=à direita da última)
		nY,		// Posição y pixels (default=abaixo da última)
		nWidth,		// Largura da janela (em pixels)
		nHeight,		// Altura da janela (em pixels)
		(HWND)HWND_DESKTOP,	// handle da janela pai (se se criar uma a partir de
						// outra) ou HWND_DESKTOP se a janela for a primeira, 
						// criada a partir do "desktop"
		(HMENU)NULL,			// handle do menu da janela (se tiver menu)
		(HINSTANCE)hInst,		// handle da instância do programa actual ("hInst" é 
						// passado num dos parâmetros de WinMain()
		&clientGUIStruct);				// Não há parâmetros adicionais para a janela

	// ============================================================================
	// 4. Mostrar a janela
	// ============================================================================
	ShowWindow(hWndGame, nCmdShow);

	UpdateWindow(hWndGame);

	HANDLE hThreadReadPipe = CreateThread(
		NULL,
		0,
		threadReadPipe,
		&clientThreadGame,
		0,
		NULL
	);

	if (hThreadReadPipe == NULL) {
		_tprintf(_T("[CreateThread] Erro a criar a thread para leitura do pipe. Erro[%d]\n"), GetLastError());
		return -1;
	}

	while (GetMessage(&lsMsgGame, NULL, 0, 0)) {
		TranslateMessage(&lsMsgGame);
		
		DispatchMessage(&lsMsgGame);
	}

	WaitForSingleObject(hThreadReadPipe, INFINITE);

	LeaveCriticalSection(&criticalSectionBool);

	// ============================================================================
	// 6. Fim do programa
	// ============================================================================
	return((int)lsMsgGame.wParam);	// Retorna sempre o parâmetro wParam da estrutura lpMsgGame
}

LRESULT CALLBACK clientDataEvents(HWND hWnd, UINT messg, WPARAM wParam, LPARAM lParam) {
	Client* client;
	HWND hNameTxt, hGameModeTxt, hBitmapSetTxt, confirmBtn;

	// recebe o 'client' atraves do 'CreateWindow()'e associa ao GWL_USERDATA
	if (messg == WM_NCCREATE)
		SetWindowLongPtr(hWnd, GWLP_USERDATA, (LONG)(((CREATESTRUCT*)lParam)->lpCreateParams));

	// obter um ponteiro com os dados do objeto ClientPipeStruct passado para a janela
	client = (Client*)GetWindowLongPtr(hWnd, GWLP_USERDATA);

	switch (messg) {
	case WM_CREATE:
	{
		hNameTxt = CreateWindowEx(WS_EX_CLIENTEDGE, _T("EDIT"),
			//_T("Insira o nome..."),
			_T("A"),			// apenas usado para facilitar os testes
			WS_VISIBLE | WS_CHILD | ES_LEFT,
			50, 50, 380, 25,
			hWnd, (HMENU)1, NULL, NULL);

		hGameModeTxt = CreateWindowEx(WS_EX_CLIENTEDGE, _T("EDIT"),
			//_T("'individual' ou 'competicao'"),
			_T("individual"),			// apenas usado para facilitar os testes
			WS_VISIBLE | WS_CHILD | ES_LEFT,
			50, 100, 380, 25,
			hWnd, (HMENU)2, NULL, NULL);

		hBitmapSetTxt = CreateWindowEx(WS_EX_CLIENTEDGE, _T("EDIT"),
			_T("set1"),			
			WS_VISIBLE | WS_CHILD | ES_LEFT,
			50, 150, 380, 25,
			hWnd, (HMENU)3, NULL, NULL);

		confirmBtn = CreateWindowEx(WS_EX_CLIENTEDGE, _T("BUTTON"),
			_T("Confirmar"),
			WS_VISIBLE | WS_CHILD | ES_LEFT,
			200, 200, 100, 25,
			hWnd, (HMENU)4, NULL, NULL);
		return 0;
	}
	case WM_COMMAND:
		if (LOWORD(wParam) == 4) {	// botao confirmar
			// obter o nome do cliente
			const HWND nameTxt = GetDlgItem(hWnd, 1);
			const int lengthNameTxt = GetWindowTextLength(nameTxt);
			if (lengthNameTxt > 0) {
				GetWindowText(nameTxt, client->name, _countof(client->name));

				// nome do cliente
				if (_tcscmp(client->name, _T("Insira o nome...")) == 0) {
					MessageBox(hWnd, _T("Deve inserir um nome valido."), _T("Nome do Cliente"), MB_OK);
					break;
				}
			}
			else {
				MessageBox(hWnd, _T("Nao e possivel deixar o nome em branco"), _T("Nome do Cliente"), MB_OK);
				break;
			}

			// obter o modo de jogo
			const HWND gameModeTxt = GetDlgItem(hWnd, 2);
			const int lengthGameModeTxt = GetWindowTextLength(gameModeTxt);
			if (lengthGameModeTxt > 0) {
				GetWindowText(gameModeTxt, client->gameMode, _countof(client->gameMode));

				// modo de jogo
				if (_tcscmp(client->gameMode, _T("individual")) != 0 && _tcscmp(client->gameMode, _T("competicao")) != 0) {
					MessageBox(hWnd, _T("Deve inserir um modo de jogo valido."), _T("Modo de Jogo"), MB_OK);
					break;
				}
			}
			else {
				MessageBox(hWnd, _T("Nao e possivel deixar o modo de jogo em branco"), _T("Modo de Jogo"), MB_OK);
				break;
			}

			// obter o conjunto de imagens bmp
			const HWND bitmapSetTxt = GetDlgItem(hWnd, 3);
			const int lengthBitmapSetTxt = GetWindowTextLength(bitmapSetTxt);
			if (lengthBitmapSetTxt > 0) {
				GetWindowText(bitmapSetTxt, client->bitmapSet, _countof(client->bitmapSet));

				// conjunto de imagems bmp
				if (_tcscmp(client->bitmapSet, _T("set1")) == 0 || _tcscmp(client->bitmapSet, _T("set2")) == 0) {
					MessageBox(hWnd, _T("O jogo vai ser iniciado"), (_T("%s"),client->name), MB_OK);

					DestroyWindow(hWnd);
				}
				else {
					MessageBox(hWnd, _T("Deve inserir um conjunto de bitmaps valido."), _T("Conjunto de Bitmaps"), MB_OK);
					break;
				}
			}
			else {
				MessageBox(hWnd, _T("Nao e possivel deixar o conjunto de bitmaps em branco"), _T("Conjunto de Bitmaps"), MB_OK);
				break;
			}
		}
		break;
	case WM_CLOSE:
		if (MessageBox(hWnd, _T("Deseja sair?"), _T("Janela de Saida"), MB_ICONQUESTION | MB_YESNO) == IDYES) {
			DestroyWindow(hWnd);
		}
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	default:
		return(DefWindowProc(hWnd, messg, wParam, lParam));
		break;
	}
	return(0);
}

LRESULT CALLBACK gameEvents(HWND hWnd, UINT messg, WPARAM wParam, LPARAM lParam) {
	HDC hdc; // HANDLE DEVICE CONTENT
	RECT rect;	// estrutura do tipo Rectangle: contem dimensoes x, y, ...
	PAINTSTRUCT ps;

	// numero de retangulos (consoante as dimensoes da matriz)
	static int nrRects = 0;

	// tamanho das celulas (retangulos)
	int cellSize = 32;

	static int counterMouseHover = 0;	// maximo = 3
	enum TimerId { TimerId_MouseHover = 1, TimerId_LifeSignal = 2 };
	static const UINT hoverTimeoutInMs = 2000;	// timeout para chamar o evento mousehover
	//static const UINT lifeSignalTimeoutInMs = 15000;	// timeout para chamar o evento mousehover

	/*--------------------------- DEPOIS REPOR OS 15 SEGUNDOS ---------------------------*/
	static const UINT lifeSignalTimeoutInMs = 15000;	// timeout para chamar o evento mousehover
														
	// posicao anterior do rato, usado para saber quando houve movimento
	static int prevX = INT_MIN;
	static int prevY = INT_MIN;

	// usada para verificar se o cursor esta sobre da janela ou fora
	static BOOL isMouseOutside = TRUE;

	// variaveis para verificar se o rato esta parado sobre um retangulo e qual o retangulo
	static BOOL isMouseHovered = FALSE;
	static int hovered = 0;

	ClientGUIStruct* data;

	// recebe o 'client' atraves do 'CreateWindow()'e associa ao GWL_USERDATA
	if (messg == WM_NCCREATE)
		SetWindowLongPtr(hWnd, GWLP_USERDATA, (LONG)(((CREATESTRUCT*)lParam)->lpCreateParams));

	// obter um ponteiro com os dados do objeto ClientPipeStruct passado para a janela
	data = (ClientGUIStruct*)GetWindowLongPtr(hWnd, GWLP_USERDATA);

	BOOL newGame = FALSE;

	// janela principal
	HBITMAP hBmp = NULL;	// representa a imagem
	static HDC bmpDC = NULL;
	static BITMAP bmp;		// representa a informacao da imagem
	static HDC memDC = NULL;	// copia em memoria

	// bitmap horizontal
	static HDC bmpHorizontalDC = NULL;
	static HBITMAP hBmpHorizontal = NULL;	// representa a imagem
	static BITMAP bmpHorizontal;

	// bitmap vertical
	static HDC bmpVerticalDC = NULL;
	static HBITMAP hBmpVertical = NULL;	// representa a imagem
	static BITMAP bmpVertical;

	// bitmap cima direita 90
	static HDC bmpUpRight90DC = NULL;
	static HBITMAP hBmpUpRight90 = NULL;	// representa a imagem
	static BITMAP bmpUpRight90;

	// bitmap cima esquerda 90
	static HDC bmpUpLeft90DC = NULL;
	static HBITMAP hBmpUpLeft90 = NULL;	// representa a imagem
	static BITMAP bmpUpLeft90;

	// bitmap baixo direita 90
	static HDC bmpDownRight90DC = NULL;
	static HBITMAP hBmpDownRight90 = NULL;	// representa a imagem
	static BITMAP bmpDownRight90;

	// bitmap baixo esquerda 90
	static HDC bmpDownLeft90DC = NULL;
	static HBITMAP hBmpDownLeft90 = NULL;	// representa a imagem
	static BITMAP bmpDownLeft90;

	// win
	static HDC bmpWinDC = NULL;
	static HBITMAP hBmpWin = NULL;	// representa a imagem
	static BITMAP bmpWin;

	// loose
	static HDC bmpLooseDC = NULL;
	static HBITMAP hBmpLoose = NULL;	// representa a imagem
	static BITMAP bmpLoose;

	switch (messg) {
	case WM_CREATE:
	{
		hdc = GetDC(hWnd);

		if (_tcscmp(data->client->bitmapSet, _T("set1")) == 0) {
			hBmpHorizontal = (HBITMAP)LoadImage(NULL, HORIZONTAL_S1, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_LOADTRANSPARENT);
			hBmpVertical = (HBITMAP)LoadImage(NULL, VERTICAL_S1, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_LOADTRANSPARENT);
			hBmpUpRight90 = (HBITMAP)LoadImage(NULL, UP_RIGHT_90_S1, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_LOADTRANSPARENT);
			hBmpUpLeft90 = (HBITMAP)LoadImage(NULL, UP_LEFT_90_S1, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_LOADTRANSPARENT);
			hBmpDownRight90 = (HBITMAP)LoadImage(NULL, DOWN_RIGHT_90_S1, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_LOADTRANSPARENT);
			hBmpDownLeft90 = (HBITMAP)LoadImage(NULL, DOWN_LEFT_90_S1, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_LOADTRANSPARENT);
		}
		else if (_tcscmp(data->client->bitmapSet, _T("set2")) == 0) {
			hBmpHorizontal = (HBITMAP)LoadImage(NULL, HORIZONTAL_S2, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_LOADTRANSPARENT);
			hBmpVertical = (HBITMAP)LoadImage(NULL, VERTICAL_S2, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_LOADTRANSPARENT);
			hBmpUpRight90 = (HBITMAP)LoadImage(NULL, UP_RIGHT_90_S2, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_LOADTRANSPARENT);	
			hBmpUpLeft90 = (HBITMAP)LoadImage(NULL, UP_LEFT_90_S2, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_LOADTRANSPARENT);
			hBmpDownRight90 = (HBITMAP)LoadImage(NULL, DOWN_RIGHT_90_S2, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_LOADTRANSPARENT);
			hBmpDownLeft90 = (HBITMAP)LoadImage(NULL, DOWN_LEFT_90_S2, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_LOADTRANSPARENT);
		}
		
		/*------------------------------------------- BITMAP Horizontal -------------------------------------------*/
		GetObject(hBmpHorizontal, sizeof(bmpHorizontal), &bmpHorizontal); // vai buscar info sobre o handle do bitmap
		bmpHorizontalDC = CreateCompatibleDC(hdc);	// criamos copia do device context e colocar em memoria
		SelectObject(bmpHorizontalDC, hBmpHorizontal);	// aplicamos o bitmap ao device context

		/*------------------------------------------- BITMAP Vertical -------------------------------------------*/
		GetObject(hBmpVertical, sizeof(bmpVertical), &bmpVertical); // vai buscar info sobre o handle do bitmap
		bmpVerticalDC = CreateCompatibleDC(hdc);	// criamos copia do device context e colocar em memoria
		SelectObject(bmpVerticalDC, hBmpVertical);	// aplicamos o bitmap ao device context

		/*------------------------------------------- BITMAP 90º Cima Direita -------------------------------------------*/		
		GetObject(hBmpUpRight90, sizeof(bmpUpRight90), &bmpUpRight90); // vai buscar info sobre o handle do bitmap
		bmpUpRight90DC = CreateCompatibleDC(hdc);	// criamos copia do device context e colocar em memoria
		SelectObject(bmpUpRight90DC, hBmpUpRight90);	// aplicamos o bitmap ao device context

		/*------------------------------------------- BITMAP 90º Cima Esquerda -------------------------------------------*/
		GetObject(hBmpUpLeft90, sizeof(bmpUpLeft90), &bmpUpLeft90); // vai buscar info sobre o handle do bitmap
		bmpUpLeft90DC = CreateCompatibleDC(hdc);	// criamos copia do device context e colocar em memoria
		SelectObject(bmpUpLeft90DC, hBmpUpLeft90);	// aplicamos o bitmap ao device context

		/*------------------------------------------- BITMAP 90º Baixo Direita -------------------------------------------*/
		GetObject(hBmpDownRight90, sizeof(bmpDownRight90), &bmpDownRight90); // vai buscar info sobre o handle do bitmap
		bmpDownRight90DC = CreateCompatibleDC(hdc);	// criamos copia do device context e colocar em memoria
		SelectObject(bmpDownRight90DC, hBmpDownRight90);	// aplicamos o bitmap ao device context

		/*------------------------------------------- BITMAP 90º Baixo Esquerda -------------------------------------------*/
		GetObject(hBmpDownLeft90, sizeof(bmpDownLeft90), &bmpDownLeft90); // vai buscar info sobre o handle do bitmap
		bmpDownLeft90DC = CreateCompatibleDC(hdc);	// criamos copia do device context e colocar em memoria
		SelectObject(bmpDownLeft90DC, hBmpDownLeft90);	// aplicamos o bitmap ao device context

		/*------------------------------------------- BITMAP Win -------------------------------------------*/
		hBmpWin = (HBITMAP)LoadImage(NULL, WIN, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_LOADTRANSPARENT);
		GetObject(hBmpWin, sizeof(bmpWin), &bmpWin); // vai buscar info sobre o handle do bitmap
		bmpWinDC = CreateCompatibleDC(hdc);	// criamos copia do device context e colocar em memoria
		SelectObject(bmpWinDC, hBmpWin);	// aplicamos o bitmap ao device context

		/*------------------------------------------- BITMAP Loose -------------------------------------------*/
		hBmpLoose = (HBITMAP)LoadImage(NULL, LOOSE, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_LOADTRANSPARENT);
		GetObject(hBmpLoose , sizeof(bmpLoose), &bmpLoose); // vai buscar info sobre o handle do bitmap
		bmpLooseDC = CreateCompatibleDC(hdc);	// criamos copia do device context e colocar em memoria
		SelectObject(bmpLooseDC, hBmpLoose);	// aplicamos o bitmap ao device context

		// no fim de criar as copias de todos os bitmaps faz o release do hdc
		ReleaseDC(hWnd, hdc);

		/*------------------------------------------- Matriz de Retangulos -------------------------------------------*/
		for (int y = 0; y < data->client->game.limitY; y++) {
			for (int x = 0; x < data->client->game.limitX; x++) {
				RECT r = {
					(x * cellSize) + 1,
					(y * cellSize) + 1,
					(x * cellSize) + 1 + (cellSize - 1),
					(y * cellSize) + 1 + (cellSize - 1)
				};

				data->matrixRect[x][y] = r;
				data->cells[nrRects] = 0;
				nrRects++;
			}
		}
		return 0;
	}
	case WM_PAINT:
	{
		// temos de criar os pinceis dentro do WM_PAINT, para no fim de pintar os remover
		// assim evitamos sobrelotar os recursos graficos
		HBRUSH hBrushWhite = CreateSolidBrush(RGB(255, 255, 255));	// cor de fundo das celulas nao selecionadas
		HBRUSH hBrushGreen = CreateSolidBrush(RGB(0, 180, 0));		// cor de fundo da celula hovered
		HBRUSH hBrushRed = CreateSolidBrush(RGB(180, 0, 0));		// cor de fundo das celulas com blocos inseridos pelo monitor
		HBRUSH hBrushBlue = CreateSolidBrush(RGB(0, 160, 255));		// cor de fundo das celulas com blocos inseridos pelo monitor

		hdc = BeginPaint(hWnd, &ps);
		GetClientRect(hWnd, &rect);

		// se a copia estiver a NULL, significa que e a primeira vez que estamos a passar no WM_PAINT e estamos a trabalhar com a copia em memoria
		if (memDC == NULL) {
			// cria copia em memoria
			memDC = CreateCompatibleDC(hdc);
			hBmp = CreateCompatibleBitmap(hdc, rect.right, rect.bottom);
			// aplicamos na copia em memoria as configs que obtemos com o CreateCompatibleBitmap
			SelectObject(memDC, hBmp);
			DeleteObject(hBmp);
		}
		// operacoes feitas na copia(memDC) , operacoes feitas na memoria
		FillRect(memDC, &rect, CreateSolidBrush(RGB(255, 255, 255)));

		if (nrRects > 0) {
			// se o jogo recomecar redefine o contador de mousehovers
			if (data->client->game.clearMap) 
				counterMouseHover = 0;

			int n = 0;
			for (int y = 0; y < data->client->game.limitY; y++) {
				for (int x = 0; x < data->client->game.limitX; x++) {
					Rectangle(memDC, x * cellSize, y * cellSize, x * cellSize + cellSize + 1, y * cellSize + cellSize + 1);

					// se for um jogo novo limpamos as celulas
					if (data->client->game.clearMap)
						data->cells[n] = 0;

					if (isMouseHovered && hovered == n)
						FillRect(memDC, &data->matrixRect[x][y], hBrushGreen);
					else {
						// verifica se existem blocos no mapa
						switch (data->client->game.matrixCells[n]) {
							case _T('A'):
								FillRect(memDC, &data->matrixRect[x][y], hBrushBlue);
								break;
							case _T('B'):
								FillRect(memDC, &data->matrixRect[x][y], hBrushRed);
								break;
							case _T('V'):
								BitBlt(memDC, x * cellSize + 1, y * cellSize + 1, bmpWin.bmWidth, bmpWin.bmHeight, bmpWinDC, 0, 0, SRCCOPY);
								break;
							case _T('L'):
								BitBlt(memDC, x * cellSize + 1, y * cellSize + 1, bmpLoose.bmWidth, bmpLoose.bmHeight, bmpLooseDC, 0, 0, SRCCOPY);

								Sleep(2000);

								MessageBox(hWnd, _T("Perdeu o Jogo.\nPrograma a ser terminado..."), _T("PERDEU"), MB_OK);

								data->client->game.quit = TRUE;

								if (!WriteFile(data->hPipe, &(*data->client), sizeof(*data->client), NULL, NULL))
									_tprintf(_T("\n[WriteFile] Erro a escrever no pipe! Erro[%d]\n"), GetLastError());
								else
									_tprintf(_T("\n[WriteFile] Informei o servidor que quero outra peca.\n"));

								DestroyWindow(hWnd);

								break;
							case _T('━'):
								BitBlt(memDC, x * cellSize + 1, y * cellSize + 1, bmpHorizontal.bmWidth, bmpHorizontal.bmHeight, bmpHorizontalDC, 0, 0, SRCCOPY);
								break;
							case _T('┃'):
								BitBlt(memDC, x * cellSize + 1, y * cellSize + 1, bmpVertical.bmWidth, bmpVertical.bmHeight, bmpVerticalDC, 0, 0, SRCCOPY);
								break;
							case _T('┏'):
								BitBlt(memDC, x * cellSize + 1, y * cellSize + 1, bmpUpRight90.bmWidth, bmpUpRight90.bmHeight, bmpUpRight90DC, 0, 0, SRCCOPY);
								break;
							case _T('┓'):
								BitBlt(memDC, x * cellSize + 1, y * cellSize + 1, bmpUpLeft90.bmWidth, bmpUpLeft90.bmHeight, bmpUpLeft90DC, 0, 0, SRCCOPY);
								break;
							case _T('┛'):
								BitBlt(memDC, x * cellSize + 1, y * cellSize + 1, bmpDownLeft90.bmWidth, bmpDownLeft90.bmHeight, bmpDownLeft90DC, 0, 0, SRCCOPY);
								break;
							case _T('┗'):
								BitBlt(memDC, x * cellSize + 1, y * cellSize + 1, bmpDownRight90.bmWidth, bmpDownRight90.bmHeight, bmpDownRight90DC, 0, 0, SRCCOPY);
								break;
							default:
								FillRect(memDC, &data->matrixRect[x][y], hBrushWhite);
						}
					}
					n++;
				}
			}
		}

		// Bitblit da copia que esta em memoria para a janela principal
		BitBlt(hdc, 0, 0, rect.right, rect.bottom, memDC, 0, 0, SRCCOPY);

		EndPaint(hWnd, &ps);

		DeleteObject(hBrushWhite);
		DeleteObject(hBrushGreen);
		DeleteObject(hBrushRed);
		DeleteObject(hBrushBlue);

		data->client->game.clearMap = FALSE;
	}
	break;
	case WM_ERASEBKGND:
		return 1;
	case WM_RBUTTONDOWN:		// remove a peca na celula selecionada
		if (nrRects > 0) {
			int n = 0;
			for (int y = 0; y < data->client->game.limitY; y++) {
				for (int x = 0; x < data->client->game.limitX; x++) {
					POINT pt = { LOWORD(lParam), HIWORD(lParam) };
					if (PtInRect(&(data->matrixRect[x][y]), pt)) {
						Beep(8000, 10);						// emite um som ao clicar na celula

						// nao permite executar esta acao devio ao cliente ainda estar a espera de outro jogador para competir
						if (_tcscmp(data->client->gameMode, _T("competicao")) == 0 && !data->client->game.competitiveON)
							break;

						// se estiver a clicar numa celula que nao permita alteracoes, quebra do ciclo
						if (data->client->game.matrixCells[n] == _T('B')
							|| data->client->game.matrixCells[n] == _T('A')
							|| data->client->game.matrixCells[n] == _T('V')
							|| data->client->game.matrixCells[n] == _T('L'))
							break;

						if (data->cells[n] == 1) {	// se a celula=1 entao esta selecionada, metemos a zero para retirar a selecao
							data->cells[n] = 0;

							// atribuir a coordenada do retangulo
							data->client->game.play.x = x;

							int aux = 0;
							for (int k = data->client->game.limitY - 1; k >= 0; k--) {
								if (aux == y) {
									data->client->game.play.y = k;
									break;
								}
								aux++;
							}

							data->client->game.removePiece = TRUE;

							// escreve no pipe a estrutura cliente para o server ler a posicao onde a peca vai ser colocada
							if (!WriteFile(data->hPipe, &(*data->client), sizeof(*data->client), NULL, NULL))
								_tprintf(_T("\n[WriteFile] Erro a escrever no pipe! Erro[%d]\n"), GetLastError());
							else
								_tprintf(_T("\n[WriteFile] Informei o servidor que quero outra peca.\n"));

							// Mouse clicked -> reseta o timer (HOLD)
							SetTimer(hWnd, TimerId_MouseHover, hoverTimeoutInMs, NULL);

							// Mouse cliked -> reseta o timer (SINAL DE VIDA)
							SetTimer(hWnd, TimerId_LifeSignal, lifeSignalTimeoutInMs, NULL);
						}
						break;
					}
					n++;
				}
			}
		}
		break;
	case WM_LBUTTONDOWN:	// insere uma peca na celula selecionada
		if (nrRects > 0) {
			int n = 0, aux = 0;
			for (int y = 0; y < data->client->game.limitY; y++) {
				for (int x = 0; x < data->client->game.limitX; x++) {
					POINT pt = { LOWORD(lParam), HIWORD(lParam) };
					if (PtInRect(&(data->matrixRect[x][y]), pt)) {
						Beep(8000, 10);						// emite um som ao clicar na celula

						// nao permite executar esta acao devio ao cliente ainda estar a espera de outro jogador para competir
						if (_tcscmp(data->client->gameMode, _T("competicao")) == 0 && !data->client->game.competitiveON)
							break;

						// se estiver a clicar numa celula que nao permita alteracoes, quebra do ciclo
						if (data->client->game.matrixCells[n] == _T('B')
							|| data->client->game.matrixCells[n] == _T('A')
							|| data->client->game.matrixCells[n] == _T('V')
							|| data->client->game.matrixCells[n] == _T('L'))
							break;

						// se a celula=0 entao nao esta selecionada, metemos a 1 para a selecionar
						if (data->cells[n] == 0)
							data->cells[n] = 1;

						// atribuir a coordenada do retangulo e a peca recebida ao cliente
						data->client->game.play.x = x;

						aux = 0;
						for (int k = data->client->game.limitY - 1; k >= 0; k--) {
							if (aux == y) {
								data->client->game.play.y = k;
								break;
							}
							aux++;
						}
						data->client->game.play.piece = _T('━');

						// escreve no pipe a estrutura cliente para o server ler a posicao onde a peca vai ser colocada
						if (!WriteFile(data->hPipe, &(*data->client), sizeof(*data->client), NULL, NULL))
							_tprintf(_T("\n[WriteFile] Erro a escrever no pipe! Erro[%d]\n"), GetLastError());
						else
							_tprintf(_T("\n[WriteFile] Informei o servidor que quero outra peca.\n"));

						// Mouse clicked -> reseta o timer (HOLD)
						SetTimer(hWnd, TimerId_MouseHover, hoverTimeoutInMs, NULL);

						// Mouse cliked -> reseta o timer (SINAL DE VIDA)
						SetTimer(hWnd, TimerId_LifeSignal, lifeSignalTimeoutInMs, NULL);

						break;
					}

					n++;
				}
			}
		}
		break;
	case WM_MOUSEMOVE: {
		// If mouse was previously outside, re-request WM_MOUSELEAVE messages
		if (isMouseOutside) {
			TRACKMOUSEEVENT tme = { sizeof(tme) };
			tme.dwFlags = TME_LEAVE;
			tme.hwndTrack = hWnd;
			TrackMouseEvent(&tme);
			isMouseOutside = FALSE;
		}

		int currX = GET_X_LPARAM(lParam);
		int currY = GET_Y_LPARAM(lParam);
		if ((currX != prevX) || (currY != prevY)) {
			// Mouse moved -> reseta o timer (SINAL DE VIDA)
			SetTimer(hWnd, TimerId_LifeSignal, lifeSignalTimeoutInMs, NULL);

			// Mouse moved -> reseta o timer (HOLD)
			SetTimer(hWnd, TimerId_MouseHover, hoverTimeoutInMs, NULL);

			prevX = currX;
			prevY = currY;

			if (isMouseHovered) {
				// informa o servidor que tem de parar de suspenser a agua
				data->client->game.holdWater = FALSE;
				data->client->game.holdWaterX = -1;
				data->client->game.holdWaterY = -1;

				if (!WriteFile(data->hPipe, &(*data->client), sizeof(*data->client), NULL, NULL))
					_tprintf(_T("\n[WriteFile] Erro a escrever no pipe! Erro[%d]\n"), GetLastError());
				else
					_tprintf(_T("\n[WriteFile] Informei o servidor que quero parar de suspender a agua.\n"));
			}

			isMouseHovered = FALSE;

			InvalidateRect(hWnd, NULL, FALSE);
		}
		return 0;
	}
	case WM_MOUSELEAVE:
		KillTimer(hWnd, TimerId_MouseHover);
		isMouseOutside = TRUE;
		prevX = INT_MIN;
		prevY = INT_MIN;
		return 0;
	case WM_TIMER:
		// o cursor nao foi mexido durante um tempo especifico, significa que houve um mousehover event
		if (wParam == TimerId_MouseHover) {
			// nao permite executar esta acao devido ao cliente ainda estar a espera de outro jogador para competir
			if (_tcscmp(data->client->gameMode, _T("competicao")) == 0 && !data->client->game.competitiveON)
				return 0;

			counterMouseHover++;

			// maximo de 3 vezes que o cliente pode recorrer a esta funcionalidade
			if (counterMouseHover <= 3) {
				isMouseHovered = TRUE;

				// saber qual o retangulo onde o cursor se encontra posicionado
				if (nrRects > 0) {
					int n = 0, yY = data->client->game.limitY;
					for (int y = 0; y < data->client->game.limitY; y++) {
						yY--;
						for (int x = 0; x < data->client->game.limitX; x++) {
							POINT pt;
							GetCursorPos(&pt);
							ScreenToClient(hWnd, &pt);
							if (PtInRect(&(data->matrixRect[x][y]), pt)) {
								// informa o servidor que tem de suspender a agua caso o cursor esteja em cima
								// da celula em que a agua se encontra
								data->client->game.holdWater = TRUE;
								data->client->game.holdWaterX = x;
								data->client->game.holdWaterY = yY;
								data->client->game.play.x = -1;
								data->client->game.play.y = -1;

								if (!WriteFile(data->hPipe, &(*data->client), sizeof(*data->client), NULL, NULL))
									_tprintf(_T("\n[WriteFile] Erro a escrever no pipe! Erro[%d]\n"), GetLastError());
								else
									_tprintf(_T("\n[WriteFile] Informei o servidor que quero suspender a agua.\n"));

								hovered = n;	// index do retangulo que esta a ser hovered
							}
							n++;
						}
					}
					InvalidateRect(hWnd, NULL, FALSE);
				}
			}

			return 0;
		}

		// se receber um evento do temporizador do sinal de vida
		// apos 15 segundos sem movimentos de rato ou cliques
		if (wParam == TimerId_LifeSignal) {
			// contador chegou a zero, porem o cliente ainda esta a espera de outro jogador para competir
			if (_tcscmp(data->client->gameMode, _T("competicao")) == 0 && !data->client->game.competitiveON) {
				// reseta o timer (SINAL DE VIDA)
				SetTimer(hWnd, TimerId_LifeSignal, lifeSignalTimeoutInMs, NULL);
				return 0;
			}

			// informar o servidor de que se vai desligar
			data->client->game.quit = TRUE;

			if (!WriteFile(data->hPipe, &(*data->client), sizeof(*data->client), NULL, NULL))
				_tprintf(_T("\n[WriteFile] Erro a escrever no pipe! Erro[%d]\n"), GetLastError());
			else
				_tprintf(_T("\n[WriteFile] Informei o servidor que quero outra peca.\n"));

			MessageBox(hWnd, _T("Nao deu sinal de vida. \nPrograma a ser terminado."), _T("Sinal de Vida"), MB_OK);

			DestroyWindow(hWnd);

			return 0;
		}
		else
			return DefWindowProc(hWnd, messg, wParam, lParam);
		break;
	case WM_CLOSE:
		if (MessageBox(hWnd, _T("Deseja sair?"), _T("Janela de Saida"), MB_ICONQUESTION | MB_YESNO) == IDYES) {
			// informar o servidor de que se vai desligar
			data->client->game.quit = TRUE;

			if (!WriteFile(data->hPipe, &(*data->client), sizeof(*data->client), NULL, NULL))
				_tprintf(_T("\n[WriteFile] Erro a escrever no pipe! Erro[%d]\n"), GetLastError());
			else
				_tprintf(_T("\n[WriteFile] Informei o servidor que quero outra peca.\n"));

			DestroyWindow(hWnd);
		}
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	default:
		return(DefWindowProc(hWnd, messg, wParam, lParam));
		break;
	}
	return(0);
}