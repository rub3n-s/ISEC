﻿#include <Windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#include <tchar.h>
#include <fcntl.h>

#include "client.h"

int _tmain(int argc, TCHAR* argv[]) {
	DWORD id = GetCurrentProcessId(), nBytes;
	BOOL ret, stop = FALSE;
	int x = 0, y = 0, op = 0;
	Play auxTmp;
	TCHAR piece;
	Client client;

	CRITICAL_SECTION criticalSectionBool;

	HANDLE hStopEventThread;
	stopEventThreadStruct mainStopEvent;

	PipeData pipe;

#ifdef UNICODE
	_setmode(_fileno(stdin), _O_WTEXT);
	_setmode(_fileno(stdout), _O_WTEXT);
	_setmode(_fileno(stderr), _O_WTEXT);
#endif

	InitializeCriticalSectionAndSpinCount(
		&criticalSectionBool,
		500
	);

	_tprintf(_T("ID do Processo: %ld\n\n"), id);	// mostra o ID do processo

	client.id = id;
	client.changePiece = FALSE;
	client.nrPlays = 0;
	client.points = 0;
	client.lost = FALSE;
	client.win = FALSE;

	//--------------------------------- LIGAR O PIPE AO SERVIDOR ---------------------------------
	// tenta ligar-se a uma das instancias do named pipe
	if (!WaitNamedPipe(CLIENTS_PIPE, NMPWAIT_WAIT_FOREVER)) {
		_tprintf(_T("[ERRO] Nao foi possivel ligar ao pipe Cliente. Erro[%d]\n"), GetLastError());
		return -1;
	}

	pipe.hPipe = CreateFile(
		CLIENTS_PIPE,
		GENERIC_READ | GENERIC_WRITE,
		0,
		NULL,
		OPEN_EXISTING,
		FILE_FLAG_OVERLAPPED,
		NULL
	);

	if (pipe.hPipe == NULL) {
		_tprintf(_T("[ERRO] Nao foi possivel ligar ao pipe Cliente. Erro[%d]\n"), GetLastError());
		return -1;
	}

	//--------------------------------- OVERLAPPED ---------------------------------
	// limpamos a struct overlap
	ZeroMemory(&pipe.overlap, sizeof(pipe.overlap));

	// criar evento para o overlapped
	pipe.overlap.hEvent = CreateEvent(
		NULL,
		TRUE,
		FALSE,
		NULL
	);

	if (pipe.overlap.hEvent == NULL) {
		_tprintf(_T("[ERRO] Nao foi possivel criar o evento Overlap. Erro[%d]\n"), GetLastError());
		CloseHandle(pipe.hPipe);
		return -1;
	}

	//--------------------------------- CRIAR EVENTO PARAGEM DO SERVIDOR ---------------------------------
	mainStopEvent.stop = &stop;
	mainStopEvent.criticalSectionBool = &criticalSectionBool;

	// a thread fica a escuta de um evento caso o servidor feche
	hStopEventThread = CreateThread(
		NULL,
		0,
		stopEventThread,
		&mainStopEvent,
		0,
		NULL
	);

	if (hStopEventThread == NULL) {
		_tprintf(_T("[ERRO] Nao foi possivel criar a thread para o evento de stop do Servidor. Erro[%d]\n"), GetLastError());
		CloseHandle(pipe.hPipe);
		return -1;
	}

	//--------------------------------- PEDIR NOME E MODO DE JOGO ---------------------------------
	_tprintf(_T("Nome do Jogador: "));
	_getts_s(client.name, _countof(client.name) - 1);

	/*do {
		_tprintf(_T("Modo de Jogo ('individual' ou 'competicao'): "));
		_getts_s(client.gameMode, _countof(client.gameMode) - 1);
	} while (_tcscmp(client.gameMode, _T("individual")) != 0 && _tcscmp(client.gameMode, _T("competicao")) != 0); */

	// escreve inicialmente a sua struct no named pipe
	if (!WriteFile(pipe.hPipe,&client,sizeof(client),NULL,&pipe.overlap))
		_tprintf(_T("\n[WriteFile] Erro a escrever no pipe! Erro[%d]\n"),GetLastError());
	else
		_tprintf(_T("\n[WriteFile] Informei o servidor de que entrei.\n"));

	// ve o resultado dessa escrita
	ret = GetOverlappedResultEx(
		pipe.hPipe,
		&pipe.overlap,
		&nBytes,
		INFINITE,
		TRUE
	);

	// o ret1 e dificil de usar com sucesso pois devido ao uso de overlapped o resultado e inconsistente
	if (!ret || !nBytes) {
		_tprintf(_T("\n[ERRO] Nao foi possivel escrever no pipe. Erro[%d]\n"), GetLastError());

		EnterCriticalSection(&criticalSectionBool);
		stop = TRUE;
		LeaveCriticalSection(&criticalSectionBool);

		WaitForSingleObject(hStopEventThread, INFINITE);

		CloseHandle(pipe.hPipe);

		return -1;
	} 

	// enquanto nao terminar, vai lendo do named pipe e vendo o resultado
	EnterCriticalSection(&criticalSectionBool);
	while (!stop) {
		LeaveCriticalSection(&criticalSectionBool);
		op = 0;
		do {	
			// receber a peca aleatoria
			ret = ReadFile(pipe.hPipe, &piece, sizeof(TCHAR), &nBytes, NULL);
			if (!ret || !nBytes) {
				_tprintf(_T("\n[ERRO] Nao foi possivel ler do pipe. Erro[%d]\n"), GetLastError());
			
				EnterCriticalSection(&criticalSectionBool);
				stop = TRUE;
				break;
			}

			_tprintf(_T("\n1 - Escolher peca recebida [%c]"), piece);
			_tprintf(_T("\n2 - Escolher outra"));
			_tprintf(_T("\nOpcao: "));
			_tscanf_s(_T("%d"), &op);

			// variavel changePiece informa o servidor de que o cliente quer trocar a peca
			if (op == 2) {
				client.changePiece = TRUE;
				if (!WriteFile(pipe.hPipe, &client, sizeof(client), NULL, NULL))
					_tprintf(_T("\n[WriteFile] Erro a escrever no pipe! Erro[%d]\n"), GetLastError());
				else
					_tprintf(_T("\n[WriteFile] Informei o servidor que quero outra peca.\n"));
				client.changePiece = FALSE;
			}
		} while (op != 1);

		_tprintf(_T("Coordenada (Uso: <x> <y>): "));
		_tscanf_s(_T("%d %d"), &client.play.x, &client.play.y);

		client.play.piece = piece;
		client.nrPlays++;

		if (!WriteFile(pipe.hPipe, &client, sizeof(client), NULL, NULL))
			_tprintf(_T("\n[WriteFile] Erro a escrever no pipe! Erro[%d]\n"), GetLastError());
		else 
			_tprintf(_T("\n[WriteFile] Enviei informacao ao servidor.\n"));
	}
	LeaveCriticalSection(&criticalSectionBool);

	WaitForSingleObject(hStopEventThread, INFINITE);

	CloseHandle(pipe.hPipe);

	_tprintf(TEXT("\nPrograma cliente terminou!\n"));

	return 0;
}