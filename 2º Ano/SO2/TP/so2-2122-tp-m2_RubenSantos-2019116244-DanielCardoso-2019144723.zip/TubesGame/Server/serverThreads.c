﻿#include "server.h"
#include "serverThreads.h"

// Thread da Interface
DWORD WINAPI threadInterface(LPVOID param) {
	Interface* mainInterface = (Interface*)param;
	TCHAR command[MAX_SIZE];

	EnterCriticalSection(mainInterface->criticalSectionBool);
	while (!*mainInterface->stop) {
		LeaveCriticalSection(mainInterface->criticalSectionBool);

		// recebemos o comando
		_tprintf(_T("\nComando: "));
		_getts_s(command, _countof(command) - 1);

		// comando 'infojogadores'
		if (_tcscmp(command, _T("infojogadores")) == 0) {
			if (mainInterface->server->sharedServer->nrClients <= 0) {
				_tprintf(_T("\nNao existem jogadores na lista.\n"));
				continue;
			} 
			_tprintf(_T("\n"));
			for (int i = 0; i < mainInterface->server->sharedServer->nrClients; i++)
				_tprintf(_T("Jogador[%d]\tNome[%s]\tPontuacao[%d]\n"),
					mainInterface->server->sharedServer->clientArray[i].id, 
					mainInterface->server->sharedServer->clientArray[i].name, 
					mainInterface->server->sharedServer->clientArray[i].game.points);

			EnterCriticalSection(mainInterface->criticalSectionBool);
			continue;
		}

		// comando 'suspender'
		if (_tcscmp(command, _T("suspender")) == 0) {
			if (mainInterface->server->suspended == TRUE) {
				_tprintf(_T("O jogo ja esta suspenso.\n"));
				continue;
			}
			mainInterface->server->suspended = TRUE;

			EnterCriticalSection(mainInterface->criticalSectionBool);
			continue;
		}

		// comando 'retomar'
		if (_tcscmp(command, _T("retomar")) == 0) {
			if (mainInterface->server->suspended == FALSE) {
				_tprintf(_T("O jogo ja foi retomado.\n"));
				continue;
			}
			mainInterface->server->suspended = FALSE;

			EnterCriticalSection(mainInterface->criticalSectionBool);
			continue;
		}

		// comando 'terminar'
		if (_tcscmp(command, _T("terminar")) == 0) {
			_tprintf(_T("\nA encerrar o servidor ...\n\n"));

			EnterCriticalSection(mainInterface->criticalSectionBool);
			break;
		}

		// comando 'help'
		if (_tcscmp(command, _T("help")) == 0) {
			_tprintf(_T("\n'infojogadores' > Obter informacao sobre os jogadores e as suas pontuacoes.\n"));
			_tprintf(_T("'suspender' > Suspender o jogo.\n"));
			_tprintf(_T("'retomar' > Retomar o jogo.\n"));
			_tprintf(_T("'terminar' > Terminar o programa.\n"));

			EnterCriticalSection(mainInterface->criticalSectionBool);
			continue;
		}

		// mensagem de erro se nao for um comando valido
		_tprintf(_T("\n[ERRO] Comando desconhecido: Usar 'help' para obter a lista de comandos.\n"));

		EnterCriticalSection(mainInterface->criticalSectionBool);
	}
	LeaveCriticalSection(mainInterface->criticalSectionBool);

	return 0;
}

DWORD WINAPI threadConsumer(LPVOID param) {
	ConsumerStruct* data = (ConsumerStruct*)param;
	Screen aux;
	TCHAR ** commandArr = NULL;
	const TCHAR delim[2] = TEXT(" ");
	unsigned int nrArguments = 0;
	unsigned int nrScreens = 0;

	// entramos na secção critica do bool
	EnterCriticalSection(data->criticalSectionBool);
	while (!*data->stop) {
		LeaveCriticalSection(data->criticalSectionBool);

		// esperamos por uma posicao para lermos
		if (WaitForSingleObject(data->hSemaphoreRead, 1000) == WAIT_TIMEOUT) {
			EnterCriticalSection(data  ->criticalSectionBool);
			continue;
		}

		// copiamos a proxima posicao de leitura do buffer circular para a nossa struct auxiliar
		CopyMemory(
			&aux,
			&data->sharedBuffer->buffer[data->sharedBuffer->readIndex],
			sizeof(Screen)
		);

		// incrementa a posicao de leitura
		data->sharedBuffer->readIndex++;

		// caso cheguemos ao fim do buffer circular, voltamos à primeira posição do mesmo
		if (data->sharedBuffer->readIndex == CIRCULAR_BUFFER_SIZE) data->sharedBuffer->readIndex = 0;

		// libertamos o semáforo de escrita
		ReleaseSemaphore(data->hSemaphoreWrite, 1, NULL);

		// mensagem recebida do monitor
		_tprintf(_T("\n\nMonitor[%ld]: [%s]\n"), aux.id, aux.comando);

		// iniciar as verificacoes para o comando recebido do Monitor
		if (_tcscmp(aux.comando, _T("ativar random")) == 0) {
			data->random = TRUE;
			_tprintf(_T("\nModo aleatorio de pecas ativado.\n"));
		} 
		else if (_tcscmp(aux.comando, _T("desativar random")) == 0) {
			data->random = FALSE;
			_tprintf(_T("\nModo aleatorio de pecas desativado.\n"));
		}

		// dividir o comando
		free(commandArr);
		commandArr = splitString(aux.comando, delim, &nrArguments);

		if (commandArr == NULL) {
			EnterCriticalSection(data->criticalSectionBool);
			continue;
		}

		// comando 'fechar a torneira'
		if (_tcscmp(commandArr[0], _T("parar")) == 0) {
			data->wait = TRUE;
			data->waitSeconds = _tstoi(commandArr[1]);
			_tprintf(_T("\nO temporizador vai ser parado durante [%d] segundos.\n"), data->waitSeconds);
		} 
		else if (_tcscmp(commandArr[0], _T("inserirblocos")) == 0) {
			insertBlocks(data, _tstoi(commandArr[1]));
			_tprintf(_T("\nVao ser inseridos [%d] blocos aleatoriamente.\n"), _tstoi(commandArr[1]));
		}

		// evento para atualizar o estado visual do jogo
		SetEvent(data->hRefreshEvent);

		// entramos na secção critica do bool porque saimos no inicio do while
		EnterCriticalSection(data->criticalSectionBool);
	}
	LeaveCriticalSection(data->criticalSectionBool);

	return 0;
}

DWORD WINAPI threadPipe(LPVOID param) {
	PipeThreadStruct* data = (PipeThreadStruct*)param;
	DWORD nBytes, offset;
	HANDLE hPipe, hPipeServerToClient, hEventTemp;
	int k;
	BOOL ret, clientExists;
	Client aux;
	HANDLE hThreadClient[MAX_CLIENTS];

	for (int i = 0; i < MAX_CLIENTS; i++) {
		// criar evento que vai ser associado a esturtura overlaped
		// os eventos aqui tem de ter sempre reset manual e nao automatico porque temos de delegar essas responsabilidades ao sistema operativo
		hEventTemp = CreateEvent(
			NULL,
			TRUE,
			FALSE,
			NULL
		);

		if (hEventTemp == NULL) {
			_tprintf(_T("[ERRO] Nao foi possivel criar o evento para o pipe do %dº cliente."), i);

			EnterCriticalSection(data->criticalSectionBool);
			*data->stop = FALSE;
			LeaveCriticalSection(data->criticalSectionBool);;

			return -1;
		}

		// aqui passamos a constante FILE_FLAG_OVERLAPPED para o named pipe aceitar comunica��es assincronas
		hPipe = CreateNamedPipe(
			CLIENTS_PIPE,
			PIPE_ACCESS_DUPLEX | FILE_FLAG_OVERLAPPED,
			PIPE_WAIT | PIPE_TYPE_MESSAGE | PIPE_READMODE_MESSAGE,
			MAX_CLIENTS,
			sizeof(Client), sizeof(Client),
			1000,
			NULL
		);

		if (hPipe == INVALID_HANDLE_VALUE) {
			_tprintf(_T("[ERRO] Nao foi possivel criar o pipe para o %dº cliente."), i);

			EnterCriticalSection(data->criticalSectionBool);
			*data->stop = FALSE;
			LeaveCriticalSection(data->criticalSectionBool);

			return -1;
		}

		// criar o pipe de comunicacao do servidor para o cliente
		hPipeServerToClient = CreateNamedPipe(
			SERVER_TO_CLIENT_PIPE,
			PIPE_ACCESS_DUPLEX | FILE_FLAG_OVERLAPPED,
			PIPE_WAIT | PIPE_TYPE_MESSAGE | PIPE_READMODE_MESSAGE,
			MAX_CLIENTS,
			sizeof(ClientGameStruct), sizeof(ClientGameStruct),
			1000,
			NULL
		);

		if (hPipeServerToClient == INVALID_HANDLE_VALUE) {
			_tprintf(_T("[ERRO] Nao foi possivel criar o pipe para a comunicacao no sentido servidor > cliente."));

			EnterCriticalSection(data->criticalSectionBool);
			*data->stop = FALSE;
			LeaveCriticalSection(data->criticalSectionBool);

			return -1;
		}

		// agora o connectnamedpipe desbloqueia imediatamente e prossegue para fazer as seguintes iteracoes
		if (ConnectNamedPipe(data->hPipes[i].hPipeServerToClient, &data->hPipes[i].overlap)) {
			_tprintf(_T("[CreateNamedPipe] Ligacao servidor > cliente! Erro[%d]"), GetLastError());

			EnterCriticalSection(data->criticalSectionBool);
			*data->stop = FALSE;
			LeaveCriticalSection(data->criticalSectionBool);

			return -1;
		}

		// overlap pode vir com lixo dentro associado a ponteiro
		// boa pratica, que deve ser sempre feita e limpar para garantir que nao ha lixo
		ZeroMemory(&data->hPipes[i].overlap, sizeof(data->hPipes[i].overlap));
		data->hPipes[i].hPipeServerToClient = hPipeServerToClient;
		data->hPipes[i].hInstance = hPipe;
		data->hPipes[i].active = FALSE;
		data->hPipes[i].overlap.hEvent = hEventTemp;
		data->hEvents[i] = hEventTemp;

		// agora o connectnamedpipe desbloqueia imediatamente e prossegue para fazer as seguintes iteracoes
		if (ConnectNamedPipe(data->hPipes[i].hInstance, &data->hPipes[i].overlap)) {
			_tprintf(_T("[CreateNamedPipe] Ligacao ao cliente > servidor! Erro[%d]"),GetLastError());
			
			EnterCriticalSection(data->criticalSectionBool);
			*data->stop = FALSE;
			LeaveCriticalSection(data->criticalSectionBool);

			return -1;
		}
	}

	EnterCriticalSection(data->criticalSectionBool);
	while (!*data->stop) {
		LeaveCriticalSection(data->criticalSectionBool);

		_tprintf(_T("\n[SERVIDOR] Esperar ligacao de um cliente...\n"));

		// parametro FALSE porque esta sempre a espera de apenas 1
		offset = WaitForMultipleObjects(MAX_CLIENTS, data->hEvents, FALSE, INFINITE);
		k = offset - WAIT_OBJECT_0;

		if (k >= 0 && k < MAX_CLIENTS) {
			_tprintf(_T("\n[SERVIDOR] Cliente %d chegou...\n"), k);

			if (GetOverlappedResult(data->hPipes[k].hInstance, &data->hPipes[k].overlap, &nBytes, FALSE)) {
				ResetEvent(data->hEvents[k]);

				WaitForSingleObject(data->hMutex, INFINITE);

				if (!data->hPipes[k].active) {
					ClientThreadStruct* clientTemp = malloc(sizeof(ClientThreadStruct));
					if (clientTemp == NULL) {
						_tprintf(_T("[ERRO] Alocar memoria para a estrutura cliente. Erro[%d]\n"), GetLastError());

						EnterCriticalSection(data->criticalSectionBool);
						*data->stop = TRUE;
						break;
					}
					clientTemp->pipe = &data->hPipes[k];
					clientTemp->hEvent = data->hEvents[k];
					clientTemp->server = data->server;
					clientTemp->hMutex = data->hMutex;
					clientTemp->criticalSectionBool = data->criticalSectionBool;
					clientTemp->criticalSectionClients = data->criticalSectionClients;
					clientTemp->stop = data->stop;
					clientTemp->hRefreshEvent = data->hRefreshEvent;

					// se o cliente entrar pela primeira vez !clientExists, lanca thread timer
					hThreadClient[k] = CreateThread(
						NULL,
						0,
						threadClient,
						clientTemp,
						NULL,
						0
					);
				}

				// quando o cliente terminar o programa, sera feito um setEvent do pipe e ira vir parar aqui porque a condicao do pipe ativo
				// ainda esta a true.
				if (data->hPipes[k].active) {
					// desconectar o pipe, voltar a fazer o ConnectNamedPipe e ficar a aguardar outro cliente, isto permite que haja 
					// apenas uma instancia do namedpipe (reutilizacao)
					DisconnectAndReconnect(data->hPipes[k]);
					
					// redefinir a ativacao do pipe como FALSE
					data->hPipes[k].active = FALSE;
				}
				else
					data->hPipes[k].active = TRUE;

				ReleaseMutex(data->hMutex);
			}
		}
	}
	LeaveCriticalSection(data->criticalSectionBool);

	// espera pelas threads cliente
	WaitForMultipleObjects(MAX_CLIENTS, hThreadClient, TRUE, INFINITE);

	return 0;
}

DWORD WINAPI threadClient(LPVOID param) {
	ClientThreadStruct* data = (ClientThreadStruct*)param;
	Client aux;
	BOOL ret;
	DWORD nBytes;
	HANDLE hThreadIndividualTimer[MAX_CLIENTS];
	HANDLE hThreadCompetitionTimer = NULL;
	SharedMemoryServer* sharedMem = data->server->sharedServer;	// a mem. partilhada ja e passada por referencia para a clienthreadstruct
	ConsumerStruct* server = data->server;
	BOOL changePiece = FALSE;
	BOOL userQuitted = FALSE;

	// ler a estrutura cliente recebida no pipe
	ret = ReadFile(data->pipe->hInstance, &aux, sizeof(Client), &nBytes, NULL);
	if (!ret || !nBytes) {
		_tprintf(_T("[ERRO] Nao foi possivel ler do pipe. Erro[%d]\n"), GetLastError());

		EnterCriticalSection(data->criticalSectionBool);
		*data->stop = TRUE;
		LeaveCriticalSection(data->criticalSectionBool);

		return -1;
	}

	_tprintf(_T("\nTHREAD[%d] \tRecebi o Cliente: ID[%d] Nome[%s]\n"), GetCurrentThreadId(), aux.id, aux.name);

	EnterCriticalSection(data->criticalSectionClients);

	// adicionar o cliente a lista
	if (server->nrClients == 0)
		// criar um array dinamico para o server e apenas passar um array fixo para a shared memory
		server->clientArray = malloc(sizeof(Client));
	else if (server->nrClients > 0)
		server->clientArray = realloc(server->clientArray, sizeof(Client) * (server->nrClients + 1));

	if (server->clientArray == NULL) {
		_tprintf(_T("[malloc/realloc] Erro a alocar/realocar o array de clientes. Erro[%d]\n"), GetLastError());

		EnterCriticalSection(data->criticalSectionBool);
		*data->stop = TRUE;
		LeaveCriticalSection(data->criticalSectionBool);
	}

	// inicializar os dados do jogo do cliente
	aux.game.hPipeS2C = data->pipe->hPipeServerToClient;
	aux.game.limitX = server->limitX;
	aux.game.limitY = server->limitY;
	aux.game.holdWater = FALSE;

	for (int i = 0; i < server->limitX * server->limitY; i++)
		aux.game.matrixCells[i] = _T('·');

	// atribuir o mapa gerado pelo servidor ao cliente que chegou
	for (int y = server->limitY - 1; y >= 0; y--)
		for (int x = 0; x <= server->limitX - 1; x++)
			aux.game.matrix[x][y] = server->matrix[x][y];

	// atribuir o cliente a estrutura server
	server->clientArray[server->nrClients] = aux;

	// incrementar o num. de clientes no servidor porque e ele que controla os clientes
	server->nrClients++;

	// depois de preencher a matriz recorrendo ao server atribuimos o cliente a sharedMem
	sharedMem->clientArray[sharedMem->nrClients] = aux;
	sharedMem->nrClients++;

	LeaveCriticalSection(data->criticalSectionClients);

	// evento para atualizar o monitor
	SetEvent(data->hRefreshEvent);

	// envia a informacao do servidor pela primeira vez
	if (!WriteFile(aux.game.hPipeS2C, &aux.game, sizeof(aux.game), NULL, NULL))
		_tprintf(_T("\n[WriteFile] Erro a escrever no pipe. Erro[%d]\n\n"), GetLastError());
	else
		_tprintf(_T("\n[WriteFile] Enviei a informacao ao cliente[%s].\n\n"), aux.name);

	// se o cliente pretende jogar contra outro cliente
	if (_tcscmp(aux.gameMode, _T("competicao")) == 0) {
		while (data->server->nrClients < 2 && !*data->stop);

		// desbloqueia as funcionalidades da GUI, devido ao cliente se encontrar a espera de outro	
		aux.game.competitiveON = TRUE;

		// envia a informacao ao cliente que pretenda competir a informar que o jogo ira comecar
		if (!WriteFile(aux.game.hPipeS2C, &aux.game, sizeof(aux.game), NULL, NULL))
			_tprintf(_T("\n[WriteFile] Erro a escrever no pipe. Erro[%d]\n\n"), GetLastError());
		else
			_tprintf(_T("\n[WriteFile] Informei o cliente[%s] de que o jogo vai iniciar.\n\n"), aux.name);

		// se o cliente que ja ca estava nao entrar nesta condicao e ficar com o competetiveON = TRUE
		// significa que ja passou por ela, jogou e ganhou, e encontra-se a espera de um jogador neste momento
		// porem como esta preso no read, nao volta a entrar aqui e temos de o avisar de que chegou um cliente novo para competir

		// o cliente que ganha e sempre movido para a primeira posicao do array devido ao que perdeu ser removido
		if (!server->clientArray[0].game.competitiveON) {
			server->clientArray[0].game.competitiveON = TRUE;

			// envia a informacao ao cliente que pretenda competir a informar que o jogo ira comecar
			if (!WriteFile(server->clientArray[0].game.hPipeS2C, &server->clientArray[0].game, sizeof(server->clientArray[0].game), NULL, NULL))
				_tprintf(_T("\n[WriteFile] Erro a escrever no pipe. Erro[%d]\n\n"), GetLastError());
			else
				_tprintf(_T("\n[WriteFile] Informei o cliente[%s] de que o jogo vai iniciar.\n\n"), server->clientArray[0].name);
		}

		// se for o ultimo cliente que chegou, entao e ele que lanca a thread temporizador de competicao
		if (aux.id == server->clientArray[MAX_CLIENTS - 1].id) {
			ClientCompetitionTimerStruct* timerTemp = malloc(sizeof(ClientCompetitionTimerStruct));
			timerTemp->server = server;
			timerTemp->criticalSectionBool = data->criticalSectionBool;
			timerTemp->criticalSectionClients = data->criticalSectionClients;			
			timerTemp->hRefreshEvent = data->hRefreshEvent;
			timerTemp->hMutex = data->hMutex;
			timerTemp->stop = data->stop;
			timerTemp->userQuitted = &userQuitted;

			hThreadCompetitionTimer = CreateThread(
				NULL,
				0,
				threadCompetitionTimer,
				timerTemp,
				NULL,
				0
			);

			if (hThreadCompetitionTimer == NULL) {
				_tprintf(_T("[CreateThread] Erro a criar a thread do temporizador de competicao. Erro[%d]\n"), GetLastError());
				EnterCriticalSection(data->criticalSectionBool);
				*data->stop = TRUE;
			}
		}
	}
	// se for um jogador que entre em modo individual
	else {
		ClientIndividualTimerStruct* timerTemp = malloc(sizeof(ClientIndividualTimerStruct));
		if (timerTemp == NULL) {
			_tprintf(_T("[ERRO] Malloc no temporizador do cliente[%d]. Erro[%d]\n"), aux.id, GetLastError());

			EnterCriticalSection(data->criticalSectionBool);
			*data->stop = TRUE;
		}

		timerTemp->server = server;
		timerTemp->client = &aux;
		timerTemp->criticalSectionBool = data->criticalSectionBool;
		timerTemp->criticalSectionClients = data->criticalSectionClients;
		timerTemp->hMutex = data->hMutex;
		timerTemp->stop = data->stop;
		timerTemp->hRefreshEvent = data->hRefreshEvent;
		timerTemp->holdWater = &aux.game.holdWater;
		timerTemp->waterLastPosX = &aux.game.holdWaterX;
		timerTemp->waterLastPosY = &aux.game.holdWaterY;
		timerTemp->userQuitted = &userQuitted;

		hThreadIndividualTimer[server->nrClients - 1] = CreateThread(
			NULL,
			0,
			threadIndividualTimer,
			timerTemp,
			NULL,
			0
		);

		if (hThreadIndividualTimer[server->nrClients - 1] == NULL) {
			_tprintf(_T("[CreateThread] Erro a criar a thread do temporizador individual do cliente[%d]. Erro[%d]\n"), aux.id, GetLastError());
			EnterCriticalSection(data->criticalSectionBool);
			*data->stop = TRUE;
		}
	}

	EnterCriticalSection(data->criticalSectionBool);
	while (!*data->stop) {
		LeaveCriticalSection(data->criticalSectionBool);

		// ler a estrutura cliente recebida no pipe
		ret = ReadFile(data->pipe->hInstance, &aux, sizeof(Client), &nBytes, NULL);
		if (!ret || !nBytes) {
			_tprintf(_T("[ERRO] Nao foi possivel ler do pipe. Erro[%d]\n"), GetLastError());

			EnterCriticalSection(data->criticalSectionBool);
			*data->stop = TRUE;
			break;
		}

		// verifica se o cliente se desconectou
		if (aux.game.quit) {
			userQuitted = TRUE;
			//WaitForSingleObject(hThreadIndividualTimer[server->nrClients - 1], 2000);
			break;
		}
		// se o cliente solicitar a paragem da agua e ela for verificada atraves do hold nao entra no if
		// caso contrario verifica qual operacao esta a realizar
		else if (aux.game.play.x != -1 && aux.game.play.y != -1) {
			// verifica se o cliente inseriu a peca onde existe um bloco
			if (aux.game.matrix[aux.game.play.x][aux.game.play.y] == _T('B')) {
				_tprintf(_T("\nCliente[%d] tentou inserir/remover uma peca onde existe um bloco.\n"), aux.id);
				break;
			}
			else {
				// verificamos se o numero de jogadas e maior que zero para proceder as validacoes de remocao/modificacao de pecas
				if (aux.game.nrPlays > 0) {
					// verificamos se o cliente pretende remover a peca da pos (x,y)
					if (aux.game.removePiece) {
						aux.game.playArray[aux.game.nrPlays].x = -1;
						aux.game.playArray[aux.game.nrPlays].y = -1;
						aux.game.playArray[aux.game.nrPlays].piece = _T('·');
						aux.game.nrPlays--;

						// remover a peca do mapa, trocar com um '·', 'P' ou 'D' dependendo da posicao da peca removida
						if (aux.game.play.x == server->startingPoint.x && aux.game.play.y == server->startingPoint.y)
							aux.game.matrix[aux.game.play.x][aux.game.play.y] = _T('P');
						else if (aux.game.play.x == server->endingPoint.x && aux.game.play.y == server->endingPoint.y)
							aux.game.matrix[aux.game.play.x][aux.game.play.y] = _T('D');
						else
							aux.game.matrix[aux.game.play.x][aux.game.play.y] = _T('·');

						_tprintf(_T("\nCliente[%s] removeu a peca na posicao [%d][%d]\n"), aux.name, aux.game.play.x, aux.game.play.y);
					}
					// se o cliente nao pretender remover a peca, verificamos a jogada tem uma peca na mesma posicao
					else {
						// verificar se recebemos uma jogada com as mesma coordenadas de outras (trocar de peca)
						for (int j = 0; j < aux.game.nrPlays; j++) {
							if (aux.game.play.x == aux.game.playArray[j].x && aux.game.play.y == aux.game.playArray[j].y) {
								// vai a funcao returnPiece buscar a peca seguinte
								aux.game.playArray[j].piece = returnPiece(server, aux.game.playArray[j].piece);

								changePiece = TRUE;

								_tprintf(_T("\nCliente[%s] alterou a peca na posicao [%d][%d]\n"), aux.name, aux.game.play.x, aux.game.play.y);

								// atribuir a peca nova a matriz na posicao correspondente
								aux.game.matrix[aux.game.play.x][aux.game.play.y] = aux.game.playArray[j].piece;
							}
						}
					}
				}

				// caso seja uma jogada nova insere no array de jogadas
				if (!changePiece && !aux.game.removePiece) {
					// atribuir a jogada ao array de jogadas
					aux.game.playArray[aux.game.nrPlays] = aux.game.play;
					aux.game.nrPlays++;

					// atribuir a jogada a matrix do cliente na memoria partilhada e no servidor
					if (server->random)
						// insere uma peca aleatoria
						aux.game.matrix[aux.game.play.x][aux.game.play.y] = returnPiece(server, aux.game.play.piece);
					else
						aux.game.matrix[aux.game.play.x][aux.game.play.y] = aux.game.play.piece;

					_tprintf(_T("\nCliente[%s] inseriu a peca na posicao [%d][%d]\n"), aux.name, aux.game.play.x, aux.game.play.y);
				}
				changePiece = FALSE;

				// no fim de verificar se alterou/removeu/inseriu atribuir a peca ao array de celulas da matriz do cliente
				int auxCounter = 0;
				for (int y = server->limitY - 1; y >= 0; y--) {
					for (int x = 0; x < server->limitX; x++) {
						if (x == aux.game.play.x && y == aux.game.play.y) {
							aux.game.matrixCells[auxCounter] = aux.game.matrix[aux.game.play.x][aux.game.play.y];
							break;
						}
						auxCounter++;
					}
				}

				// repor este valor para enviar ao cliente caso ele tenha removido uma peca
				aux.game.removePiece = FALSE;

				// passa para o cliente o jogo com a jogava nova para ele atualizar o mapa
				if (!WriteFile(aux.game.hPipeS2C, &aux.game, sizeof(aux.game), NULL, NULL))
					_tprintf(_T("\n[WriteFile] Erro a escrever no pipe. Erro[%d]\n\n"), GetLastError());
				else
					_tprintf(_T("\n[WriteFile] Informei o cliente[%s] que a peca foi enviada.\n\n"), aux.name);

				// atribuir todos os valores do servidor a memoria partilhada
				WaitForSingleObject(data->hMutex, INFINITE);
				for (int j = 0; j < server->nrClients; j++) {
					if (aux.id == server->clientArray[j].id) {
						server->clientArray[j] = aux;

						// atribuir o cliente e o numero de clientes
						sharedMem->clientArray[j] = aux;
						sharedMem->nrClients = server->nrClients;
					}
				}
				ReleaseMutex(data->hMutex);

				// evento para atualizar o monitor depois das operacoes: ALTERAR, MODIFICAR ou REMOVER
				SetEvent(data->hRefreshEvent);
			}
		}
	}
	LeaveCriticalSection(data->criticalSectionBool); 

	// espera pelas threads cliente
	WaitForMultipleObjects(MAX_CLIENTS, hThreadIndividualTimer, FALSE, INFINITE);

	if (_tcscmp(aux.gameMode, _T("competicao")) == 0)
		WaitForSingleObject(hThreadCompetitionTimer, INFINITE);

	// cria um cliente temporario para substituir o que saiu
	Client tmp;
	tmp.id = 0;
	_tcscpy_s(tmp.name, _countof(_T("empty")), _T("empty"));
	_tcscpy_s(tmp.gameMode, _countof(_T("empty")), _T("empty"));
	tmp.game.nrPlays = 0;
	tmp.game.points = 0;
	tmp.game.clearMap = FALSE;
	tmp.game.nrPlays = 0;
	tmp.game.points = 0;
	tmp.game.level = 1;
	tmp.game.lost = FALSE;
	tmp.game.win = FALSE;
	tmp.game.quit = FALSE;
	tmp.game.removePiece = FALSE;
	tmp.game.holdWater = FALSE;
	tmp.game.holdWaterX = -1;
	tmp.game.holdWaterY = -1;
	tmp.game.competitiveON = FALSE;

	WaitForSingleObject(data->hMutex, INFINITE);

	// quando terminar remover o cliente
	if (server->nrClients == 2) {
		int pos = 0;
		for (int i = 0; i < server->nrClients; i++)
			if (aux.id == server->clientArray[i].id)
				pos = i;

		for (int i = pos; i < server->nrClients - 1; i++)
			server->clientArray[i] = server->clientArray[i + 1];

		// realocar o array para -1 posicao
		server->clientArray = realloc(server->clientArray, sizeof(Client) * (server->nrClients - 1));

		// decrementar o numero de clientes
		server->nrClients--;
	}
	else {
		// liberta o array
		free(server->clientArray);
		server->nrClients = 0;
	}

	// atualizar os dados da memoria partilhada com clientes vazios
	for (int i = 0; i < MAX_CLIENTS; i++)
		sharedMem->clientArray[i] = tmp;
	// se ainda houver algum cliente, atribui ao array da memoria partilhada
	if (server->nrClients > 0)
		for (int i = 0; i < server->nrClients; i++)
			sharedMem->clientArray[i] = server->clientArray[i];
	sharedMem->nrClients = server->nrClients;

	_tprintf(_T("\nCliente[%d] foi removido do sistema.\n"), aux.id);

	ReleaseMutex(data->hMutex);

	// disparar o evento para sair do WaitForMultipleObjects da pipeThread
	SetEvent(data->hEvent);

	return 0;
}

DWORD WINAPI threadIndividualTimer(LPVOID param) {
	ClientIndividualTimerStruct* data = (ClientIndividualTimerStruct*)param;
	int seconds = 0;
	int index = 0;
	int waterFlowSpeed = 2500;
	int waterLastPosX = data->server->startingPoint.x, waterLastPosY = data->server->startingPoint.y;	// a agua comeca a fluir no ponto de partida
	BOOL stopVerifyingPlays = FALSE;
	BOOL lost = FALSE;
	BOOL holdWaterAccepted = FALSE;	

	while (!lost && !*data->stop && !*data->userQuitted) {
		data->client->game.clearMap = FALSE;

		stopVerifyingPlays = FALSE;

		// temporizador definido ao criar o servidor
		if (data->client->game.level == 1) {
			seconds = data->server->timer;
			_tprintf(_T("\nNivel[%d]: %d segundos ate comecar.\n"), data->client->game.level, seconds);
		}
		else {
			seconds = data->server->timer - data->client->game.level * 1500;
			_tprintf(_T("\nNivel[%d]: %d segundos ate comecar.\n"), data->client->game.level, seconds);
		}

		// quando chegar a zero entra no ciclo de verificacao de jogadas
		while (seconds >= 0 && !*data->stop) {
			// enquanto a agua nao estiver suspensa pelo servidor, faz a contagem a decrescente
			while (!data->server->suspended && seconds >= 0) {
				// termina a thread
				if (!*data->userQuitted)
					return 0;

				if (data->server->wait)
					Sleep(data->server->waitSeconds * 1000);
				if (seconds <= 5)
					_tprintf(_T("Client[%s|%d] Faltam %d segundos\n"), data->client->name, data->client->id, seconds);
				Sleep(1000);
				seconds--;
			}
		}

		// acaba o tempo, agua comeca a fluir, avaliar o mapa com as pecas inseridas
		while (!stopVerifyingPlays && !*data->stop) {
			// se o cliente estiver com o rato em cima da celula onde a agua se encontra termina
			while (!*data->holdWater && !holdWaterAccepted && !stopVerifyingPlays && !*data->stop) {
				// termina a thread
				if (!*data->userQuitted)
					return 0;

				// comeca por verificar se o cliente realizou alguma jogada
				if (data->client->game.nrPlays == 0) {
					data->client->game.lost = TRUE;
					data->client->game.matrix[waterLastPosX][waterLastPosY] = _T('L');

					// no fim de verificar se alterou/removeu/inseriu atribuir a jogada ao array do jogo do cliente 
					int auxCounter = 0;
					for (int y = data->server->limitY - 1; y >= 0; y--) {
						for (int x = 0; x < data->server->limitX; x++) {
							if (x == waterLastPosX && y == waterLastPosY) {
								data->client->game.matrixCells[auxCounter] = _T('L');
								break;
							}
							auxCounter++;
						}
					}

					// passa para o cliente o jogo com a jogava nova para ele atualizar o mapa
					if (!WriteFile(data->client->game.hPipeS2C, &data->client->game, sizeof(data->client->game), NULL, NULL))
						_tprintf(_T("\n[WriteFile] Erro a escrever no pipe. Erro[%d]\n\n"), GetLastError());
					else 
						_tprintf(_T("\n[WriteFile] Informei o Cliente[%d] de que perdeu o jogo.\n\n"), data->client->id);

					WaitForSingleObject(data->hMutex, INFINITE);
					// atribuir o cliente a memoria partilhada e ao servidor
					for (int i = 0; i < data->server->nrClients; i++) {
						if (data->client->id == data->server->clientArray[i].id) {
							data->server->clientArray[i] = *data->client;
							data->server->sharedServer->clientArray[i] = *data->client;
						}
					}
					ReleaseMutex(data->hMutex);

					// evento para atualizar o monitor
					SetEvent(data->hRefreshEvent);

					stopVerifyingPlays = TRUE;
					lost = TRUE;
					break;
				}

				// verifica jogada a jogada, se for bem sucedida a agua fluir pelo tubo
				if (verifyPlay(*data->client, *data->server, data->client->game.playArray[index], index)) {
					// comeca em 3 segundos
					if (data->client->game.level > 1)
						waterFlowSpeed -= data->client->game.level * 250;

					// minimo de 100ms
					if (waterFlowSpeed < 250)
						waterFlowSpeed = 250;

					Sleep(waterFlowSpeed);

					// 10 pontos por tubo bem colocado
					data->client->game.points += 10;

					// guarda a ultima posicao da agua
					waterLastPosX = data->client->game.playArray[index].x;
					waterLastPosY = data->client->game.playArray[index].y;

					// verifica se chegou ao destino
					if (waterLastPosX == data->server->endingPoint.x && waterLastPosY == data->server->endingPoint.y) {
						// inserir no mapa um caracter a informar que chegou a ultima posicao e venceu
						data->client->game.matrix[waterLastPosX][waterLastPosY] = _T('V');

						// alterar variavel na estrutura cliente para informar que venceu
						data->client->game.win = TRUE;

						// no fim de verificar se alterou/removeu/inseriu atribuir a jogada ao array do jogo do cliente 
						int auxCounter = 0;
						for (int y = data->server->limitY - 1; y >= 0; y--) {
							for (int x = 0; x < data->server->limitX; x++) {
								if (x == waterLastPosX && y == waterLastPosY) {
									data->client->game.matrixCells[auxCounter] = _T('V');
									break;
								}
								auxCounter++;
							}
						}

						// passa para o cliente o jogo com a jogava nova para ele atualizar o mapa
						if (!WriteFile(data->client->game.hPipeS2C, &data->client->game, sizeof(data->client->game), NULL, NULL))
							_tprintf(_T("\n[WriteFile] Erro a escrever no pipe. Erro[%d]\n\n"), GetLastError());
						else
							_tprintf(_T("\n[WriteFile] Informei o Cliente[%d] de que venceu o nivel.\n\n"), data->client->id);

						WaitForSingleObject(data->hMutex, INFINITE);
						// atribuir o cliente a memoria partilhada e ao servidor
						for (int i = 0; i < data->server->nrClients; i++) {
							if (data->client->id == data->server->clientArray[i].id) {
								data->server->clientArray[i] = *data->client;
								data->server->sharedServer->clientArray[i] = *data->client;
							}
						}
						ReleaseMutex(data->hMutex);

						// evento para atualizar o monitor
						SetEvent(data->hRefreshEvent);

						Sleep(2000);
					}
					else {
						// atualiza o mapa e insere um 'A' na posicao da jogada para indicar que a agua se encontra nessa posicao
						data->client->game.matrix[waterLastPosX][waterLastPosY] = _T('A');

						// no fim de verificar se alterou/removeu/inseriu atribuir a jogada ao array do jogo do cliente 
						int auxCounter = 0;
						for (int y = data->server->limitY - 1; y >= 0; y--) {
							for (int x = 0; x < data->server->limitX; x++) {
								if (x == waterLastPosX && y == waterLastPosY) {
									data->client->game.matrixCells[auxCounter] = _T('A');
									break;
								}
								auxCounter++;
							}
						}

						// passa para o cliente o jogo com a jogava nova para ele atualizar o mapa
						if (!WriteFile(data->client->game.hPipeS2C, &data->client->game, sizeof(data->client->game), NULL, NULL))
							_tprintf(_T("\n[WriteFile] Erro a escrever no pipe. Erro[%d]\n\n"), GetLastError());

						WaitForSingleObject(data->hMutex, INFINITE);
						// atribuir o cliente a memoria partilhada e ao servidor
						for (int i = 0; i < data->server->nrClients; i++) {
							if (data->client->id == data->server->clientArray[i].id) {
								data->server->clientArray[i] = *data->client;
								data->server->sharedServer->clientArray[i] = *data->client;
							}
						}
						ReleaseMutex(data->hMutex);

						// incrementa a posicao do array de jogadas
						index++;

						// se o cliente estiver a fazer hold e a agua chegar ao ponto onde ele esta com o cursor
						if (*data->holdWater && waterLastPosX == *data->waterLastPosX && waterLastPosY == *data->waterLastPosY) {
							holdWaterAccepted = TRUE;
							break;
						// quando mover o cursor *data->holdWater fica a false e sai da condicao de paragem do ciclo while
						}
						else
							holdWaterAccepted = FALSE;
					}

					// evento para atualizar o monitor
					SetEvent(data->hRefreshEvent);
				}
				else {
					Sleep(waterFlowSpeed);

					// se a jogada nao for validada indica no mapa a posicao em que perdeu e avisa o cliente de que perdeu
					data->client->game.lost = TRUE;
					data->client->game.matrix[waterLastPosX][waterLastPosY] = _T('L');

					// no fim de verificar se alterou/removeu/inseriu atribuir a jogada ao array do jogo do cliente 
					int auxCounter = 0;
					for (int y = data->server->limitY - 1; y >= 0; y--) {
						for (int x = 0; x < data->server->limitX; x++) {
							if (x == waterLastPosX && y == waterLastPosY) {
								data->client->game.matrixCells[auxCounter] = _T('L');
								break;
							}
							auxCounter++;
						}
					}

					// passa para o cliente o jogo com a jogava nova para ele atualizar o mapa
					if (!WriteFile(data->client->game.hPipeS2C, &data->client->game, sizeof(data->client->game), NULL, NULL))
						_tprintf(_T("\n[WriteFile] Erro a informar o cliente de que perdeu. Erro[%d]\n\n"), GetLastError());
					else
						_tprintf(_T("\n[WriteFile] Informei o Cliente[%d] de que perdeu o jogo.\n\n"), data->client->id);

					WaitForSingleObject(data->hMutex, INFINITE);
					// atribuir o cliente a memoria partilhada e ao servidor
					for (int i = 0; i < data->server->nrClients; i++) {
						if (data->client->id == data->server->clientArray[i].id) {
							data->server->clientArray[i] = *data->client;
							data->server->sharedServer->clientArray[i] = *data->client;
						}
					}
					ReleaseMutex(data->hMutex);

					// evento para atualizar o monitor
					SetEvent(data->hRefreshEvent);

					stopVerifyingPlays = TRUE;
					lost = TRUE;
					break;
				}

				// se o cliente ganhou, resetar os valores das jogadas do cliente para preparar o proximo nivel
				if (data->client->game.win) {
					// redefine a variavel de vitoria
					data->client->game.win = FALSE;

					// incrementa o nivel
					data->client->game.level++;

					// limpar os arrays de jogadas
					Play playTmp;
					playTmp.x = -1;
					playTmp.y = -1;
					playTmp.piece = _T('·');
					for (int i = 0; i < MAX_PLAYS; i++)
						data->client->game.playArray[i] = playTmp;

					data->client->game.nrPlays = 0;

					// resetar o iterador de jogadas
					index = 0;

					// limpa o mapa do jogador, informacao na memoria partilhada
					for (int y = data->server->limitY - 1; y >= 0; y--)
						for (int x = 0; x < data->server->limitX; x++)
							data->client->game.matrix[x][y] = data->server->matrix[x][y];

					// limpar o mapa
					data->client->game.clearMap = TRUE;

					// limpar o array do estado do jogo que e enviado para o cliente, apenas deixamos ficar os blocos
					int auxCounter = 0;
					for (int y = data->server->limitY - 1; y >= 0; y--) {
						for (int x = 0; x < data->server->limitX; x++) {
							if (data->client->game.matrixCells[auxCounter] != _T('B'))
								data->client->game.matrixCells[auxCounter] = _T('·');
							auxCounter++;
						}
					}

					// informar o cliente de que o jogo vai recomecar
					if (!WriteFile(data->client->game.hPipeS2C, &data->client->game, sizeof(data->client->game), NULL, NULL))
						_tprintf(_T("\n[WriteFile] Erro a escrever no pipe. Erro[%d]\n\n"), GetLastError());
					else
						_tprintf(_T("\n[WriteFile] Informei o cliente[%s] que o jogo vai recomecar.\n\n"), data->client->name);

					data->client->game.clearMap = FALSE;

					stopVerifyingPlays = TRUE;

					WaitForSingleObject(data->hMutex, INFINITE);
					// atribuir o cliente a memoria partilhada e ao servidor
					for (int i = 0; i < data->server->nrClients; i++) {
						if (data->client->id == data->server->clientArray[i].id) {
							data->server->clientArray[i] = *data->client;
							data->server->sharedServer->clientArray[i] = *data->client;
						}
					}
					ReleaseMutex(data->hMutex);

					// evento para atualizar o monitor
					SetEvent(data->hRefreshEvent);

					break;
				}
			}
		}
	}

	return 0;
}

DWORD WINAPI threadCompetitionTimer(LPVOID param) {
	ClientCompetitionTimerStruct* data = (ClientCompetitionTimerStruct*)param;
	HANDLE hThreadsVerifyPlays[MAX_CLIENTS];
	ClientVerifyPlaysStruct verifyPlays[MAX_CLIENTS];
	BOOL verifyingComplete[MAX_CLIENTS];
	int seconds = 0;
	BOOL stopTimer = FALSE;
	BOOL competitionIsOver = FALSE;

	while (!*data->stop && !stopTimer && !competitionIsOver) {
		// temporizador definido ao criar o servidor
		// verifica em que nivel 1 dos clientes se encontra (verificar 1 e suficiente viste que esta thread apenas opera com 2)
		if (data->server->clientArray[0].game.level == 1) {
			seconds = data->server->timer;
			_tprintf(_T("\nNivel[%d]: %d segundos ate comecar.\n"), data->server->clientArray[0].game.level, seconds);
		}
		else {
			seconds = data->server->timer - data->server->clientArray[0].game.level * 1500;
			_tprintf(_T("\nNivel[%d]: %d segundos ate comecar.\n"), data->server->clientArray[0].game.level, seconds);
		}

		// quando chegar a zero entra no ciclo de verificacao de jogadas
		while (seconds >= 0 && !*data->stop) {
			// termina a thread
			if (!*data->userQuitted)
				return 0;

			// enquanto a agua nao estiver suspensa pelo servidor, faz a contagem a decrescente
			while (!data->server->suspended && seconds >= 0 && !*data->stop) {
				if (data->server->wait)
					Sleep(data->server->waitSeconds * 1000);
				if (seconds <= 5)
					_tprintf(_T("MODO COMPETICAO: Faltam %d segundos\n"), seconds);
				Sleep(1000);
				seconds--;
			}
		}

		for (int i = 0; i < MAX_CLIENTS; i++) {
			verifyingComplete[i] = FALSE;

			verifyPlays[i].server = data->server;
			verifyPlays[i].client = &data->server->clientArray[i];
			verifyPlays[i].hMutex = data->hMutex;
			verifyPlays[i].criticalSectionBool = data->criticalSectionBool;
			verifyPlays[i].criticalSectionClients = data->criticalSectionClients;
			verifyPlays[i].stop = data->stop;
			verifyPlays[i].verifyingComplete = &verifyingComplete[i];
			verifyPlays[i].hRefreshEvent = data->hRefreshEvent;
			verifyPlays[i].competitionIsOver = &competitionIsOver;

			hThreadsVerifyPlays[i] = CreateThread(
				NULL,
				0,
				threadVerifyCompetitionPlays,
				&verifyPlays[i],
				0,
				NULL
			);
		}

		// fica a espera que as verificacoes sejam concluidas em ambos os clientes
		// a verificacao de um pode demorar mais que a do outro, depende no numero de pecas inseridas no mapa
		while (!*data->stop && !stopTimer) {
			// client[0] terminou as verificacoes e perdeu
			if (verifyingComplete[0] && verifyPlays[0].client->game.lost) {
				_tprintf(_T("\nClient[%d] ganhou o jogo.\n"), verifyPlays[1].client->id);
				stopTimer = TRUE;
				competitionIsOver = TRUE;
			}
			// client[1] terminou as verificacoes e perdeu
			else if (verifyingComplete[1] && verifyPlays[1].client->game.lost) {
				_tprintf(_T("\nClient[%d] ganhou o jogo.\n"), verifyPlays[0].client->id);
				stopTimer = TRUE;
				competitionIsOver = TRUE;
			}
			// se ambos concluiram e nenhum deles perdeu, recomeca o timer
			else if (verifyingComplete[0] && verifyingComplete[1] && !verifyPlays[0].client->game.lost && !verifyPlays[1].client->game.lost) {
				_tprintf(_T("\nAmbos os clientes ganharam este nivel.\n"));
				competitionIsOver = TRUE;
			}
		}

		// espera pelas threads de verificacao de jogadas dos clientes
		WaitForMultipleObjects(MAX_CLIENTS, hThreadsVerifyPlays, TRUE, INFINITE);
	}

	return 0;
}

DWORD WINAPI threadVerifyCompetitionPlays(LPVOID param) {
	ClientVerifyPlaysStruct* data = (ClientVerifyPlaysStruct*)param;
	int index = 0;
	int waterFlowSpeed = 2500;
	int waterLastPosX = data->server->startingPoint.x, waterLastPosY = data->server->startingPoint.y;	// a agua comeca a fluir no ponto de partida
	BOOL lost = FALSE;

	// acaba o tempo, agua comeca a fluir, avaliar o mapa com as pecas inseridas
	while (!*data->verifyingComplete && !*data->competitionIsOver && !*data->stop) {
		// se o cliente estiver com o rato em cima da celula onde a agua se encontra termina
		while (!*data->verifyingComplete && !*data->competitionIsOver && !*data->stop) {
			// comeca por verificar se o cliente realizou alguma jogada
			if (data->client->game.nrPlays == 0) {
				data->client->game.lost = TRUE;
				data->client->game.matrix[waterLastPosX][waterLastPosY] = _T('L');

				// no fim de verificar se alterou/removeu/inseriu atribuir a jogada ao array do jogo do cliente 
				int auxCounter = 0;
				for (int y = data->server->limitY - 1; y >= 0; y--) {
					for (int x = 0; x < data->server->limitX; x++) {
						if (x == waterLastPosX && y == waterLastPosY) {
							data->client->game.matrixCells[auxCounter] = _T('L');
							break;
						}
						auxCounter++;
					}
				}

				// passa para o cliente o jogo com a jogava nova para ele atualizar o mapa
				if (!WriteFile(data->client->game.hPipeS2C, &data->client->game, sizeof(data->client->game), NULL, NULL))
					_tprintf(_T("\n[WriteFile] Erro a escrever no pipe. Erro[%d]\n\n"), GetLastError());
				else
					_tprintf(_T("\n[WriteFile] Informei o Cliente[%d] de que perdeu o jogo.\n\n"), data->client->id);

				WaitForSingleObject(data->hMutex, INFINITE);
				// atribuir o cliente a memoria partilhada e ao servidor
				for (int i = 0; i < data->server->nrClients; i++) {
					if (data->client->id == data->server->clientArray[i].id) {
						data->server->clientArray[i] = *data->client;
						data->server->sharedServer->clientArray[i] = *data->client;
					}
				}
				ReleaseMutex(data->hMutex);

				// evento para atualizar o monitor
				SetEvent(data->hRefreshEvent);

				*data->verifyingComplete = TRUE;
				lost = TRUE;
				break;
			}

			// verifica jogada a jogada, se for bem sucedida a agua fluir pelo tubo
			if (verifyPlay(*data->client, *data->server, data->client->game.playArray[index], index)) {
				// comeca em 3 segundos
				if (data->client->game.level > 1)
					waterFlowSpeed -= data->client->game.level * 250;

				// minimo de 100ms
				if (waterFlowSpeed < 250)
					waterFlowSpeed = 250;

				Sleep(waterFlowSpeed);

				// 10 pontos por tubo bem colocado
				data->client->game.points += 10;

				// guarda a ultima posicao da agua
				waterLastPosX = data->client->game.playArray[index].x;
				waterLastPosY = data->client->game.playArray[index].y;

				// verifica se chegou ao destino
				if (waterLastPosX == data->server->endingPoint.x && waterLastPosY == data->server->endingPoint.y) {
					// inserir no mapa um caracter a informar que chegou a ultima posicao e venceu
					data->client->game.matrix[waterLastPosX][waterLastPosY] = _T('V');

					// alterar variavel na estrutura cliente para informar que venceu
					data->client->game.win = TRUE;

					// no fim de verificar se alterou/removeu/inseriu atribuir a jogada ao array do jogo do cliente 
					int auxCounter = 0;
					for (int y = data->server->limitY - 1; y >= 0; y--) {
						for (int x = 0; x < data->server->limitX; x++) {
							if (x == waterLastPosX && y == waterLastPosY) {
								data->client->game.matrixCells[auxCounter] = _T('V');
								break;
							}
							auxCounter++;
						}
					}

					// passa para o cliente o jogo com a jogava nova para ele atualizar o mapa
					if (!WriteFile(data->client->game.hPipeS2C, &data->client->game, sizeof(data->client->game), NULL, NULL))
						_tprintf(_T("\n[WriteFile] Erro a escrever no pipe. Erro[%d]\n\n"), GetLastError());
					else
						_tprintf(_T("\n[WriteFile] Informei o Cliente[%d] de que venceu o nivel.\n\n"), data->client->id);

					WaitForSingleObject(data->hMutex, INFINITE);
					// atribuir o cliente a memoria partilhada e ao servidor
					for (int i = 0; i < data->server->nrClients; i++) {
						if (data->client->id == data->server->clientArray[i].id) {
							data->server->clientArray[i] = *data->client;
							data->server->sharedServer->clientArray[i] = *data->client;
						}
					}
					ReleaseMutex(data->hMutex);

					// evento para atualizar o monitor
					SetEvent(data->hRefreshEvent);

					Sleep(2000);
				}
				else {
					// atualiza o mapa e insere um 'A' na posicao da jogada para indicar que a agua se encontra nessa posicao
					data->client->game.matrix[waterLastPosX][waterLastPosY] = _T('A');

					// no fim de verificar se alterou/removeu/inseriu atribuir a jogada ao array do jogo do cliente 
					int auxCounter = 0;
					for (int y = data->server->limitY - 1; y >= 0; y--) {
						for (int x = 0; x < data->server->limitX; x++) {
							if (x == waterLastPosX && y == waterLastPosY) {
								data->client->game.matrixCells[auxCounter] = _T('A');
								break;
							}
							auxCounter++;
						}
					}					

					WaitForSingleObject(data->hMutex, INFINITE);
					// atribuir o cliente a memoria partilhada e ao servidor
					for (int i = 0; i < data->server->nrClients; i++) {
						if (data->client->id == data->server->clientArray[i].id) {
							data->server->clientArray[i] = *data->client;
							data->server->sharedServer->clientArray[i] = *data->client;
						}
					}

					// passa para o cliente o jogo com a jogava nova para ele atualizar o mapa
					if (!WriteFile(data->client->game.hPipeS2C, &data->client->game, sizeof(data->client->game), NULL, NULL))
						_tprintf(_T("\n[WriteFile] Erro a escrever no pipe. Erro[%d]\n\n"), GetLastError());

					ReleaseMutex(data->hMutex);

					// incrementa a posicao do array de jogadas
					index++;
				}

				// evento para atualizar o monitor
				SetEvent(data->hRefreshEvent);
			}
			else {
				Sleep(waterFlowSpeed);

				// se a jogada nao for validada indica no mapa a posicao em que perdeu e avisa o cliente de que perdeu
				data->client->game.lost = TRUE;
				data->client->game.matrix[waterLastPosX][waterLastPosY] = _T('L');

				// no fim de verificar se alterou/removeu/inseriu atribuir a jogada ao array do jogo do cliente 
				int auxCounter = 0;
				for (int y = data->server->limitY - 1; y >= 0; y--) {
					for (int x = 0; x < data->server->limitX; x++) {
						if (x == waterLastPosX && y == waterLastPosY) {
							data->client->game.matrixCells[auxCounter] = _T('L');
							break;
						}
						auxCounter++;
					}
				}

				// passa para o cliente o jogo com a jogava nova para ele atualizar o mapa
				if (!WriteFile(data->client->game.hPipeS2C, &data->client->game, sizeof(data->client->game), NULL, NULL))
					_tprintf(_T("\n[WriteFile] Erro a escrever no pipe. Erro[%d]\n\n"), GetLastError());
				else
					_tprintf(_T("\n[WriteFile] Informei o Cliente[%d] de que perdeu o jogo.\n\n"), data->client->id);

				WaitForSingleObject(data->hMutex, INFINITE);
				// atribuir o cliente a memoria partilhada e ao servidor
				for (int i = 0; i < data->server->nrClients; i++) {
					if (data->client->id == data->server->clientArray[i].id) {
						data->server->clientArray[i] = *data->client;
						data->server->sharedServer->clientArray[i] = *data->client;
					}
				}
				ReleaseMutex(data->hMutex);

				// evento para atualizar o monitor
				SetEvent(data->hRefreshEvent);

				*data->verifyingComplete = TRUE;
				lost = TRUE;
				break;
			}

			// se o cliente ganhou, resetar os valores das jogadas do cliente para preparar o proximo nivel
			if (data->client->game.win) {
				// redefine a variavel de vitoria
				data->client->game.win = FALSE;

				// incrementa o nivel
				data->client->game.level++;

				// limpar os arrays de jogadas
				Play playTmp;
				playTmp.x = -1;
				playTmp.y = -1;
				playTmp.piece = _T('·');
				for (int i = 0; i < MAX_PLAYS; i++)
					data->client->game.playArray[i] = playTmp;

				data->client->game.nrPlays = 0;

				// resetar o iterador de jogadas
				index = 0;

				// limpa o mapa do jogador, informacao na memoria partilhada
				for (int y = data->server->limitY - 1; y >= 0; y--)
					for (int x = 0; x < data->server->limitX; x++)
						data->client->game.matrix[x][y] = data->server->matrix[x][y];

				// limpar o mapa na GUI
				data->client->game.clearMap = TRUE;

				// limpar o array do estado do jogo que e enviado para o cliente, apenas deixamos ficar os blocos
				int auxCounter = 0;
				for (int y = data->server->limitY - 1; y >= 0; y--) {
					for (int x = 0; x < data->server->limitX; x++) {
						if (data->client->game.matrixCells[auxCounter] != _T('B'))
							data->client->game.matrixCells[auxCounter] = _T('·');
						auxCounter++;
					}
				}

				// passa para o cliente o jogo com a jogava nova para ele atualizar o mapa
				if (!WriteFile(data->client->game.hPipeS2C, &data->client->game, sizeof(data->client->game), NULL, NULL))
					_tprintf(_T("\n[WriteFile] Erro a escrever no pipe. Erro[%d]\n\n"), GetLastError());
				else
					_tprintf(_T("\n[WriteFile] Informei o cliente[%s] que o jogo vai recomecar.\n\n"), data->client->name);

				*data->verifyingComplete = TRUE;

				WaitForSingleObject(data->hMutex, INFINITE);
				// atribuir o cliente a memoria partilhada e ao servidor
				for (int i = 0; i < data->server->nrClients; i++) {
					if (data->client->id == data->server->clientArray[i].id) {
						data->server->clientArray[i] = *data->client;
						data->server->sharedServer->clientArray[i] = *data->client;
					}
				}
				ReleaseMutex(data->hMutex);

				// evento para atualizar o monitor
				SetEvent(data->hRefreshEvent);

				break;
			}
		}
	}

	// se sair do ciclo porque a competicao terminou, significa que o outro cliente perdeu
	if (*data->competitionIsOver) {
		// resetar o iterador de jogadas
		index = 0;

		// redefine a variavel de vitoria
		data->client->game.win = FALSE;

		// incrementa o nivel
		data->client->game.level = 1;

		// limpar o mapa na GUI
		data->client->game.clearMap = TRUE;

		// repoe o valor a false, fica a true de novo assim que entrar outro jogador para competir
		data->client->game.competitiveON = FALSE;

		// limpar os arrays de jogadas
		Play playTmp;
		playTmp.x = -1;
		playTmp.y = -1;
		playTmp.piece = _T('·');
		for (int i = 0; i < MAX_PLAYS; i++)
			data->client->game.playArray[i] = playTmp;

		data->client->game.nrPlays = 0;

		// limpa o mapa do jogador, informacao na memoria partilhada
		for (int y = data->server->limitY - 1; y >= 0; y--)
			for (int x = 0; x < data->server->limitX; x++)
				data->client->game.matrix[x][y] = data->server->matrix[x][y];

		// limpar o array do estado do jogo que e enviado para o cliente, apenas deixamos ficar os blocos
		int auxCounter = 0;
		for (int y = data->server->limitY - 1; y >= 0; y--) {
			for (int x = 0; x < data->server->limitX; x++) {
				if (data->client->game.matrixCells[auxCounter] != _T('B'))
					data->client->game.matrixCells[auxCounter] = _T('·');
				auxCounter++;
			}
		}

		// informar o cliente de que o jogo vai recomecar
		if (!WriteFile(data->client->game.hPipeS2C, &data->client->game, sizeof(data->client->game), NULL, NULL))
			_tprintf(_T("\n[WriteFile] Erro a escrever no pipe. Erro[%d]\n\n"), GetLastError());
		else
			_tprintf(_T("\n[WriteFile] Informei o cliente[%s] que o jogo vai recomecar.\n\n"), data->client->name);
				
		*data->verifyingComplete = TRUE;

		WaitForSingleObject(data->hMutex, INFINITE);
		// atribuir o cliente a memoria partilhada e ao servidor
		for (int i = 0; i < data->server->nrClients; i++) {
			if (data->client->id == data->server->clientArray[i].id) {
				data->server->clientArray[i] = *data->client;
				data->server->sharedServer->clientArray[i] = *data->client;
			}
		}
		ReleaseMutex(data->hMutex);

		// evento para atualizar o monitor
		SetEvent(data->hRefreshEvent);
	}

	return 0;
}