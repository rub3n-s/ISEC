#include <windows.h>

// thread consumidor (le do buffer a estrutura monitor)
DWORD WINAPI threadConsumer(LPVOID param);

// thread da interface do servidor
DWORD WINAPI threadInterface(LPVOID param);

// thread para gerir o tempo que falta ate a agua fluir
DWORD WINAPI threadManageScreen(LPVOID param);

// thread para criar os pipes e gerir o overlapped
DWORD WINAPI threadPipe(LPVOID param);

// gere os dados vindos dos clientes ao se conectarem
DWORD WINAPI threadClient(LPVOID param);

// gere o temporizador dos clientes em modo individual
DWORD WINAPI threadIndividualTimer(LPVOID param);

// gere o temporizador dos clientes em modo competicao
DWORD WINAPI threadCompetitionTimer(LPVOID param);

// verifica as jogadas dos clientes
DWORD WINAPI threadVerifyCompetitionPlays(LPVOID param);