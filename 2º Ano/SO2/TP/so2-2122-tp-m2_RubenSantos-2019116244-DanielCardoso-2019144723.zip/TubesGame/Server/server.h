#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#include <tchar.h>
#include <fcntl.h>
#include <time.h>

#define MAX_PLAYS 1000
#define MAX_CLIENTS 2
#define MAX_SIZE 128	// tamanho maximo aceite num array de carateres
#define MATRIX_MAX 20
#define CIRCULAR_BUFFER_SIZE 20	// tamanho do buffer circular

#define SHARED_MEM_SERVER _T("SHARED_MEM_SERVER")

#define SEMAPHORE_UNIQUE_SERVER _T("SERVER_SEMAPHORE")	    // garante que apenas existe uma instancia
#define SEMAPHORE_CIRCULAR_READ _T("CIRCULAR_SEMAPHORE_READ")	// nome do Semaforo de Leitura
#define SEMAPHORE_CIRCULAR_WRITE _T("CIRCULAR_SEMAPHORE_WRITE")	// nome do Semaforo de Escrita

#define FILEMAPPING_CIRCULAR _T("CIRCULAR_FILE_MAPPING")	// nome do FileMapping do Buffer Circular

#define FILEMAPPING_SCREENS _T("SCRRENS_FILE_MAPPING")		// nome do FileMapping dos Monitores

#define MUTEX_CIRCULAR _T("MUTEX_CIRCULAR")     				// nome do Mutex dos Monitores

#define EVENT_SERVER_CLOSED _T("CLOSED_SERVER_EVENT")      // nome do evento de fecho do servidor
#define EVENT_SCREEN_REFRESH _T("EVENT_SCREEN_REFRESH")    // nome do evento para atualizar o estado do jogo no monitor

#define REGISTRY_PATH "Software\\TubesGame"     // caminho para as chaves do registry

#define CLIENTS_PIPE _T("\\\\.\\pipe\\CLIENTS")   // pipe dos clientes
#define SERVER_TO_CLIENT_PIPE   _T("\\\\.\\pipe\\SERVER_TO_CLIENT")   // pipe do servidor

#define CONNECTING_STATE 0 
#define READING_STATE 1 
#define WRITING_STATE 2 

typedef struct {
    int x;
    int y;
} Coordinate;

typedef struct {
    int x;
    int y;
    TCHAR piece;
} Play;

typedef struct {
    HANDLE hPipeS2C;
    int limitX;
    int limitY;
    BOOL clearMap;
    BOOL competitiveON;
    int level;
    int points;
    TCHAR matrix[MATRIX_MAX][MATRIX_MAX];
    TCHAR matrixCells[MATRIX_MAX * MATRIX_MAX];
    Play play;
    Play playArray[MAX_PLAYS];
    int nrPlays;
    TCHAR receivedPiece;
    BOOL removePiece;
    BOOL lost;
    BOOL win;
    BOOL quit;
    BOOL holdWater;
    int holdWaterX;
    int holdWaterY;
} ClientGameStruct;

typedef struct {
    ClientGameStruct game;
    DWORD id;
    TCHAR name[MAX_SIZE];
    TCHAR gameMode[MAX_SIZE];
    TCHAR bitmapSet[MAX_SIZE];
} Client;

// representa a nossa memoria partilhada
typedef struct {
    TCHAR matrix[MATRIX_MAX][MATRIX_MAX];
    
    Client clientArray[MAX_CLIENTS];
    int nrClients;

    Coordinate startingPoint;
    Coordinate endingPoint;
    int limitX;
    int limitY;
    int timer;
} SharedMemoryServer;

typedef struct {
    DWORD id;
    TCHAR comando[MAX_SIZE];
} Screen;

// representa a nossa memoria partilhada
typedef struct {
    int nScreens;   // numero de monitores
    int writeIndex; // proxima posicao de escrita
    int readIndex; // proxima posicao de leitura

    Screen buffer[CIRCULAR_BUFFER_SIZE]; // buffer circular em si (array de estruturas)
} SharedBufferMemory;

// estrutura de apoio ao buffer circular
typedef struct {
    SharedBufferMemory* sharedBuffer; // ponteiro para a memoria partilhada
    SharedMemoryServer* sharedServer;

    TCHAR matrix[MATRIX_MAX][MATRIX_MAX];

    Client* clientArray;
    int nrClients;

    Coordinate startingPoint;
    Coordinate endingPoint;
    int limitX;
    int limitY;
    int timer;
    BOOL suspended;
    BOOL wait;
    BOOL random;
    int waitSeconds;
    TCHAR sendPiece;

    HANDLE hSemaphoreWrite; // handle para o semaforo que controla as escritas (controla quantas posicoes estao vazias)
    HANDLE hSemaphoreRead; // handle para o semaforo que controla as leituras (controla quantas posicoes estao preenchidas)

    HANDLE hManageScreenEvent, hRefreshEvent, hStopEvent;

    LPCRITICAL_SECTION criticalSectionScreens, criticalSectionBool;

    BOOL* stop;
} ConsumerStruct;

// estrutura da interface
typedef struct {
    ConsumerStruct* server;

    HANDLE hSharedScreensMutex;

    LPCRITICAL_SECTION criticalSectionScreens, criticalSectionBool;

    BOOL* stop;
} Interface;

typedef struct {
    HANDLE hPipeServerToClient;
    HANDLE hInstance;
    OVERLAPPED overlap;
    BOOL active; //representa se a instancia do named pipe esta ou nao ativa, se ja tem um cliente ou nao
} PipeStruct;

typedef struct {
    ConsumerStruct* server;
    PipeStruct hPipes[MAX_CLIENTS];
    HANDLE hEvents[MAX_CLIENTS], hMutex, hRefreshEvent;

    LPCRITICAL_SECTION criticalSectionClients, criticalSectionBool;
    BOOL* stop;
} PipeThreadStruct;

typedef struct {
    ConsumerStruct* server;
    PipeStruct* pipe;
    HANDLE hMutex, hEvent, hRefreshEvent;
    LPCRITICAL_SECTION criticalSectionBool, criticalSectionClients;
    BOOL* stop;
} ClientThreadStruct;

typedef struct {
    ConsumerStruct* server;
    Client* client;
    HANDLE hRefreshEvent;
    HANDLE hMutex;
    LPCRITICAL_SECTION criticalSectionBool, criticalSectionClients;
    BOOL* stop;
    BOOL* holdWater;
    int* waterLastPosX;
    int* waterLastPosY;
    BOOL* userQuitted;
} ClientIndividualTimerStruct;

typedef struct {
    ConsumerStruct* server;
    HANDLE hMutex;
    HANDLE hRefreshEvent;
    LPCRITICAL_SECTION criticalSectionBool, criticalSectionClients;
    BOOL* stop;
    BOOL* userQuitted;
} ClientCompetitionTimerStruct;

typedef struct {
    ConsumerStruct* server;
    Client* client;
    HANDLE hRefreshEvent;
    HANDLE hMutex;
    LPCRITICAL_SECTION criticalSectionBool, criticalSectionClients;
    BOOL* stop;
    BOOL* verifyingComplete;
    BOOL* competitionIsOver;
} ClientVerifyPlaysStruct;

void presentation();
void initializeVariables(ConsumerStruct* server);
BOOL defineParameters(ConsumerStruct* server, int argc, TCHAR* argv[]);
void displayParameters(ConsumerStruct server);

Coordinate defineCoordinate(ConsumerStruct server, int limiteX, int limiteY);
BOOL createRegistry(TCHAR path[], TCHAR name[], int value);
BOOL loadRegistry(ConsumerStruct* server, TCHAR path[], TCHAR name[]);

void insertBlocks(ConsumerStruct* server, int nrBlocks);
TCHAR returnPiece(ConsumerStruct* server, TCHAR actualPiece);
BOOL verifyPlay(Client client, ConsumerStruct server, Play play, int number);

BOOL DisconnectAndReconnect(PipeStruct pipe);