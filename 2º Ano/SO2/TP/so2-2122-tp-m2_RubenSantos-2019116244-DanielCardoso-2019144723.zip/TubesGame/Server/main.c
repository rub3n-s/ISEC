#include "serverThreads.h"
#include "server.h"

int _tmain(int argc, TCHAR* argv[]) {   
    BOOL stop = FALSE;
    CRITICAL_SECTION criticalSectionBool, criticalSectionScreens, criticalSectionClients;

    Interface mainInterface;
    ConsumerStruct consumerData;
    PipeThreadStruct pipeData;

    HANDLE hSemaphoreUnique, hFileMapScreens, hFileMapConsumer, hSharedServerInfo; // handles semaforo unico/filemappings

    HANDLE hStopEvent, hRefreshEvent, hManageScreenEvent, hWriteToCircularBufferEvent;   // handles eventos

    HANDLE hThreadInterface, hThreadConsumer, hThreadManageScreen, hThreadPipe;  // handles threads

#ifdef UNICODE
    _setmode(_fileno(stdin), _O_WTEXT);
    _setmode(_fileno(stdout), _O_WTEXT);
    _setmode(_fileno(stderr), _O_WTEXT);
#endif

    // cria um semaforo para garantir uma execucao de um unico processo servidor
    hSemaphoreUnique = CreateSemaphore(
        NULL,
        1,
        2,
        SEMAPHORE_UNIQUE_SERVER
    );

    // Se ERROR_ALREADY_EXISTS , entao nao deixa iniciar outro servidor
    if (GetLastError() == ERROR_ALREADY_EXISTS) {
        _tprintf(_T("[ERRO] Ja existe um servidor aberto: Erro[%d]\n"), GetLastError());
        return -1;
    }

    InitializeCriticalSectionAndSpinCount(
        &criticalSectionBool,
        500
    );

    InitializeCriticalSectionAndSpinCount(
        &criticalSectionScreens,
        500
    );

    InitializeCriticalSectionAndSpinCount(
        &criticalSectionClients,
        500
    );

    //--------------------------------- CRIAR EVENTO PARAGEM DO SERVIDOR ---------------------------------
    hStopEvent = CreateEvent(
        NULL,
        TRUE,
        FALSE,
        EVENT_SERVER_CLOSED
    );

    if (hStopEvent == NULL) {
        _tprintf(_T("[CreateEvent] Nao foi possivel criar o evento de notificacao de saida: Erro[%d]\n"), GetLastError());
        return -1;
    }

    //--------------------------------- CRIAR EVENTO DE ESCRITA NO BUFFER ---------------------------------
    // criar o evento que sinaliza quando ira escrever no buffer
    hManageScreenEvent = CreateEvent(
        NULL,
        TRUE,
        FALSE,
        NULL
    );

    if (hManageScreenEvent == NULL) {
        _tprintf(_T("[CreateEvent] Nao foi possivel criar o evento de gestao de monitores: Erro[%d]\n"), GetLastError());

        EnterCriticalSection(&criticalSectionBool);
        stop = TRUE;
        LeaveCriticalSection(&criticalSectionBool);

        return -1;
    }

    //--------------------------------- CRIAR EVENTO ATUALIZACAO VISUAL DO JOGO ---------------------------------
    hRefreshEvent = CreateEvent(
        NULL,
        TRUE,
        FALSE,
        EVENT_SCREEN_REFRESH
    );

    if (hRefreshEvent == NULL) {
        _tprintf(_T("[CreateEvent] Nao foi possivel criar o evento de atualizacao do estado do jogo: Erro[%d]\n"), GetLastError());
        return -1;
    }

    //--------------------------------- CRIAR THREAD DOS PIPES CLIENTE ---------------------------------
    pipeData.hMutex = CreateMutex(NULL, FALSE, NULL);
    pipeData.criticalSectionBool = &criticalSectionBool;
    pipeData.criticalSectionClients = &criticalSectionClients;
    pipeData.stop = &stop;
    pipeData.server = &consumerData;
    pipeData.hRefreshEvent = hRefreshEvent;

    hThreadPipe = CreateThread(
        NULL,
        0,
        threadPipe,
        &pipeData,
        0,
        NULL
    );
    
    if (hThreadPipe == NULL) {
        _tprintf(_T("[CreateThread] Erro a criar a thread dos pipes. Erro[%d]\n"), GetLastError());
        
        EnterCriticalSection(&criticalSectionBool);
        stop = TRUE;
        LeaveCriticalSection(&criticalSectionBool);

        return -1;
    }

    // mensagem de apresentacao
    presentation();

    // inicializar as variaveis da estrutura Servidor
    initializeVariables(&consumerData);

    // definir parametros para limites e temporizador
    if (!defineParameters(&consumerData, argc, argv)) {
        _tprintf(_T("\nA encerrar o servidor.\n"));
        return -1;
    }

    // mostra os valores em servidor
    displayParameters(consumerData);

    //------------------------------------- CRIAR MEMORIA PARTILHADA INFO SERVIDOR -------------------------------------    
    hSharedServerInfo = CreateFileMapping(
        INVALID_HANDLE_VALUE,
        NULL,
        PAGE_READWRITE,
        0,
        sizeof(SharedMemoryServer),
        SHARED_MEM_SERVER
    );

    if (hSharedServerInfo == NULL) {
        _tprintf(_T("[CreateFileMapping] Nao foi possivel criar o FileMapping da informacao do servidor: Erro[%d]\n"), GetLastError());

        EnterCriticalSection(&criticalSectionBool);
        stop = TRUE;
        LeaveCriticalSection(&criticalSectionBool);

        return -1;
    }

    // mapeamos o bloco de memoria para o espaco de enderecamento do processo
    consumerData.sharedServer = (SharedMemoryServer*)MapViewOfFile(
        hSharedServerInfo,
        FILE_MAP_ALL_ACCESS,
        0,
        0,
        0
    );

    if (consumerData.sharedServer == NULL) {
        _tprintf(_T("[MapViewOfFile] Nao foi possivel criar a vista para a memoria partilhada: Erro[%d]\n"), GetLastError());

        EnterCriticalSection(&criticalSectionBool);
        stop = TRUE;
        LeaveCriticalSection(&criticalSectionBool);

        return -1;
    }

    // preenchemos a estrutura da memoria partilhada
    for (int y = consumerData.limitY - 1; y >= 0; y--)
        for (int x = 0; x < consumerData.limitX; x++)
            consumerData.sharedServer->matrix[x][y] = consumerData.matrix[x][y];
    consumerData.sharedServer->limitX = consumerData.limitX;
    consumerData.sharedServer->limitY = consumerData.limitY;
    consumerData.sharedServer->nrClients = 0;
    consumerData.stop = &stop;
    consumerData.hManageScreenEvent = hManageScreenEvent;
    consumerData.criticalSectionBool = &criticalSectionBool;
    consumerData.criticalSectionScreens = &criticalSectionScreens;
    consumerData.hRefreshEvent = hRefreshEvent;
    consumerData.hStopEvent = hStopEvent;
    consumerData.nrClients = 0;

    //------------------------------------- INICIAR INTERFACE -------------------------------------	
    // inicializar as variaveis da estrutura Interface
    mainInterface.server = &consumerData;
    mainInterface.criticalSectionScreens = &criticalSectionScreens;
    mainInterface.criticalSectionBool = &criticalSectionBool;
    mainInterface.stop = &stop;

    // cria a thread da interface
    hThreadInterface = CreateThread(
        NULL,
        0,
        threadInterface,
        &mainInterface,
        0,
        NULL
    );

    if (hThreadInterface == NULL) {
        _tprintf(_T("[CreateThread] Impossivel criar thread interface: Erro[%d]\n"), GetLastError());

        EnterCriticalSection(&criticalSectionBool);
        stop = TRUE;
        LeaveCriticalSection(&criticalSectionBool);

        return -1;
    }

    //------------------------------------- RECEBER INFO DO MONITOR -------------------------------------
    // cria semaforo de escrita para o buffer circular
    consumerData.hSemaphoreWrite = CreateSemaphore(
        NULL,
        CIRCULAR_BUFFER_SIZE,
        CIRCULAR_BUFFER_SIZE,
        SEMAPHORE_CIRCULAR_WRITE
    );

    // cria semaforo de leitura para o buffer circular
    consumerData.hSemaphoreRead = CreateSemaphore(
        NULL,
        0,
        CIRCULAR_BUFFER_SIZE,
        SEMAPHORE_CIRCULAR_READ
    );

    // caso de erro na criacao dos semaforos, alteramos o stop para TRUE e aguardamos que a ThreadInterface termine
    if (consumerData.hSemaphoreWrite == NULL || consumerData.hSemaphoreRead == NULL) {
        _tprintf(_T("[CreateSemaphore] Nao foi possivel criar semaforos para o buffer circular: Erro[%d]\n"), GetLastError());

        EnterCriticalSection(&criticalSectionBool);
        stop = TRUE;
        LeaveCriticalSection(&criticalSectionBool);

        WaitForSingleObject(hThreadInterface, INFINITE);

        return -1;
    }

    // cria o FileMapping do buffer circular
    hFileMapConsumer = CreateFileMapping(
        INVALID_HANDLE_VALUE,
        NULL,
        PAGE_READWRITE,
        0,
        sizeof(SharedBufferMemory),
        FILEMAPPING_CIRCULAR
    );

    if (hFileMapConsumer == NULL) {
        _tprintf(_T("[CreateFileMapping] Nao foi possivel criar o FileMapping do buffer circular: Erro[%d]\n"), GetLastError());

        EnterCriticalSection(&criticalSectionBool);
        stop = TRUE;
        LeaveCriticalSection(&criticalSectionBool);

        return -1;
    }

    // mapeamos o bloco de memoria para o espaco de enderecamento do processo
    consumerData.sharedBuffer = (SharedBufferMemory*)MapViewOfFile(
        hFileMapConsumer,
        FILE_MAP_ALL_ACCESS,
        0,
        0,
        0
    );

    if (consumerData.sharedBuffer == NULL) {
        _tprintf(_T("[MapViewOfFile] Nao foi possivel criar a vista para a memoria partilhada: Erro[%d]\n"), GetLastError());

        EnterCriticalSection(&criticalSectionBool);
        stop = TRUE;
        LeaveCriticalSection(&criticalSectionBool);

        WaitForSingleObject(hThreadInterface, INFINITE);

        return -1;
    }

    // preenchemos a estrutura de apoio ao buffer circular
    consumerData.hManageScreenEvent = hManageScreenEvent;
    consumerData.criticalSectionBool = &criticalSectionBool;
    consumerData.criticalSectionScreens = &criticalSectionScreens;
    consumerData.stop = &stop;
    consumerData.hRefreshEvent = hRefreshEvent;

    // preenchemos a estrutura da memoria partilhada
    consumerData.sharedBuffer->nScreens = 0;
    consumerData.sharedBuffer->writeIndex = 0;
    consumerData.sharedBuffer->readIndex = 0;

    hThreadConsumer = CreateThread(
        NULL,
        0,
        threadConsumer,
        &consumerData,
        0,
        NULL
    );

    if (hThreadConsumer == NULL) {
        _tprintf(_T("[MapViewOfFile] Nao foi possivel criar a thread consumidor: Erro[%d]\n"), GetLastError());

        EnterCriticalSection(&criticalSectionBool);
        stop = TRUE;
        LeaveCriticalSection(&criticalSectionBool);

        WaitForSingleObject(hThreadInterface, INFINITE);

        return -1;
    }

    WaitForSingleObject(hThreadInterface, INFINITE);    // espera pela thread da interface

    // entra na seccao critica assim que o WaitForSingleObject da thread interface terminar (stop=TRUE, vai parar os restantes)
    EnterCriticalSection(&criticalSectionBool);
    stop = TRUE;
    LeaveCriticalSection(&criticalSectionBool);

    WaitForSingleObject(hThreadPipe, INFINITE);
    WaitForSingleObject(hThreadConsumer, INFINITE); 

    UnmapViewOfFile(consumerData.sharedBuffer);   // liberta a memoria partilhada
    UnmapViewOfFile(consumerData.sharedServer);   // liberta a memoria partilhada

    SetEvent(hStopEvent);   // avisa que o servidor esta a encerrar

    return 0;
}