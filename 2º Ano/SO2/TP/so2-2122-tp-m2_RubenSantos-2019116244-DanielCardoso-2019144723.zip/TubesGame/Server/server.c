﻿#include "server.h"

void presentation() {
	_tprintf(_T("┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n"));
	_tprintf(_T("┃  Jogo dos Tubos                          ┃\n"));
	_tprintf(_T("┃                                          ┃\n"));
	_tprintf(_T("┃  Realizado por:                          ┃\n"));
	_tprintf(_T("┃      Daniel Cardoso - 2019144723         ┃\n"));
	_tprintf(_T("┃      Ruben Santos   - 2019116244         ┃\n"));
	_tprintf(_T("┃                                          ┃\n"));
	_tprintf(_T("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n"));
}

void initializeVariables(ConsumerStruct* server) {
	server->limitX = 0;
	server->limitY = 0;
	server->startingPoint.x = 0;
	server->startingPoint.y = 0;
	server->endingPoint.x = 0;
	server->endingPoint.y = 0;
	server->timer = 0;
	server->suspended = FALSE;
	server->wait = FALSE;
	server->waitSeconds = 0;
	server->random = FALSE;
	for (int y = 0; y < MATRIX_MAX; y++)
		for (int x = 0; x < MATRIX_MAX; x++)
			server->matrix[x][y] = _T('·');
}

Coordinate defineCoordinate(ConsumerStruct server, int limitX, int limitY) {
	Coordinate tmp;
	int x = 0, y = 0;

	tmp.x = 0;
	tmp.y = 0;

	// inicializacao do time
	srand(time(NULL));

	BOOL tf = FALSE;

	// se as coordenadas de ponto de partida estiverem a zero, entao tem de ser definidas
	if (server.startingPoint.x == 0 && server.startingPoint.y == 0) {
		// TRUE-FALSE (0 ou 1)
		tf = (rand() % 2) != 0;

		// metodo utilizado para escolher qual o quadrante a utilizar
		if (tf)		// lado direito
			x = (rand() % (limitX - limitX / 2)) + limitX / 2;
		else        // lado esquerdo
			x = rand() % (limitX / 2);

		// condicao para o caso de x ficar numa extremidade
		if (x == 0 || x == limitX - 1)
			y = (rand() % (limitY - 1)) + 1;	// y vai gerar um numero entre 1 e limitY-1
		// caso x nao esteja numa extremidade, temos de garantir que y esta
		else {
			tf = (rand() % 2) != 0;	// aplica-se de novo para escolher aleatoriamente o lado

			// escolher aleatoriamente qual a extremidade de y 
			if (tf)		// lado direito
				y = 0;
			else        // lado esquerdo
				y = limitY - 1;
		}

		// definir ponto de partida
		tmp.x = x;
		tmp.y = y;

		// devolve a coordenada
		return tmp;
	}

	// se as coordenadas de ponto de destino estiverem a zero, entao tem de ser definidas

	// comecar por verificar de que lado esta o ponto de partida, para o de destino ficar do lado oposto

	if (server.startingPoint.x == 0 || server.startingPoint.x == limitX - 1) {
		if (server.startingPoint.y < limitY / 2)	// quadrante esquerdo, entao y tem de ficar do lado direito
			y = (rand() % (limitY - limitY / 2)) + limitY / 2;
		else
			y = (rand() % (limitY / 2 - 1)) + 1;

		// definir ponto de destino 'x' na extremidade oposta
		if (server.startingPoint.x == 0)
			tmp.x = limitX - 1;
		else
			tmp.x = 0;
		tmp.y = y;
	}
	// pode estar em qualquer x, entao y tera de ficar no ponto maximo ou minimo
	else {
		// obter um x aleatorio que nao esteja nas extremidades
		if (server.startingPoint.x < limitX / 2)
			x = (rand() % (limitX - limitX / 2)) + limitX / 2;
		else
			x = (rand() % (limitX / 2 - 1)) + 1;

		// definir ponto de destino 'y' na extremidade oposta
		if (server.startingPoint.y == 0)
			tmp.y = limitY - 1;
		else
			tmp.y = 0;
		tmp.x = x;
	}

	// devolve a coordenada (so chega aqui quando se esta a definir o ponto de destino)
	return tmp;
}

BOOL defineParameters(ConsumerStruct* server, int argc, TCHAR* argv[]) {
	switch (argc) {
		// se apenas tiver 1 argumento, verifica no registry se existem as chaves respetivas
	case 1:
		// se alguma das chaves nao existir, return FALSE e encerra o programa no main
		if (!loadRegistry(server, REGISTRY_PATH, _T("limitX"))) {
			_tprintf(_T("\n[ERRO] Leitura do 'limite X' a partir do registry."));
			return FALSE;
		}
		else if (!loadRegistry(server, REGISTRY_PATH, _T("limitY"))) {
			_tprintf(_T("\n[ERRO] Leitura do 'limite Y' a partir do registry."));
			return FALSE;
		}
		else if (!loadRegistry(server, REGISTRY_PATH, _T("timer"))) {
			_tprintf(_T("\n[ERRO] Leitura do 'temporizador' a partir do registry."));
			return FALSE;
		}

		// aleatoriamente escolher o ponto de partida e de destino
		server->startingPoint = defineCoordinate(*server, server->limitX, server->limitY);
		server->endingPoint = defineCoordinate(*server, server->limitX, server->limitY);

		// definir o ponto de partida e destino na matriz
		server->matrix[server->startingPoint.x][server->startingPoint.y] = _T('P');
		server->matrix[server->endingPoint.x][server->endingPoint.y] = _T('D');

		_tprintf(_T("\n[SUCESSO] Carregou os valores dos limites e temporizador a partir do registry.\n"));

		return TRUE;
	case 4:
		for (int i = 1; i < argc; i++) {
			if (atoi(argv[i]) < 0) {	// restricao para todos os argumentos, devem ser > 0
				_tprintf(_T("[ERRO] Os argumentos devem ser valores inteiros maiores que 0\n"));
				return FALSE;
			}
			else if (atoi(argv[i]) > 20 && i != 3) {	// retricao para os dois primeiros argumentos: limiteX e limite Y
				_tprintf(_T("[ERRO] Os primeiros dois argumentos (limites) devem ser maiores que 0 e menos que 20\n"));
				return FALSE;
			}
		}

		// atribuir os valores a estrutura servidor, converter: string > int			
		server->limitX = _tstoi(argv[1]);
		server->limitY = _tstoi(argv[2]);
		server->timer = _tstoi(argv[3]);

		// aleatoriamente escolher o ponto de partida e de destino
		server->startingPoint = defineCoordinate(*server, server->limitX, server->limitY);
		server->endingPoint = defineCoordinate(*server, server->limitX, server->limitY);			

		// definir o ponto de partida e destino na matriz
		server->matrix[server->startingPoint.x][server->startingPoint.y] = _T('P');
		server->matrix[server->endingPoint.x][server->endingPoint.y] = _T('D');

		// guardar os valores lidos no Registry
		createRegistry(REGISTRY_PATH, _T("limitX"), server->limitX);
		createRegistry(REGISTRY_PATH, _T("limitY"), server->limitY);
		createRegistry(REGISTRY_PATH, _T("timer"), server->timer);

		_tprintf(_T("\n[SUCESSO] Inseriu os valores dos limites e temporizador no registry.\n"));

		return TRUE;
	default:
		// tem de receber pelo menos 4 argumentos .\Servidor <limiteX> <limiteY> <temporizador>
		if (argc < 4) {
			_tprintf(_T("[ERRO] Numero de argumentos insuficiente. Uso: .\\Servidor <limiteX> <limiteY> <temporizador>\n"));
			return FALSE;
		}
	}
	return FALSE;
}

BOOL loadRegistry(ConsumerStruct* server, TCHAR path[], TCHAR name[]) {
	HKEY key;
	int result;

	// verifica se a chave existe
	result = RegOpenKeyExA(
		HKEY_CURRENT_USER,
		path,
		0,
		KEY_ALL_ACCESS,
		&key);

	// nao encontrou a chave
	if (result == ERROR_FILE_NOT_FOUND) {
		_tprintf(_T("\nErro [RegOpenKeyExA]: %d"), GetLastError());
		return FALSE;
	}
	else if (result == ERROR_SUCCESS) {	// encontrou a chave
		DWORD valor;
		DWORD tam = sizeof(DWORD);	// tam. do valor a ser atribuido

		result = RegQueryValueEx(
			key,
			name,
			NULL,
			NULL,
			&valor,
			&tam
		);

		if (result == ERROR_SUCCESS) {
			// fecha a chave
			RegCloseKey(key);

			// verifica qual o valor lido, e atribui ao parametro do servidor
			if (_tcscmp(name, _T("limitX")) == 0)
				server->limitX = valor;
			else if (_tcscmp(name, _T("limitY")) == 0)
				server->limitY = valor;
			else if (_tcscmp(name, _T("timer")) == 0)
				server->timer = valor;
			else
				return FALSE;
			return TRUE;
		}
		// fecha a chave
		RegCloseKey(key);

		return TRUE;
	}
	return FALSE;
}

BOOL createRegistry(TCHAR path[], TCHAR name[], int value) {
	HKEY key;
	int result;

	// verifica se a chave ja existe
	result = RegOpenKeyExA(
		HKEY_CURRENT_USER,
		path,
		0,
		KEY_ALL_ACCESS,
		&key);

	// se ainda nao existir, cria a chave
	if (result == ERROR_FILE_NOT_FOUND) {
		result = RegCreateKeyExA(
			HKEY_CURRENT_USER,
			path,
			0,
			NULL,
			REG_OPTION_NON_VOLATILE,
			KEY_ALL_ACCESS,
			NULL,
			&key,
			NULL
		);
		if (result != ERROR_SUCCESS) {
			_tprintf(_T("\nERRO [RegCreateKeyExA]: %d"), GetLastError());
			return FALSE;
		}
		_tprintf(_T("\nChave criada com sucesso."));
	}

	// converter o valor para uma DWORD para ser atribuido a chave
	DWORD dwValue = value;

	// atribuir o valor a chave
	result = RegSetValueEx(
		key,
		name,
		0,
		REG_DWORD,
		&dwValue,
		sizeof(dwValue)
	);

	if (result != ERROR_SUCCESS) {
		_tprintf(_T("\nErro [RegSetValueEx]: %d"), GetLastError());
		return FALSE;
	}

	// quando termina fecha a chave
	RegCloseKey(key);

	return TRUE;
}

void displayParameters(ConsumerStruct server) {
	_tprintf(_T("\n\nParametros obtidos: "));
	_tprintf(_T("\nLimite X: %d"), server.limitX);
	_tprintf(_T("\nLimite Y: %d"), server.limitY);
	_tprintf(_T("\nTemporizador: %d"), server.timer);
	_tprintf(_T("\nPonto de Partida: (%d,%d)"), server.startingPoint.x, server.startingPoint.y);
	_tprintf(_T("\nPonto de Destino: (%d,%d)\n"), server.endingPoint.x, server.endingPoint.y);

	_tprintf(_T("\nMapa:\n\n"));
	for (int y = server.limitY - 1; y >= 0; y--) {
		for (int x = 0; x < server.limitX; x++)
			_tprintf(_T("%c "), server.matrix[x][y]);
		_tprintf(_T("\n"));
	}
}

void insertBlocks(ConsumerStruct* server, int nrBlocks) {
	int rndX = 0, rndY = 0, counter = 0, blocks = 0, aux = 0;

	if (server->nrClients == 0) {
		_tprintf(_T("Nao existem jogadores.\n"));
		return;
	}

	// comeca por verificar se tem espaco no mapa para inserir os blocos
	for (int y = server->sharedServer->limitY - 1; y >= 0; y--)
		for (int x = 0; x < server->sharedServer->limitX; x++)
			if (server->sharedServer->matrix[x][y] == _T('·'))
				counter++;
	if (counter < nrBlocks) {
		_tprintf(_T("Numero de blocos a ser inserido excede as quadriculas disponiveis.\n"));
		return;
	}
	for (int i = 0; i < server->nrClients; i++) {
		blocks = nrBlocks;
		while (blocks > 0) {
			do {
				rndX = rand() % server->limitX;
				rndY = rand() % server->limitY;
				// fazer as verificacoes para nao inserir o bloco numa quadricula ja ocupada
			} while (server->startingPoint.x == rndX && server->startingPoint.y == rndY
				|| server->endingPoint.x == rndX && server->endingPoint.y == rndY
				|| server->clientArray[i].game.matrix[rndX][rndY] != _T('·'));
			server->clientArray[i].game.matrix[rndX][rndY] = _T('B');
			server->sharedServer->clientArray[i].game.matrix[rndX][rndY] = _T('B');
			blocks--;
		}

		// inserir 1's no array consoante a posicao que tiver uma celulas bloqueadas
		aux = 0;
		for (int y = server->limitY - 1; y >= 0; y--) {
			for (int x = 0; x < server->limitX; x++) {
				if (server->clientArray[i].game.matrix[x][y] == _T('B'))
					server->clientArray[i].game.matrixCells[aux] = _T('B');
				aux++;
			}
		}

		// informar o cliente de que os blocos vao ser inseridos
		if (!WriteFile(server->clientArray[i].game.hPipeS2C, &server->clientArray[i].game, sizeof(server->clientArray[i].game), NULL, NULL))
			_tprintf(_T("\n[WriteFile] Erro a escrever no pipe. Erro[%d]\n\n"), GetLastError());
		else
			_tprintf(_T("\n[WriteFile] Informei o cliente[%s] que vao ser inseridos blocos no mapa.\n\n"), server->clientArray[i].name);
	}	
}

TCHAR returnPiece(ConsumerStruct* server, TCHAR actualPiece) {
	TCHAR arr[] = { _T('━'), _T('┃'), _T('┏'), _T('┓'), _T('┛'), _T('┗') };
	if (server->random) {
		int index = rand() % 6;
		return arr[index];
	}
	else {
		for (int i = 0; i < 6; i++)
			if (actualPiece == arr[i] && i < 5)
				return arr[i + 1];
	}
	return arr[0];
}

//===================================== utils =====================================
TCHAR** splitString(TCHAR* str, const TCHAR* delim, unsigned int* size) {
	TCHAR* nextToken = NULL, ** temp, ** returnArray = NULL;
	TCHAR* token = _tcstok_s(str, delim, &nextToken);

	if (str == NULL) {
		_ftprintf(stderr, TEXT("[ERRO] String vazia!"));
		return NULL;
	}

	*size = 0;

	while (token != NULL) {
		temp = realloc(returnArray, sizeof(TCHAR*) * (*size + 1));

		if (temp == NULL) {
			_ftprintf(stderr, TEXT("[ERRO] Impossivel alocar memoria para string!"));
			return NULL;
		}

		returnArray = temp;
		returnArray[(*size)++] = token;

		token = _tcstok_s(NULL, delim, &nextToken);
	}

	return returnArray;
}

BOOL isStringANumber(TCHAR* str) {
	unsigned int i;

	for (i = 0; i < _tcslen(str); i++) {
		if (!_istdigit(str[i])) return FALSE;
	}

	return TRUE;
}

BOOL verifyPlay(Client client, ConsumerStruct server, Play play, int index) {
	// verifica se a jogada esta dentro dos limites do mapa
	if (play.x >= server.limitX || play.y >= server.limitY)
		return FALSE;

	// verificar a primeira jogada (se esta no ponto de partida)
	if (index == 0) {
		// se comecar nas extremidades do x deve comecar com  '━'
		if (server.startingPoint.x == 0 || server.startingPoint.x == server.limitX - 1)
			if (play.x == server.startingPoint.x && play.y == server.startingPoint.y && play.piece == _T('━'))
					return TRUE;
		// se nao comecar nas extremidades do y deve comecar com '┃'
		if (play.x == server.startingPoint.x && play.y == server.startingPoint.y && play.piece == _T('┃'))
				return TRUE;
		
		return FALSE;
	}

	// verificar se a jogada anterior (ver pos. anterior na matrix) e compativel com esta
	switch (play.piece) {
		case _T('┃'):
			// verifica a jogada anterior e se esta na linha acima (util para saber em que direcao estamos a ir
			// ex: cima para baixo, esquerda para direita,...)

			// se a jogada anterior for na linha acima da atual
			if (client.game.playArray[index - 1].y == (play.y + 1) && client.game.playArray[index - 1].x == play.x) {
				if (client.game.playArray[index - 1].piece == _T('┃')
					|| client.game.playArray[index - 1].piece == _T('┓')
					|| client.game.playArray[index - 1].piece == _T('┏'))
					return TRUE;
			}
			// se a jogada anterior for na linha abaixo da atual
			else if (client.game.playArray[index - 1].y == (play.y - 1) && client.game.playArray[index - 1].x == play.x) {
				if (client.game.playArray[index - 1].piece == _T('┃')
					|| client.game.playArray[index - 1].piece == _T('┗')
					|| client.game.playArray[index - 1].piece == _T('┛'))
					return TRUE;
			}
			break;
		case _T('┗'):
			// se a jogada anterior for na linha acima da atual
			if (client.game.playArray[index - 1].y == (play.y + 1) && client.game.playArray[index - 1].x == play.x) {
				if (client.game.playArray[index - 1].piece == _T('┃')
					|| client.game.playArray[index - 1].piece == _T('┓')
					|| client.game.playArray[index - 1].piece == _T('┏'))
					return TRUE;
			}
			// se a jogada anterior for na mesma linha e do lado direito
			else if (client.game.playArray[index - 1].y == play.y && client.game.playArray[index - 1].x == (play.x + 1)) {
				if (client.game.playArray[index - 1].piece == _T('━')
					|| client.game.playArray[index - 1].piece == _T('┓')
					|| client.game.playArray[index - 1].piece == _T('┛'))
					return TRUE;
			}
			break;
		case  _T('┛'):
			// se a jogada anterior for na linha acima da atual
			if (client.game.playArray[index - 1].y == (play.y + 1) && client.game.playArray[index - 1].x == play.x) {
				if (client.game.playArray[index - 1].piece == _T('┃')
					|| client.game.playArray[index - 1].piece == _T('┓')
					|| client.game.playArray[index - 1].piece == _T('┏'))
					return TRUE;
			}
			// se a jogada anterior for na mesma linha e do lado esquerdo
			else if (client.game.playArray[index - 1].y == play.y && client.game.playArray[index - 1].x == (play.x - 1)) {
				if (client.game.playArray[index - 1].piece == _T('━')
					|| client.game.playArray[index - 1].piece == _T('┏')
					|| client.game.playArray[index - 1].piece == _T('┗'))
					return TRUE;
			}
			break;
		case _T('━'):
			// se a jogada anterior for na mesma linha e do lado direito
			if (client.game.playArray[index - 1].y == play.y && client.game.playArray[index - 1].x == (play.x + 1)) {
				if (client.game.playArray[index - 1].piece == _T('━')
					|| client.game.playArray[index - 1].piece == _T('┓')
					|| client.game.playArray[index - 1].piece == _T('┛'))
					return TRUE;
			}
			else if (client.game.playArray[index - 1].y == play.y && client.game.playArray[index - 1].x == (play.x - 1)) {
				if (client.game.playArray[index - 1].piece == _T('━')
					|| client.game.playArray[index - 1].piece == _T('┏')
					|| client.game.playArray[index - 1].piece == _T('┗'))
					return TRUE;
			}
			break;
		case _T('┓'):
			// se a jogada anterior for na mesma linha e do lado esquerdo
			if (client.game.playArray[index - 1].y == play.y && client.game.playArray[index - 1].x == (play.x - 1)) {
				if (client.game.playArray[index - 1].piece == _T('━')
					|| client.game.playArray[index - 1].piece == _T('┏')
					|| client.game.playArray[index - 1].piece == _T('┗'))
					return TRUE;
			}
			// se a jogada anterior for na mesma linha e do lado esquerdo
			else if (client.game.playArray[index - 1].y == (play.y - 1) && client.game.playArray[index - 1].x == play.x) {
				if (client.game.playArray[index - 1].piece == _T('┃')
					|| client.game.playArray[index - 1].piece == _T('┛')
					|| client.game.playArray[index - 1].piece == _T('┗'))
					return TRUE;
			}
			break;
		case _T('┏'):
			// se a jogada anterior for na mesma linha e do lado esquerdo
			if (client.game.playArray[index - 1].y == play.y && client.game.playArray[index - 1].x == (play.x + 1)) {
				if (client.game.playArray[index - 1].piece == _T('━')
					|| client.game.playArray[index - 1].piece == _T('┛')
					|| client.game.playArray[index - 1].piece == _T('┓'))
					return TRUE;
			}
			// se a jogada anterior for na mesma linha e do lado esquerdo
			else if (client.game.playArray[index - 1].y == (play.y - 1) && client.game.playArray[index - 1].x == play.x) {
				if (client.game.playArray[index - 1].piece == _T('┃')
					|| client.game.playArray[index - 1].piece == _T('┛')
					|| client.game.playArray[index - 1].piece == _T('┗'))
					return TRUE;
			}
			break;
	}

	return FALSE;
}


// DisconnectAndReconnect(PipeStruct pipe) 
// Esta funcao e chamada sempre que um cliente se desconecta
// fecha o handle do pipe, reabre a conexao e espera que outro cliente se conecte

BOOL DisconnectAndReconnect(PipeStruct pipe) {
	// desconecta do pipe overlapped (cliente > servidor)
	if (!DisconnectNamedPipe(pipe.hInstance)) {
		_tprintf(_T("DisconnectNamedPipe falhou com o erro[%d].\n"), GetLastError());
		return FALSE;
	}

	// desconecta do pipe servidor > cliente
	if (!DisconnectNamedPipe(pipe.hPipeServerToClient)) {
		_tprintf(_T("DisconnectNamedPipe falhou com o erro[%d].\n"), GetLastError());
		return FALSE;
	}

	if (ConnectNamedPipe(pipe.hInstance, &pipe.overlap)) {
		_tprintf(_T("[CreateNamedPipe] Ligacao ao cliente!, Erro[%d]"), GetLastError());

		return FALSE;
	}

	if (ConnectNamedPipe(pipe.hPipeServerToClient, &pipe.overlap)) {
		_tprintf(_T("[CreateNamedPipe] Ligacao ao cliente!, Erro[%d]"), GetLastError());
		return FALSE;
	}

	_tprintf(_T("\nDesconectou o cliente com sucesso do pipe. Aguarda uma nova ligacao...\n"));

	return TRUE;
}