#include "balcao.h"

typedef struct  {
    int pid;
    int tempo;
    bool expirou;
} Temporizador;

void *sinalVida(void *dados) {
    Temporizador *pdados = (Temporizador *)dados;
    while(1) {
        printf("\nESP[%d] => [%d]\n", pdados->pid,pdados->tempo);
        pdados->tempo--;
        fflush(stdout);
        sleep(1);

        if (pdados->tempo == 0) {
            printf("\nESP[%d] => [%d]\n", pdados->pid,pdados->tempo);
            printf("Sem sinal de vida do especialista[%d]!",pdados->pid);
            pdados->expirou = true;
            fflush(stdout);
            break;
        }
    }
    pthread_exit(NULL);
}

int main(int argc, char ** argv) {
    Balcao balcao;
    Cliente cliente;
    Medico medico;

    int nfd;
    fd_set read_fds;
    struct timeval tv;

    inicializa(&balcao);
    getEnvVars(&balcao);
    infoBalcao(balcao);

    Temporizador *temporizador;
    pthread_t *time;

    int count_fila = balcao.freqFila;
    int nTemporizadores = 0, nThreads = 0;

    if (signal(SIGINT,trataSig) == SIG_ERR) {
        perror("\nNão foi possivel configurar o sinal SIGINT\n");
        exit(EXIT_FAILURE);
    }

    if (signal (SIGALRM, trataSigAlrm) == SIG_ERR) {
        perror("\nNão foi possivel configurar o sinal SIGALRM\n");
        exit(EXIT_FAILURE);
    }

    if (mkfifo(BALCAO_FIFO, 0666) == -1) {  /* 1) criar o fifo e fazer as verificações */
        if (errno == EEXIST) {
            printf("Erro - Já existe ou o programa já está a correr\n");
        }
        printf("Erro a abrir fifo\n");
        return 1;
    }

    if (mkfifo(BALCAO_FIFO_MED, 0666) == -1) {  /* 1) criar o fifo e fazer as verificações */
        if (errno == EEXIST) {
            printf("Erro - Já existe ou o programa já está a correr\n");
        }
        printf("Erro a abrir fifo\n");
        return 1;
    }

    int fdRecebeCliente = open(BALCAO_FIFO,O_RDWR | O_NONBLOCK);  /* 2) abrir para leitura e fazer as verificações */
    if (fdRecebeCliente == -1) {
        printf("Erro a abrir o pipe cliente\n");
        return 1;
    }

    int fdRecebeMedico = open(BALCAO_FIFO_MED,O_RDWR | O_NONBLOCK);  /* 2) abrir para leitura e fazer as verificações */
    if (fdRecebeMedico == -1) {
        printf("Erro a abrir o pipe medico\n");
        return 1;
    }

    do {    /* 3) ler e verificar se o numero de bytes lidos é > 0  (de vários clientes / le vários pipes)*/
        tv.tv_sec = 1; // segundos
        tv.tv_usec = 0; // micro segundos

        FD_ZERO(&read_fds);
        FD_SET(0, &read_fds);
        FD_SET(fdRecebeCliente, &read_fds);
        FD_SET(fdRecebeMedico, &read_fds);

        nfd = select(max(fdRecebeCliente, fdRecebeMedico) + 1, &read_fds, NULL, NULL, &tv);

        if (nfd == -1) {
            perror("\nErro no select\n");
            close(fdRecebeCliente);
            close(fdRecebeMedico);
            unlink(BALCAO_FIFO);
            unlink(BALCAO_FIFO_MED);
            return EXIT_FAILURE;
        }

        if (FD_ISSET(0, &read_fds))
            trataTeclado(&balcao);

        if (FD_ISSET(fdRecebeCliente, &read_fds))
            balcao = pipeCliente(fdRecebeCliente, cliente, balcao);

        if (FD_ISSET(fdRecebeMedico, &read_fds)) {
            int medico_pid = 0;
            balcao = pipeMedico(fdRecebeMedico, medico, balcao, &medico_pid);

            /* verifica se o medico tem alguma thread a correr */
            bool temThread = false;
            for (int i = 0; i < balcao.nMedicos; i++)
                if (balcao.medicos[i].thread && balcao.medicos[i].medico_pid == medico_pid)
                    temThread = true;

            if (temThread) {
                printf("\nA RECOMEÇAR CONTAGEM -> ESPECIALISTA[%d]\n\n",medico_pid);
                /* redefine o valor do temporizador para 20 segundos (recomeça a contagem)
                 * cada medico tem o seu proprio temporizador associado ao PID */
                for (int i = 0; i < nTemporizadores; i++) {
                    if (temporizador[i].pid == medico_pid)
                        temporizador[i].tempo = 20;
                }
            /* se o medico que esta a chegar não tem thread (não está no sistema), então verifica capacidade*/
            } else if (!balcao.cheioMedicos) {
                if (nThreads == 0) {
                    /* alocar memoria para nova estrutura de dados tempo */
                    temporizador = malloc(sizeof(Temporizador));

                    /* definir os dados do novo objeto temporizador */
                    temporizador[nTemporizadores].pid = medico_pid;
                    temporizador[nTemporizadores].tempo = 20;
                    temporizador[nTemporizadores].expirou = false;

                    /* alocar memoria para uma nova thread */
                    time = malloc(sizeof(pthread_t));

                    if (pthread_create(&time[nThreads], NULL, &sinalVida, &temporizador[nTemporizadores]) != 0) {
                        printf("erro - thread especialista[%d]\n", medico_pid);
                        exit(-1);
                    }

                    /* guardar o indice da thread para ser acedido mais tarde */
                    setThreadMedico(&balcao, medico_pid, &time[nThreads]);

                    /* incrementar os contadores */
                    nThreads++; nTemporizadores++;
                } else if (nThreads > 0) {
                    /* realocar memoria para nova estrutura de dados tempo */
                    temporizador = realloc(temporizador, sizeof(Temporizador) * nTemporizadores + 1);

                    /* definir os dados do novo objeto temporizador */
                    temporizador[nTemporizadores].pid = medico_pid;
                    temporizador[nTemporizadores].tempo = 20;
                    temporizador[nTemporizadores].expirou = false;

                    /* alocar memoria para uma nova thread e chama o temporizador com o pid do medico*/
                    time = realloc(time, sizeof(pthread_t) * nThreads + 1);
                    if (pthread_create(&time[nThreads], NULL, &sinalVida, &temporizador[nTemporizadores]) != 0) {
                        printf("erro - thread especialista[%d]\n", medico_pid);
                        exit(-1);
                    }

                    /* guardar a thread na estrutura medico para ser acedida mais tarde */
                    setThreadMedico(&balcao, medico_pid, &time[nThreads]);

                    /* incrementar os contadores */
                    nThreads++; nTemporizadores++;
                }
            }
        }

        if (count_fila == 0) {   // select configurado para operar de 1 em 1 segundo
            listaFilaEspera(balcao);
            count_fila = balcao.freqFila;    // repõe o valor para a contagem decrescente
        } else
            count_fila--;

        for (int j = 0; j < nTemporizadores; j++) {
            if (temporizador[j].expirou) {
                printf("ESPECIALISTA[%d] VAI SAIR!\n", temporizador[j].pid);
                /* verifica se o medico já esta a comunicar com algum processo */
                for (int i = 0; i < balcao.nMedicos; i++) {
                    if (balcao.medicos[i].medico_pid == temporizador[j].pid){
                        if (balcao.medicos[i].comunicaPid > 0) { /* já está a comunicar */
                            printf("\nA remover o utente [%d]\n",balcao.medicos[i].comunicaPid);
                            kill(balcao.medicos[i].comunicaPid,SIGINT);
                            eliminaUtente(&balcao,balcao.medicos[i].comunicaPid);
                        }
                    }
                }

                pthread_cancel(delThreadMedico(balcao,temporizador[j].pid));
                kill(temporizador[j].pid,SIGINT);
                eliminaEspecialista(&balcao,temporizador[j].pid);
                printf("\nA enviar informação ao especialista[%d] que vai ser retirado\n\n", temporizador[j].pid);

                balcao.comunicaCliPID = 0;
                temporizador[j].expirou = false;
                temporizador[j].pid = 0;
                temporizador[j].tempo = 0;

                break;
            }
        }
    } while(!balcao.avisa);

    free(time);
    free(temporizador);
    close(fdRecebeCliente);
    close(fdRecebeMedico);
    unlink(BALCAO_FIFO);
    unlink(BALCAO_FIFO_MED);

    return 0;
}